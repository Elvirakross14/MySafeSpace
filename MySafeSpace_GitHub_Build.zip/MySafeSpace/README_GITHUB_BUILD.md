# Build My Safe Space 3.1 from GitHub Actions

1. Replace the repository\'s existing `MySafeSpace_GitHub_Build.zip` with this updated archive, keeping the exact filename expected by the existing workflow.
2. Keep the existing GitHub Actions workflow unchanged for this source-only test build. It should unpack the archive into `source/` and run `gradle assembleDebug` from `source/MySafeSpace`.
3. In GitHub, open **Actions**, choose **Build My Safe Space APK**, and run the workflow (or let the existing push trigger start it).
4. When the run finishes successfully, open the run, scroll to **Artifacts**, and download `MySafeSpace-APK`.
5. Extract the artifact ZIP on Android.

The project root inside this archive is `MySafeSpace/`. The application ID remains `com.mysafespace.app` and versionCode is increased to 4.

**Important: do not install this APK over the existing installation yet.** Android requires both the same application ID and the same signing certificate for an in-place update. A hosted GitHub Actions `assembleDebug` build may use a newly generated debug keystore on each runner. The current workflow does not show a persistent signing-key setup, so the signing certificate must be checked before attempting an update. Do not uninstall the current app; that can erase its local encrypted vault. For reliable future updates, configure one private signing key via GitHub Actions Secrets and use it for every build. Never commit that private keystore to this public repository.

Gradle generates the offline rain and forest WAV sound resources during the build. They are intentionally not included as large files in this source archive.

## Verification status

This archive has been checked for Java delimiter balance, required resource references, and XML well-formedness. It has **not** been compiled with the Android SDK in this environment. A green GitHub Actions build is still required before the APK can be considered build-verified.
