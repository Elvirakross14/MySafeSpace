# Build APK with GitHub Actions (phone-friendly)

This project includes `.github/workflows/android.yml`. After the project is pushed to a GitHub repository on the `main` branch, GitHub Actions builds a debug APK automatically. You can also start it manually from the Actions tab using **Build My Safe Space APK** → **Run workflow**.

When the run finishes successfully:
1. Open the completed workflow run.
2. Find **Artifacts** at the bottom.
3. Download `MySafeSpace-debug-apk`.
4. Extract the downloaded ZIP and tap `app-debug.apk` on Android.
5. If Android asks, allow your browser/file manager to install unknown apps, then install.

This is a debug APK for personal testing, not a release-signed APK for Google Play. The app is a starter version; the Support chat uses preset offline replies, not ChatGPT.
