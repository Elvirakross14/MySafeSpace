# Build My Safe Space 2.0 from GitHub Actions

1. Replace the existing `MySafeSpace_GitHub_Build.zip` in your repository with this updated archive.
2. Keep the GitHub Actions workflow that previously built version 1.0 successfully.
3. Open **Actions** in the repository, choose **Build My Safe Space APK**, and tap **Run workflow** (or push the updated ZIP to `main` if the workflow is set to run on push).
4. When the run finishes with a green check, open the run, scroll to **Artifacts**, and download `MySafeSpace-APK`.
5. Extract the artifact ZIP on your Android phone and install `app-debug.apk`.

The project inside the archive is at `MySafeSpace/`. The workflow used for the successful previous build should unzip the archive to `source/`, then run `gradle assembleDebug` from `source/MySafeSpace` and upload `source/MySafeSpace/app/build/outputs/apk/debug/app-debug.apk`. During that build, Gradle creates the two offline ambient WAV loops. They are not stored as large files in the upload archive; the APK keeps them uncompressed and should exceed 40 MB.

Version 2.0 keeps the same Android application ID so it can update the previously installed app. Existing diary notes are migrated from the earlier local preference store where possible.
