# Build My Safe Space 3.3 from GitHub Actions

1. Replace the repository-root file `MySafeSpace_GitHub_Build.zip` with this archive, keeping that exact filename.
2. Keep the repository-root `.github/workflows/android.yml` unchanged. It unpacks the ZIP into `source/`, builds `source/MySafeSpace`, then signs the APK with the existing persistent keystore stored in GitHub Actions Secrets.
3. In GitHub, open **Actions** and run **Build My Safe Space APK**, or let the existing push trigger start it.
4. When the run succeeds, download the `MySafeSpace-APK` artifact.

The ZIP contains the project directory `MySafeSpace/`. Its Android application ID remains `com.mysafespace.app`; versionCode is 6 and versionName is 3.3. The source archive does not contain the private signing keystore or any signing passwords. Do not change the repository's signing secrets or workflow.

Gradle generates the offline rain and forest WAV files during the build.

## Build and installation safety

The GitHub workflow in the repository uses the permanent signing key from Actions Secrets. Nevertheless, wait for a green workflow and verify the resulting artifact before installing. Do not uninstall the current app, because this could erase its local encrypted vault. Install over the existing app only if Android accepts it as an update; a signing-certificate mismatch must be resolved before installing.

## Yandex Disk

Cloud backup code is included, but the user must register an OAuth app and enter its Client ID in the app. The OAuth redirect is `mysafespace://oauth/callback`; required app-folder scope is `cloud_api:disk.app_folder`. Save the generated recovery key separately from the phone. OAuth setup and real Yandex API round trips need to be tested with the user's own Yandex account.

## Verification status

The source tree and XML have been checked in this environment, but Android SDK/Gradle are unavailable here. The archive has not been compiled locally. A successful GitHub Actions run is required before considering the APK build-verified. The new cat touch/drag behaviors also need real-device testing.
