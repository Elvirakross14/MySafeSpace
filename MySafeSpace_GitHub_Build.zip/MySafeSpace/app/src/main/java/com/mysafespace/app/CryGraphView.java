package com.mysafespace.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

/** Small adaptive line chart for daily episode counts or average intensity. */
final class CryGraphView extends View {
    private final float[] values;
    private final Paint grid = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint point = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final int muted, gridColor;

    CryGraphView(Context context, float[] values, int accent, int muted, int gridColor) {
        super(context);
        this.values = values == null ? new float[0] : values.clone();
        this.muted = muted;
        this.gridColor = gridColor;
        grid.setColor(gridColor);
        grid.setStrokeWidth(context.getResources().getDisplayMetrics().density);
        grid.setStyle(Paint.Style.STROKE);
        line.setColor(accent);
        line.setStrokeWidth(3.2f * context.getResources().getDisplayMetrics().density);
        line.setStrokeCap(Paint.Cap.ROUND);
        line.setStrokeJoin(Paint.Join.ROUND);
        line.setStyle(Paint.Style.STROKE);
        point.setColor(accent);
        point.setStyle(Paint.Style.FILL);
        text.setColor(muted);
        text.setTextSize(10f * context.getResources().getDisplayMetrics().scaledDensity);
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float density = getResources().getDisplayMetrics().density;
        float left = 25f * density, right = getWidth() - 10f * density;
        float top = 12f * density, bottom = getHeight() - 24f * density;
        if (right <= left || bottom <= top) return;
        for (int i = 0; i < 4; i++) {
            float y = top + (bottom - top) * i / 3f;
            canvas.drawLine(left, y, right, y, grid);
        }
        if (values.length == 0) {
            text.setTextAlign(Paint.Align.CENTER);
            canvas.drawText("Пока нет данных для графика", (left + right) / 2f, (top + bottom) / 2f, text);
            return;
        }
        float max = 1f;
        for (float value : values) if (!Float.isNaN(value) && !Float.isInfinite(value)) max = Math.max(max, value);
        Path path = new Path();
        float step = values.length <= 1 ? 0 : (right - left) / (values.length - 1f);
        boolean segmentStarted = false;
        for (int i = 0; i < values.length; i++) {
            if (Float.isNaN(values[i]) || Float.isInfinite(values[i])) { segmentStarted = false; continue; }
            float x = left + i * step;
            float y = bottom - (Math.max(0, values[i]) / max) * (bottom - top);
            if (!segmentStarted) { path.moveTo(x, y); segmentStarted = true; } else path.lineTo(x, y);
        }
        canvas.drawPath(path, line);
        int stride = Math.max(1, values.length / 9);
        for (int i = 0; i < values.length; i++) {
            if (Float.isNaN(values[i]) || Float.isInfinite(values[i])) continue;
            if (i % stride != 0 && i != values.length - 1) continue;
            float x = left + i * step;
            float y = bottom - (Math.max(0, values[i]) / max) * (bottom - top);
            canvas.drawCircle(x, y, 3.4f * density, point);
        }
        text.setTextAlign(Paint.Align.LEFT);
        canvas.drawText("0", 3f * density, bottom + 13f * density, text);
        canvas.drawText("" + Math.round(max), 3f * density, top + 4f * density, text);
        text.setTextAlign(Paint.Align.RIGHT);
        canvas.drawText("сегодня", right, getHeight() - 4f * density, text);
    }
}
