package com.mysafespace.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/** Uploads a portable, AES-GCM encrypted backup to the restricted Yandex Disk app folder. */
public final class YandexBackupWorker extends Worker {
    private static final String VAULT_ALIAS = "MySafeSpaceVaultKey";
    public YandexBackupWorker(@NonNull Context context, @NonNull WorkerParameters params) { super(context, params); }

    @NonNull @Override public Result doWork() {
        Context context = getApplicationContext();
        SharedPreferences prefs = context.getSharedPreferences("safe_space", Context.MODE_PRIVATE);
        if (!prefs.getBoolean("yandex_connected", false)
                || (!prefs.getBoolean("yandex_sync_enabled", false) && !getInputData().getBoolean("force", false))
                || !prefs.getBoolean("backup_key_confirmed", false)) return Result.success();
        HttpURLConnection connection = null;
        try {
            SecretKey localKey = localKey();
            String token = freshAccessToken(context, prefs, localKey);
            byte[] recoveryKey = decryptBytes(prefs.getString("backup_key_wrapped", ""), localKey);
            if (token.isEmpty() || recoveryKey.length != 32) throw new IllegalStateException("Yandex authorization or recovery key is missing");
            String vault = prefs.getString("vault", "");
            if (vault.isEmpty()) return Result.success();
            String json = decryptText(vault, localKey);
            byte[] zipped = makePortableZip(context, json, localKey);
            byte[] encryptedBackup = encryptPortable(zipped, recoveryKey);

            URL link = new URL("https://cloud-api.yandex.net/v1/disk/resources/upload?path=app:/MySafeSpace/secure-backup.mss&overwrite=true");
            connection = (HttpURLConnection) link.openConnection();
            connection.setRequestMethod("GET");
            connection.setRequestProperty("Authorization", "OAuth " + token);
            connection.setConnectTimeout(20000); connection.setReadTimeout(20000);
            int code = connection.getResponseCode();
            if (code == 401) {
                connection.disconnect(); connection = null;
                token = refreshAccessToken(context, prefs, localKey);
                connection = (HttpURLConnection) link.openConnection();
                connection.setRequestMethod("GET");
                connection.setRequestProperty("Authorization", "OAuth " + token);
                connection.setConnectTimeout(20000); connection.setReadTimeout(20000);
                code = connection.getResponseCode();
            }
            if (code != 200) throw new IllegalStateException("Yandex upload URL request failed: " + code);
            JSONObject answer = new JSONObject(readAll(connection.getInputStream()));
            String href = answer.getString("href");
            connection.disconnect(); connection = null;

            connection = (HttpURLConnection) new URL(href).openConnection();
            connection.setRequestMethod("PUT"); connection.setDoOutput(true);
            connection.setConnectTimeout(20000); connection.setReadTimeout(60000);
            connection.setFixedLengthStreamingMode(encryptedBackup.length);
            try (OutputStream out = connection.getOutputStream()) { out.write(encryptedBackup); out.flush(); }
            code = connection.getResponseCode();
            if (code < 200 || code >= 300) throw new IllegalStateException("Yandex upload failed: " + code);
            prefs.edit().putLong("yandex_last_sync", System.currentTimeMillis()).putBoolean("yandex_sync_pending", false).putString("yandex_sync_error", "").apply();
            return Result.success();
        } catch (Exception e) {
            prefs.edit().putBoolean("yandex_sync_pending", true).putString("yandex_sync_error", safeMessage(e)).apply();
            return Result.retry();
        } finally { if (connection != null) connection.disconnect(); }
    }

    private static String freshAccessToken(Context context, SharedPreferences prefs, SecretKey localKey) throws Exception {
        long expiresAt = prefs.getLong("yandex_expires_at", 0L);
        if (expiresAt > 0L && expiresAt <= System.currentTimeMillis() + 5L * 60L * 1000L) {
            return refreshAccessToken(context, prefs, localKey);
        }
        String token = decryptText(prefs.getString("yandex_access_token", ""), localKey);
        if (token.isEmpty()) throw new IllegalStateException("Yandex access token is missing");
        return token;
    }

    private static String refreshAccessToken(Context context, SharedPreferences prefs, SecretKey localKey) throws Exception {
        String refresh = decryptText(prefs.getString("yandex_refresh_token", ""), localKey);
        String clientId = prefs.getString("yandex_client_id", "");
        if (refresh.isEmpty() || clientId.isEmpty()) throw new IllegalStateException("Yandex session expired; reconnect the account");
        String body = "grant_type=refresh_token&refresh_token=" + URLEncoder.encode(refresh, "UTF-8")
                + "&client_id=" + URLEncoder.encode(clientId, "UTF-8");
        HttpURLConnection c = (HttpURLConnection) new URL("https://oauth.yandex.com/token").openConnection();
        try {
            c.setRequestMethod("POST"); c.setDoOutput(true);
            c.setConnectTimeout(20000); c.setReadTimeout(20000);
            c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
            try (OutputStream out = c.getOutputStream()) { out.write(body.getBytes(StandardCharsets.UTF_8)); }
            int code = c.getResponseCode();
            InputStream response = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
            String raw = response == null ? "" : readAll(response);
            JSONObject json = new JSONObject(raw);
            String access = json.optString("access_token", "");
            if (code < 200 || code >= 300 || access.isEmpty()) {
                throw new IllegalStateException(json.optString("error_description", "Yandex token refresh failed"));
            }
            SharedPreferences.Editor edit = prefs.edit().putString("yandex_access_token", encryptText(access, localKey));
            String newRefresh = json.optString("refresh_token", "");
            if (!newRefresh.isEmpty()) edit.putString("yandex_refresh_token", encryptText(newRefresh, localKey));
            long seconds = json.optLong("expires_in", 0L);
            if (seconds > 0L) edit.putLong("yandex_expires_at", System.currentTimeMillis() + seconds * 1000L);
            edit.apply();
            return access;
        } finally { c.disconnect(); }
    }

    private static String encryptText(String text, SecretKey key) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding"); cipher.init(Cipher.ENCRYPT_MODE, key);
        byte[] iv = cipher.getIV(), body = cipher.doFinal(text.getBytes(StandardCharsets.UTF_8));
        byte[] all = new byte[iv.length + body.length];
        System.arraycopy(iv, 0, all, 0, iv.length); System.arraycopy(body, 0, all, iv.length, body.length);
        return Base64.encodeToString(all, Base64.NO_WRAP);
    }

    private static String safeMessage(Exception e) { String m = e.getMessage(); return m == null ? "Sync failed" : m.substring(0, Math.min(180, m.length())); }
    private static SecretKey localKey() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore"); ks.load(null);
        return (SecretKey) ks.getKey(VAULT_ALIAS, null);
    }
    private static byte[] decode(String value) { return Base64.decode(value, Base64.NO_WRAP); }
    private static byte[] decryptBytes(String encoded, SecretKey key) throws Exception {
        if (encoded == null || encoded.isEmpty()) return new byte[0];
        byte[] all = decode(encoded); if (all.length < 13) throw new IllegalArgumentException("Encrypted key is invalid");
        byte[] iv = new byte[12], body = new byte[all.length - 12];
        System.arraycopy(all, 0, iv, 0, 12); System.arraycopy(all, 12, body, 0, body.length);
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding"); cipher.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(128, iv));
        return cipher.doFinal(body);
    }
    private static String decryptText(String encoded, SecretKey key) throws Exception { return new String(decryptBytes(encoded, key), StandardCharsets.UTF_8); }

    private static byte[] decryptAttachment(File file, SecretKey key) throws Exception {
        byte[] all; try (FileInputStream in = new FileInputStream(file); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192]; int n; while ((n = in.read(buffer)) > 0) out.write(buffer, 0, n); all = out.toByteArray();
        }
        if (all.length < 13) throw new IllegalArgumentException("Attachment is invalid");
        byte[] iv = new byte[12], body = new byte[all.length - 12];
        System.arraycopy(all, 0, iv, 0, 12); System.arraycopy(all, 12, body, 0, body.length);
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding"); cipher.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(128, iv));
        return cipher.doFinal(body);
    }
    private static byte[] makePortableZip(Context context, String json, SecretKey localKey) throws Exception {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        try (ZipOutputStream zip = new ZipOutputStream(bytes)) {
            zip.putNextEntry(new ZipEntry("data.json")); zip.write(json.getBytes(StandardCharsets.UTF_8)); zip.closeEntry();
            JSONObject root = new JSONObject(json); JSONArray cries = root.optJSONArray("cries");
            if (cries != null) for (int i = 0; i < cries.length(); i++) {
                JSONObject cry = cries.optJSONObject(i); if (cry == null) continue;
                JSONArray attachments = cry.optJSONArray("attachments"); if (attachments == null) continue;
                for (int j = 0; j < attachments.length(); j++) {
                    JSONObject item = attachments.optJSONObject(j); if (item == null) continue;
                    String fileName = item.optString("fileName", ""); if (!fileName.matches("[A-Za-z0-9_-]+\\.mss")) continue;
                    File file = new File(new File(context.getFilesDir(), "cry_media"), fileName);
                    if (!file.isFile()) continue;
                    byte[] content = decryptAttachment(file, localKey);
                    zip.putNextEntry(new ZipEntry("media/" + fileName)); zip.write(content); zip.closeEntry();
                }
            }
        }
        return bytes.toByteArray();
    }
    private static byte[] encryptPortable(byte[] plain, byte[] keyBytes) throws Exception {
        SecretKey key = new SecretKeySpec(keyBytes, "AES");
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding"); cipher.init(Cipher.ENCRYPT_MODE, key);
        byte[] iv = cipher.getIV(), encrypted = cipher.doFinal(plain), all = new byte[iv.length + encrypted.length];
        System.arraycopy(iv, 0, all, 0, iv.length); System.arraycopy(encrypted, 0, all, iv.length, encrypted.length); return all;
    }
    private static String readAll(InputStream in) throws Exception {
        try (InputStream source = in; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] b = new byte[4096]; int n; while ((n = source.read(b)) > 0) out.write(b, 0, n); return out.toString("UTF-8");
        }
    }
}
