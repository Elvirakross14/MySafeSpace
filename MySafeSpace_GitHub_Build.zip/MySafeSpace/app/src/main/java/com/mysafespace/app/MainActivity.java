package com.mysafespace.app;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.app.DatePickerDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.BroadcastReceiver;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.BitmapFactory;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.media.SoundPool;
import android.net.Uri;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Bundle;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.UUID;
import java.util.Collections;
import java.util.Comparator;
import java.util.concurrent.TimeUnit;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.ExistingWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

/**
 * My Safe Space 3.1 aesthetic home refresh.
 * Personal entries are stored as one AES/GCM encrypted JSON vault using Android Keystore.
 * The app intentionally works offline; online services are not silently simulated.
 */
public class MainActivity extends Activity {
    private static final String VAULT_ALIAS = "MySafeSpaceVaultKey";
    private static final int REQ_EXPORT = 4101, REQ_IMPORT = 4102, REQ_VOICE = 4103, REQ_THEME_EXPORT = 4104, REQ_CRY_IMAGES = 4105, REQ_CRY_AUDIO = 4106;
    private static final String REMINDER_CHANNEL = "mss_reminders";

    private static int BG, PAPER, SAGE, SAGE_DARK, SAGE_LIGHT, MINT, INK, MUTED, LINE, WHITE;
    private LinearLayout root, content, nav, header;
    private String current = "Главная";
    private SharedPreferences prefs;
    private SoundPool soundPool;
    private MediaPlayer ambience;
    private int ambienceId = 0;
    private int sndTap, sndSave, sndOpen;
    private boolean soundEnabled = true, hapticEnabled = true;
    private boolean vaultProblem = false;
    private String themeName = "Midnight";
    private EditText voiceTarget;
    private int backupMode = 0;
    private final LinkedHashSet<String> customCauses = new LinkedHashSet<>();
    private final ArrayList<Attachment> draftAttachments = new ArrayList<>();
    private CryRecord attachmentTarget;
    private TextView attachmentCountLabel;
    private int draftIntensity = 3;
    private boolean draftIntensityEnabled = false;
    private int statsDays = 30;
    private String statsMetric = "episodes";
    private final LinkedHashSet<String> statsCauseFilter = new LinkedHashSet<>();
    private final LinkedHashSet<String> historyCauseFilter = new LinkedHashSet<>();
    private boolean hideGapStats = false;
    private boolean reminderEnabled = false;
    private int reminderMinutes = -1;
    private boolean syncBusy = false;
    private boolean pendingAudioRecordingPermission = false;
    private CryRecord recordingTarget = null;
    private MediaRecorder activeRecorder = null;
    private File activeRecordingFile = null;
    private AlertDialog recordingDialog = null;
    private String yandexClientId = "";
    private String pendingYandexState = "";
    private String pendingYandexVerifier = "";

    private final ArrayList<CryRecord> cries = new ArrayList<>();
    private final ArrayList<JournalEntry> journal = new ArrayList<>();
    private final ArrayList<MemoryEntry> memories = new ArrayList<>();
    private final ArrayList<GoalEntry> goals = new ArrayList<>();
    private final LinkedHashSet<String> hiddenSections = new LinkedHashSet<>();
    private final LinkedHashSet<String> selectedCauses = new LinkedHashSet<>();
    private Calendar visibleMonth = Calendar.getInstance();
    private Calendar selectedDate = Calendar.getInstance();
    private long pendingCryTime = -1L;

    private static final String[] CAUSES = {"Отношения", "Семья", "Одиночество", "Тревога", "Усталость", "Обидные слова", "Воспоминания", "Конфликт", "Не знаю", "Другое"};
    private static final String[] MEMORY_TYPES = {"Важный момент", "Фотография", "Заметка", "Цитата", "Голосовая запись", "Памятная дата", "Письмо себе"};
    private static final String[] HIDE_OPTIONS = {"Дневник", "Воспоминания", "Календарь", "Поддержка"};

    private static class Attachment {
        String fileName, displayName, mime;
        Attachment(String f, String d, String m) { fileName=f; displayName=d; mime=m; }
    }
    private static class CryRecord {
        long time; String causes, note; int intensity = 0; ArrayList<Attachment> attachments = new ArrayList<>();
        CryRecord(long t, String c, String n) { time=t; causes=c; note=n; }
        String day() { return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date(time)); }
    }
    private static class JournalEntry {
        long time; String title, note;
        JournalEntry(long t, String h, String n) { time=t; title=h; note=n; }
    }
    private static class MemoryEntry {
        long time; String type, title, note;
        MemoryEntry(long t, String y, String h, String n) { time=t; type=y; title=h; note=n; }
    }
    private static class GoalEntry {
        long time; String title; boolean done;
        GoalEntry(long t, String h, boolean d) { time=t; title=h; done=d; }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("safe_space", MODE_PRIVATE);
        soundEnabled = prefs.getBoolean("sound", true);
        hapticEnabled = prefs.getBoolean("haptics", true);
        themeName = prefs.getString("theme", "Midnight");
        if ("Sage nature".equalsIgnoreCase(themeName)) themeName = "Dreamcore";
        if ("Lavender".equalsIgnoreCase(themeName)) themeName = "Cloudy";
        if ("Soft grunge".equalsIgnoreCase(themeName)) themeName = "Soft Grunge";
        prefs.edit().putString("theme", themeName).apply();
        for (String s : prefs.getString("hide_sections", "").split("\\|")) if (!s.trim().isEmpty()) hiddenSections.add(s);
        hideGapStats = prefs.getBoolean("hide_gap_stats", false);
        reminderEnabled = prefs.getBoolean("reminder_enabled", false);
        reminderMinutes = prefs.getInt("reminder_minutes", -1);
        yandexClientId = prefs.getString("yandex_client_id", "");
        applyTheme();
        loadData();
        initSounds();
        handleYandexCallback(getIntent());
        if (reminderEnabled && reminderMinutes >= 0 && android.os.Build.VERSION.SDK_INT < 33) scheduleReminder();
        if (reminderEnabled && reminderMinutes >= 0 && android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS")==PackageManager.PERMISSION_GRANTED) scheduleReminder();
        if (prefs.getBoolean("yandex_sync_enabled", false)) enqueueYandexBackup(false);
        showSplash();
    }

    private void applyTheme() {
        if ("Midnight".equalsIgnoreCase(themeName) || "Dark academia".equals(themeName)) {
            BG=Color.rgb(20,22,36); PAPER=Color.rgb(31,34,53); SAGE=Color.rgb(125,166,224); SAGE_DARK=Color.rgb(191,216,250);
            SAGE_LIGHT=Color.rgb(42,51,76); MINT=Color.rgb(35,43,65); INK=Color.rgb(238,242,252); MUTED=Color.rgb(164,176,199); LINE=Color.rgb(67,79,110);
        } else if ("Cloudy".equalsIgnoreCase(themeName) || "Lavender".equals(themeName)) {
            BG=Color.rgb(247,241,250); PAPER=Color.rgb(255,252,255); SAGE=Color.rgb(183,137,196); SAGE_DARK=Color.rgb(115,77,132);
            SAGE_LIGHT=Color.rgb(239,222,245); MINT=Color.rgb(247,235,249); INK=Color.rgb(65,49,73); MUTED=Color.rgb(143,124,151); LINE=Color.rgb(229,210,237);
        } else if ("Soft Grunge".equalsIgnoreCase(themeName) || "Soft grunge".equals(themeName)) {
            BG=Color.rgb(37,31,38); PAPER=Color.rgb(49,40,48); SAGE=Color.rgb(176,105,129); SAGE_DARK=Color.rgb(224,164,185);
            SAGE_LIGHT=Color.rgb(75,48,62); MINT=Color.rgb(61,43,55); INK=Color.rgb(246,232,239); MUTED=Color.rgb(190,164,178); LINE=Color.rgb(93,67,82);
        } else if ("Dreamcore".equalsIgnoreCase(themeName)) {
            BG=Color.rgb(31,42,47); PAPER=Color.rgb(43,58,61); SAGE=Color.rgb(133,190,177); SAGE_DARK=Color.rgb(193,228,217);
            SAGE_LIGHT=Color.rgb(48,70,72); MINT=Color.rgb(42,63,65); INK=Color.rgb(235,246,239); MUTED=Color.rgb(165,197,188); LINE=Color.rgb(74,103,101);
        } else {
            BG=Color.rgb(246,245,237); PAPER=Color.rgb(255,254,249); SAGE=Color.rgb(111,132,105); SAGE_DARK=Color.rgb(62,83,66);
            SAGE_LIGHT=Color.rgb(225,233,218); MINT=Color.rgb(235,241,229); INK=Color.rgb(43,57,46); MUTED=Color.rgb(119,129,116); LINE=Color.rgb(222,226,215);
        }
        WHITE=Color.WHITE;
        if (getWindow()!=null) {
            getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG);
            boolean dark = "Midnight".equalsIgnoreCase(themeName) || "Dark academia".equals(themeName) || "Soft Grunge".equalsIgnoreCase(themeName) || "Dreamcore".equalsIgnoreCase(themeName);
            getWindow().getDecorView().setSystemUiVisibility(dark ? 0 : View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        }
    }

    private void initSounds() {
        try { soundPool = new SoundPool.Builder().setMaxStreams(3).build(); sndTap=soundPool.load(this,R.raw.tap,1); sndSave=soundPool.load(this,R.raw.save,1); sndOpen=soundPool.load(this,R.raw.open,1); }
        catch (Exception ignored) { }
    }
    private void play(int id) { if(soundEnabled && soundPool!=null && id!=0) try { soundPool.play(id,.38f,.38f,1,0,1f); } catch(Exception ignored) { } }
    private void playNature(int which) {
        if(ambience!=null && ambienceId==which && ambience.isPlaying()) { stopNature(); return; }
        stopNature();
        try { ambience=MediaPlayer.create(this,which==1?R.raw.ambience_rain:R.raw.ambience_forest); if(ambience!=null){ambience.setLooping(true);ambience.setVolume(.42f,.42f);ambience.start();ambienceId=which;} }
        catch(Exception e) { stopNature(); Toast.makeText(this,"Не удалось включить звук",Toast.LENGTH_SHORT).show(); }
    }
    private void stopNature() { if(ambience!=null){try{if(ambience.isPlaying())ambience.stop();}catch(Exception ignored){}try{ambience.release();}catch(Exception ignored){}ambience=null;}ambienceId=0; }
    private void feedback(View v,boolean save) { if(hapticEnabled)v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP); play(save?sndSave:sndTap); }

    private void showSplash() {
        LinearLayout splash=column(); splash.setGravity(Gravity.CENTER); splash.setBackground(gradient(BG,SAGE_LIGHT,GradientDrawable.Orientation.TL_BR)); setContentView(splash);
        TextView sprig=label("❧",64,SAGE,true,Typeface.SERIF); sprig.setGravity(Gravity.CENTER); splash.addView(sprig);
        TextView brand=label("My Safe Space",32,INK,false,Typeface.SERIF); brand.setGravity(Gravity.CENTER); brand.setPadding(0,dp(8),0,dp(5)); splash.addView(brand);
        TextView sub=label("твоё личное пространство",13,MUTED,false,Typeface.DEFAULT); sub.setGravity(Gravity.CENTER); splash.addView(sub);
        sprig.setAlpha(0f);sprig.setScaleX(.8f);sprig.setScaleY(.8f);sprig.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(700).start();
        new android.os.Handler().postDelayed(()->{if(!isFinishing()){play(sndOpen);buildShell();showPage("Главная");}},2500);
    }

    private GradientDrawable gradient(int a,int b,GradientDrawable.Orientation o) { GradientDrawable d=new GradientDrawable(o,new int[]{a,b}); d.setCornerRadius(dp(24)); return d; }
    private GradientDrawable solid(int c,int radius,int stroke) { GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(dp(radius));if(stroke!=0)d.setStroke(dp(1),stroke);return d; }
    private int dp(float n) { return (int)(n*getResources().getDisplayMetrics().density+0.5f); }
    private TextView label(String s,int size,int color,boolean bold,Typeface face) { TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.CENTER_VERTICAL);if(face!=null)t.setTypeface(face,bold?Typeface.BOLD:Typeface.NORMAL);else if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t; }
    private LinearLayout column() { LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l; }
    private LinearLayout row() { LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l; }
    private void margins(View v,int bottom) { LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(bottom);content.addView(v,p); }
    private void addSpace(LinearLayout into,int h) { into.addView(new View(this),new LinearLayout.LayoutParams(1,dp(h))); }

    private void buildShell() {
        root=column();root.setBackgroundColor(BG);setContentView(root);
        header=column();header.setPadding(dp(18),dp(9),dp(18),dp(8));
        LinearLayout brandRow=row();TextView sprig=label("❧",24,SAGE,true,Typeface.SERIF);brandRow.addView(sprig,new LinearLayout.LayoutParams(dp(32),dp(36)));
        TextView brand=label("MY SAFE SPACE",12,SAGE_DARK,true,Typeface.DEFAULT);brand.setLetterSpacing(.13f);brandRow.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
        TextView shield=label("◈",22,SAGE_DARK,true,Typeface.DEFAULT);shield.setGravity(Gravity.CENTER);shield.setBackground(solid(MINT,18,LINE));brandRow.addView(shield,new LinearLayout.LayoutParams(dp(40),dp(38)));shield.setOnClickListener(v->{feedback(v,false);showQuickHide();});
        header.addView(brandRow);root.addView(header);
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(false);scroll.setClipToPadding(false);content=column();content.setPadding(dp(17),dp(4),dp(17),dp(22));scroll.addView(content);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        nav=row();nav.setPadding(dp(4),dp(6),dp(4),dp(6));nav.setBackgroundColor(PAPER);nav.setElevation(dp(7));
        String[] tabs={"Главная","Профиль","Воспоминания","Статистика","Календарь","Дневник"};String[] icons={"⌂","◯","♡","▥","▦","▤"};
        for(int i=0;i<tabs.length;i++){final String tab=tabs[i];LinearLayout item=column();item.setGravity(Gravity.CENTER);item.setPadding(0,dp(4),0,dp(4));TextView ic=label(icons[i],19,SAGE,true,Typeface.DEFAULT);ic.setGravity(Gravity.CENTER);TextView tx=label(tabs[i],8,MUTED,false,Typeface.DEFAULT);tx.setGravity(Gravity.CENTER);item.addView(ic);item.addView(tx);item.setOnClickListener(v->{feedback(v,false);navigate(tab);});nav.addView(item,new LinearLayout.LayoutParams(0,-2,1));}
        root.addView(nav);
    }

    private void navigate(String tab) { current=tab;showPage(tab); }
    private void showPage(String tab) {
        current=tab;content.removeAllViews();
        if(hiddenSections.contains(tab) && !"Главная".equals(tab) && !"Профиль".equals(tab) && !"Статистика".equals(tab)) { title("Раздел скрыт","Этот раздел выбран для быстрого скрытия.");margins(label("Его содержимое временно не показывается в обычной навигации.",13,MUTED,false,Typeface.DEFAULT),14);margins(action("Настройки приватности",()->navigate("Профиль"),true),0);return; }
        switch(tab){
            case "Главная":showHome();break;case "Дневник":showJournal();break;case "Календарь":showCalendar();break;case "Поддержка":showSupport();break;
            case "Профиль":showProfile();break;case "Статистика":showStats();break;case "Воспоминания":showMemories();break;case "Забота о себе":showCare();break;case "Цели и мечты":showGoals();break;case "Библиотека":showLibrary();break;
            default:showHome();
        }
        content.setAlpha(0f);content.setTranslationY(dp(7));content.animate().alpha(1f).translationY(0).setDuration(220).start();
    }
    private void title(String s,String sub) { TextView h=label(s,28,INK,false,Typeface.SERIF);h.setPadding(0,dp(4),0,dp(3));margins(h,2);if(sub!=null&&!sub.isEmpty()){TextView p=label(sub,13,MUTED,false,Typeface.DEFAULT);p.setLineSpacing(dp(2),1f);margins(p,13);} }
    private LinearLayout card() { LinearLayout c=column();c.setPadding(dp(16),dp(15),dp(16),dp(15));c.setBackground(solid(PAPER,23,LINE));c.setElevation(dp(1));c.setAlpha(0f);c.setTranslationY(dp(7));margins(c,12);c.animate().alpha(1f).translationY(0f).setDuration(260).start();return c; }
    private TextView action(String s,Runnable run,boolean primary) { TextView b=label(s,14,primary?WHITE:INK,true,Typeface.DEFAULT);b.setGravity(Gravity.CENTER);b.setPadding(dp(14),dp(13),dp(14),dp(13));b.setBackground(primary?gradient(SAGE,Color.rgb(Math.min(255,Color.red(SAGE)+25),Math.min(255,Color.green(SAGE)+23),Math.min(255,Color.blue(SAGE)+24)),GradientDrawable.Orientation.LEFT_RIGHT):solid(MINT,17,LINE));b.setOnClickListener(v->{feedback(v,primary);v.animate().scaleX(.985f).scaleY(.985f).setDuration(65).withEndAction(()->v.animate().scaleX(1f).scaleY(1f).setDuration(90).start()).start();run.run();});return b; }
    private TextView chip(String s,boolean active,Runnable run) { TextView t=label(s,12,active?WHITE:INK,false,Typeface.DEFAULT);t.setGravity(Gravity.CENTER);t.setPadding(dp(12),dp(9),dp(12),dp(9));t.setBackground(active?solid(SAGE,18,0):solid(MINT,18,LINE));t.setOnClickListener(v->{feedback(v,false);run.run();});return t; }
    private void headingIn(LinearLayout c,String s,int size) { TextView t=label(s,size,INK,true,Typeface.DEFAULT);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(8);c.addView(t,p); }

    private LinearLayout homeTile(String icon, String heading, String description, int background, int minHeight, Runnable run) {
        LinearLayout tile=column();
        tile.setPadding(dp(14),dp(14),dp(14),dp(14));
        tile.setMinimumHeight(dp(minHeight));
        tile.setBackground(solid(background,24,LINE));
        tile.setElevation(dp(1));
        TextView symbol=label(icon,27,SAGE_DARK,false,Typeface.SERIF);
        symbol.setGravity(Gravity.CENTER_VERTICAL);
        tile.addView(symbol,new LinearLayout.LayoutParams(-1,dp(36)));
        TextView title=label(heading,16,INK,true,Typeface.SERIF);
        title.setPadding(0,dp(7),0,dp(4));
        tile.addView(title);
        TextView sub=label(description,11,MUTED,false,Typeface.DEFAULT);
        sub.setLineSpacing(dp(2),1f);
        tile.addView(sub);
        tile.setOnClickListener(v->{feedback(v,false);v.animate().scaleX(.985f).scaleY(.985f).setDuration(70).withEndAction(()->v.animate().scaleX(1f).scaleY(1f).setDuration(100).start()).start();run.run();});
        return tile;
    }

    private void addCollageTile(LinearLayout column, LinearLayout tile, int bottom) {
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);
        lp.bottomMargin=dp(bottom);
        column.addView(tile,lp);
    }

    private void showHome() {
        title("Мой маленький мир ♡","Собирай здесь моменты, мысли и всё, что делает пространство твоим.");
        if(vaultProblem){LinearLayout warning=card();headingIn(warning,"Локальное хранилище недоступно",15);warning.addView(label("Не удалось расшифровать прежние данные. Я не буду перезаписывать их автоматически. Открой профиль и попробуй восстановить резервную копию.",12,MUTED,false,Typeface.DEFAULT));warning.addView(action("Открыть восстановление",()->navigate("Профиль"),true));}

        LinearLayout hero=card();
        hero.setBackground(gradient(SAGE_LIGHT,BG,GradientDrawable.Orientation.TL_BR));
        hero.addView(label("MY SAFE SPACE  ·  YOUR OWN LITTLE WORLD",9,SAGE_DARK,true,Typeface.DEFAULT));
        TextView greeting=label("Здесь можно быть собой. ♡",25,INK,false,Typeface.SERIF);
        greeting.setPadding(0,dp(8),0,dp(5));hero.addView(greeting);
        hero.addView(label(new SimpleDateFormat("EEEE, d MMMM",new Locale("ru")).format(new Date()),12,MUTED,false,Typeface.DEFAULT));
        addSpace(hero,12);
        TextView moon=label("☾",34,SAGE_DARK,true,Typeface.SERIF);moon.setGravity(Gravity.RIGHT);hero.addView(moon,new LinearLayout.LayoutParams(-1,dp(38)));moon.setShadowLayer(dp(12),0,0,SAGE);
        moon.animate().rotationBy(8f).setDuration(1800).withEndAction(()->moon.animate().rotationBy(-8f).setDuration(1800).start()).start();
        hero.addView(action("Я сегодня плакала  ·  ＋",()->showCryForm(),true));

        LinearLayout collage=row();
        collage.setGravity(Gravity.TOP);
        LinearLayout left=column(), right=column();
        LinearLayout.LayoutParams colLp=new LinearLayout.LayoutParams(0,-2,1f);
        colLp.rightMargin=dp(6);collage.addView(left,colLp);
        LinearLayout.LayoutParams rightLp=new LinearLayout.LayoutParams(0,-2,1f);
        rightLp.leftMargin=dp(6);collage.addView(right,rightLp);

        addCollageTile(left,homeTile("✎","Мои мысли","Дневник и страницы, которые хочется сохранить.",PAPER,160,()->navigate("Дневник")),12);
        addCollageTile(left,homeTile("♡","Воспоминания","Маленькие и большие моменты моей жизни.",MINT,146,()->navigate("Воспоминания")),12);
        addCollageTile(left,homeTile("☁","Забота о себе","Нежные ритуалы и звуки природы.",SAGE_LIGHT,150,()->navigate("Забота о себе")),12);
        addCollageTile(left,homeTile("✧","Цели и мечты","Идеи, желания и планы без спешки.",PAPER,138,()->navigate("Цели и мечты")),0);

        addCollageTile(right,homeTile("▦","Календарь слёз",cries.size()+" эпизодов · бережная история без оценок.",MINT,144,()->navigate("Календарь")),12);
        addCollageTile(right,homeTile("☾","Тихая поддержка","Когда хочется выдохнуть или рассказать о чём-то.",PAPER,165,()->navigate("Поддержка")),12);
        addCollageTile(right,homeTile("❧","Психология","Небольшая библиотека для самопознания.",SAGE_LIGHT,145,()->navigate("Библиотека")),12);
        addCollageTile(right,homeTile("♡","Моя история",""+journal.size()+" записей · "+memories.size()+" воспоминаний.",PAPER,130,()->navigate("Статистика")),0);

        LinearLayout.LayoutParams collageLp=new LinearLayout.LayoutParams(-1,-2);
        collageLp.bottomMargin=dp(12);content.addView(collage,collageLp);

        LinearLayout quote=card();
        quote.setBackground(gradient(PAPER,MINT,GradientDrawable.Orientation.LEFT_RIGHT));
        TextView quoteText=label("«Твоё пространство. Твои правила. Твой темп.»",16,SAGE_DARK,false,Typeface.SERIF);
        quoteText.setGravity(Gravity.CENTER);quoteText.setPadding(dp(8),dp(4),dp(8),dp(4));quote.addView(quoteText);
        TextView customize=action("Изменить эстетику  ·  Профиль",()->navigate("Профиль"),false);
        addSpace(quote,8);quote.addView(customize);

        LinearLayout sounds=card();
        headingIn(sounds,"Звуки природы",15);
        sounds.addView(label("Дождь или лес — можно включить фоном и остановить в любой момент.",12,MUTED,false,Typeface.DEFAULT));
        addSpace(sounds,8);
        LinearLayout soundRow=row();
        soundRow.addView(action("☂  Дождь",()->playNature(1),false),new LinearLayout.LayoutParams(0,-2,1));
        View soundGap=new View(this);soundRow.addView(soundGap,new LinearLayout.LayoutParams(dp(7),1));
        soundRow.addView(action("♧  Лес",()->playNature(2),false),new LinearLayout.LayoutParams(0,-2,1));
        sounds.addView(soundRow);addSpace(sounds,7);
        sounds.addView(action("Остановить звук",()->stopNature(),false));
    }

    private void showCryForm() { showCryForm(System.currentTimeMillis()); }
    private void showCryForm(long timestamp) {
        pendingCryTime=timestamp; selectedCauses.clear(); draftAttachments.clear(); draftIntensity=3; draftIntensityEnabled=false; attachmentTarget=null;
        content.removeAllViews(); title("Я сегодня плакала ♡","Один эпизод — одна отметка. Причины и подробности можно пропустить.");
        LinearLayout c=card(); headingIn(c,"Что могло стать причиной?",16); c.addView(label("Можно выбрать несколько вариантов или добавить свою причину.",12,MUTED,false,Typeface.DEFAULT)); addSpace(c,8);
        ArrayList<String> all=allCauses();
        for(int i=0;i<all.size();i+=2){LinearLayout r=row();for(int j=i;j<Math.min(i+2,all.size());j++){String cause=all.get(j);TextView t=chip(cause,false,()->{});t.setOnClickListener(v->{feedback(v,false);if(selectedCauses.contains(cause))selectedCauses.remove(cause);else selectedCauses.add(cause);t.setBackground(solid(selectedCauses.contains(cause)?SAGE:MINT,18,selectedCauses.contains(cause)?0:LINE));t.setTextColor(selectedCauses.contains(cause)?WHITE:INK);});r.addView(t,new LinearLayout.LayoutParams(0,-2,1));if(j+1<Math.min(i+2,all.size())){View gap=new View(this);r.addView(gap,new LinearLayout.LayoutParams(dp(7),1));}}LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.bottomMargin=dp(6);c.addView(r,rp);}
        c.addView(action("＋ Добавить свою причину",()->addCustomCauseFromForm(),false));
        addSpace(c,10); headingIn(c,"Насколько тяжело было?",15); Switch intensitySwitch=new Switch(this);intensitySwitch.setText("Указать интенсивность (по желанию)");intensitySwitch.setTextColor(INK);intensitySwitch.setChecked(false);c.addView(intensitySwitch);
        TextView intensityValue=label("3 из 5 · можно выбрать позже",12,MUTED,false,Typeface.DEFAULT); c.addView(intensityValue);
        SeekBar intensity=new SeekBar(this);intensity.setMax(4);intensity.setProgress(2); if(android.os.Build.VERSION.SDK_INT>=21)intensity.setProgressTintList(android.content.res.ColorStateList.valueOf(SAGE));c.addView(intensity);
        intensity.setEnabled(false);intensitySwitch.setOnCheckedChangeListener((b,v)->{intensity.setEnabled(v);draftIntensityEnabled=v;intensityValue.setAlpha(v?1f:.5f);});
        intensity.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int progress,boolean from){draftIntensity=progress+1;intensityValue.setText(draftIntensity+" из 5 · "+intensityText(draftIntensity));}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}});
        addSpace(c,10);headingIn(c,"Хочешь рассказать подробнее?",15);EditText details=makeEdit("Что произошло? Можно оставить пустым.",3);c.addView(details);
        addSpace(c,10);headingIn(c,"Фото и аудио",15);attachmentCountLabel=label("Вложений пока нет",12,MUTED,false,Typeface.DEFAULT);c.addView(attachmentCountLabel);addSpace(c,6);
        c.addView(action("＋ Добавить несколько фото",()->pickCryFiles(true),false));addSpace(c,6);c.addView(action("♫ Добавить аудиофайлы",()->pickCryFiles(false),false));addSpace(c,6);c.addView(action("● Записать голос прямо здесь",()->startAudioRecording(null),false));
        addSpace(c,13);c.addView(action("Сохранить эпизод",()->{StringBuilder b=new StringBuilder();for(String v:selectedCauses){if(b.length()>0)b.append(", ");b.append(v);}long when=pendingCryTime>0?pendingCryTime:System.currentTimeMillis();CryRecord record=new CryRecord(when,b.toString(),details.getText().toString().trim());record.intensity=draftIntensityEnabled?draftIntensity:0;record.attachments.addAll(draftAttachments);cries.add(0,record);pendingCryTime=-1L;draftAttachments.clear();saveData();showSuccess();},true));addSpace(c,7);c.addView(action("Отмена",()->navigate("Главная"),false));
    }
    private ArrayList<String> allCauses(){ArrayList<String> a=new ArrayList<>();Collections.addAll(a,CAUSES);for(String x:customCauses)if(!a.contains(x))a.add(x);return a;}
    private String intensityText(int v){switch(v){case 1:return "немного тяжело";case 2:return "неприятно";case 3:return "очень грустно";case 4:return "сильно тяжело";default:return "невыносимо тяжело";}}
    private void addCustomCauseFromForm(){EditText e=makeEdit("Например: «Слишком много всего»",1);new AlertDialog.Builder(this).setTitle("Своя причина").setView(e).setNegativeButton("Отмена",null).setPositiveButton("Добавить",(d,w)->{String v=e.getText().toString().trim();if(v.isEmpty())return;if(!customCauses.contains(v))customCauses.add(v);selectedCauses.add(v);saveData();Toast.makeText(this,"Причина добавлена и выбрана для этого эпизода",Toast.LENGTH_SHORT).show();}).show();}
    private void pickCryFiles(boolean images){attachmentTarget=null;Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType(images?"image/*":"audio/*");i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);try{startActivityForResult(i,images?REQ_CRY_IMAGES:REQ_CRY_AUDIO);}catch(Exception e){Toast.makeText(this,"Не удалось открыть файлы",Toast.LENGTH_SHORT).show();}}
    private void pickCryFilesForRecord(boolean images,CryRecord target){attachmentTarget=target;Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType(images?"image/*":"audio/*");i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);try{startActivityForResult(i,images?REQ_CRY_IMAGES:REQ_CRY_AUDIO);}catch(Exception e){attachmentTarget=null;Toast.makeText(this,"Не удалось открыть файлы",Toast.LENGTH_SHORT).show();}}
    private void startAudioRecording(CryRecord target){
        recordingTarget=target;
        if(android.os.Build.VERSION.SDK_INT>=23 && checkSelfPermission("android.permission.RECORD_AUDIO")!=PackageManager.PERMISSION_GRANTED){
            pendingAudioRecordingPermission=true;
            requestPermissions(new String[]{"android.permission.RECORD_AUDIO"},7703);
            return;
        }
        beginAudioRecording();
    }
    private void beginAudioRecording(){
        try{
            File dir=new File(getCacheDir(),"recordings");if(!dir.exists()&&!dir.mkdirs())throw new IOException("Не удалось создать временную папку");
            activeRecordingFile=File.createTempFile("mss_voice_", ".m4a", dir);
            activeRecorder=android.os.Build.VERSION.SDK_INT>=31?new MediaRecorder(this):new MediaRecorder();
            activeRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            activeRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            activeRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            activeRecorder.setAudioEncodingBitRate(96000);
            activeRecorder.setAudioSamplingRate(44100);
            activeRecorder.setOutputFile(activeRecordingFile.getAbsolutePath());
            activeRecorder.prepare();activeRecorder.start();
            LinearLayout box=column();box.setPadding(dp(16),dp(14),dp(16),dp(8));
            TextView status=label("● Идёт запись…",16,SAGE_DARK,true,Typeface.DEFAULT);status.setGravity(Gravity.CENTER);box.addView(status);
            TextView hint=label("Когда закончишь, нажми «Сохранить аудио».",12,MUTED,false,Typeface.DEFAULT);hint.setGravity(Gravity.CENTER);box.addView(hint);
            recordingDialog=new AlertDialog.Builder(this).setTitle("Голосовая запись").setView(box).setCancelable(false)
                .setNegativeButton("Отменить",(d,w)->finishAudioRecording(false))
                .setPositiveButton("Сохранить аудио",(d,w)->finishAudioRecording(true)).create();
            recordingDialog.setOnCancelListener(d->finishAudioRecording(false));recordingDialog.show();
        }catch(Exception e){cleanupRecorder();Toast.makeText(this,"Не удалось начать запись: "+(e.getMessage()==null?"проверь микрофон":""),Toast.LENGTH_LONG).show();}
    }
    private void finishAudioRecording(boolean keep){
        File recorded=activeRecordingFile;
        try{
            if(activeRecorder!=null){if(keep)activeRecorder.stop();else{try{activeRecorder.stop();}catch(Exception ignored){}}}
            if(keep&&recorded!=null&&recorded.isFile()&&recorded.length()>0){
                byte[] plain;try(InputStream in=new java.io.FileInputStream(recorded);ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] b=new byte[8192];int n;while((n=in.read(b))>0)out.write(b,0,n);plain=out.toByteArray();}
                Attachment a=saveEncryptedAttachmentBytes(plain,"Голосовая запись.m4a","audio/mp4");
                if(recordingTarget!=null){recordingTarget.attachments.add(a);saveData();showCalendar();}
                else{draftAttachments.add(a);updateAttachmentCount();}
                Toast.makeText(this,"Аудиозапись сохранена",Toast.LENGTH_SHORT).show();
            }
        }catch(Exception e){Toast.makeText(this,"Запись не удалось сохранить. Попробуй ещё раз.",Toast.LENGTH_LONG).show();}
        finally{cleanupRecorder();if(recorded!=null&&recorded.exists())recorded.delete();recordingTarget=null;if(recordingDialog!=null){recordingDialog.dismiss();recordingDialog=null;}}
    }
    private void cleanupRecorder(){if(activeRecorder!=null){try{activeRecorder.reset();}catch(Exception ignored){}try{activeRecorder.release();}catch(Exception ignored){}activeRecorder=null;}if(activeRecordingFile!=null&&activeRecordingFile.exists())activeRecordingFile.delete();activeRecordingFile=null;}
    private Attachment saveEncryptedAttachmentBytes(byte[] plain,String name,String mime)throws Exception{
        Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.ENCRYPT_MODE,vaultKey());byte[] iv=cipher.getIV();byte[] encrypted=cipher.doFinal(plain);File dir=new File(getFilesDir(),"cry_media");if(!dir.exists()&&!dir.mkdirs())throw new IOException("Не удалось создать папку вложений");String file=UUID.randomUUID().toString()+".mss";try(FileOutputStream out=new FileOutputStream(new File(dir,file))){out.write(iv);out.write(encrypted);}return new Attachment(file,name,mime);
    }
    private void updateAttachmentCount(){if(attachmentCountLabel!=null)attachmentCountLabel.setText(draftAttachments.size()==0?"Вложений пока нет":"Прикреплено: "+draftAttachments.size()+" файл(ов)");}
    private Attachment saveEncryptedAttachment(Uri uri)throws Exception{
        byte[] plain;try(InputStream in=getContentResolver().openInputStream(uri);ByteArrayOutputStream out=new ByteArrayOutputStream()){if(in==null)throw new IOException("Файл недоступен");byte[] buf=new byte[8192];int n;while((n=in.read(buf))>0)out.write(buf,0,n);plain=out.toByteArray();}
        String name="Вложение";String mime=getContentResolver().getType(uri);String last=uri.getLastPathSegment();if(last!=null&&last.contains(":"))last=last.substring(last.lastIndexOf(':')+1);if(last!=null&&!last.isEmpty())name=last;return saveEncryptedAttachmentBytes(plain,name,mime==null?"application/octet-stream":mime);
    }
    private byte[] readDecryptedAttachment(Attachment a)throws Exception{File f=new File(new File(getFilesDir(),"cry_media"),a.fileName);byte[] all;try(InputStream in=new java.io.FileInputStream(f);ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] b=new byte[8192];int n;while((n=in.read(b))>0)out.write(b,0,n);all=out.toByteArray();}if(all.length<13)throw new IOException("Повреждённое вложение");byte[] iv=new byte[12],enc=new byte[all.length-12];System.arraycopy(all,0,iv,0,12);System.arraycopy(all,12,enc,0,enc.length);Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.DECRYPT_MODE,vaultKey(),new GCMParameterSpec(128,iv));return cipher.doFinal(enc);}
    private void displayAttachments(LinearLayout target,CryRecord record){if(record.attachments==null||record.attachments.isEmpty())return;headingIn(target,"Вложения",13);for(Attachment a:new ArrayList<>(record.attachments)){if(a.mime!=null&&a.mime.startsWith("image/")){try{byte[] bytes=readDecryptedAttachment(a);Bitmap bitmap=BitmapFactory.decodeByteArray(bytes,0,bytes.length);if(bitmap!=null){ImageView image=new ImageView(this);image.setImageBitmap(bitmap);image.setScaleType(ImageView.ScaleType.CENTER_CROP);target.addView(image,new LinearLayout.LayoutParams(-1,dp(150)));image.setOnClickListener(v->{android.widget.ImageView full=new ImageView(this);full.setImageBitmap(bitmap);full.setAdjustViewBounds(true);new AlertDialog.Builder(this).setView(full).setPositiveButton("Закрыть",null).show();});}}catch(Exception e){target.addView(label("Не удалось открыть фото",11,MUTED,false,Typeface.DEFAULT));}}else{target.addView(action("♫  "+a.displayName,()->playCryAudio(a),false));}target.addView(action("Удалить вложение",()->new AlertDialog.Builder(this).setMessage("Убрать этот файл из эпизода?").setNegativeButton("Отмена",null).setPositiveButton("Удалить",(d,w)->{record.attachments.remove(a);File f=new File(new File(getFilesDir(),"cry_media"),a.fileName);if(f.exists())f.delete();saveData();showCalendar();}).show(),false));}}
    private void playCryAudio(Attachment a){try{byte[] bytes=readDecryptedAttachment(a);File temp=File.createTempFile("mss_audio_",".tmp",getCacheDir());try(FileOutputStream out=new FileOutputStream(temp)){out.write(bytes);}MediaPlayer player=new MediaPlayer();player.setDataSource(temp.getAbsolutePath());player.setOnCompletionListener(mp->{mp.release();temp.delete();});player.prepare();player.start();Toast.makeText(this,"Аудио воспроизводится",Toast.LENGTH_SHORT).show();}catch(Exception e){Toast.makeText(this,"Не удалось воспроизвести аудио",Toast.LENGTH_SHORT).show();}}
    private void showSuccess(){content.removeAllViews();LinearLayout c=card();c.setGravity(Gravity.CENTER);TextView icon=label("♡",54,SAGE,true,Typeface.SERIF);icon.setGravity(Gravity.CENTER);c.addView(icon);TextView t=label("Твоя отметка сохранена",23,INK,false,Typeface.SERIF);t.setGravity(Gravity.CENTER);t.setPadding(0,dp(11),0,dp(7));c.addView(t);TextView p=label(randomSupportMessage(),14,MUTED,false,Typeface.DEFAULT);p.setGravity(Gravity.CENTER);p.setPadding(dp(8),0,dp(8),0);c.addView(p);icon.animate().scaleX(1.18f).scaleY(1.18f).setDuration(220).withEndAction(()->icon.animate().scaleX(1f).scaleY(1f).setDuration(260).start()).start();addSpace(c,18);c.addView(action("Посмотреть календарь",()->navigate("Календарь"),true));addSpace(c,7);c.addView(action("На главную",()->navigate("Главная"),false));}
    private String randomSupportMessage(){String[] m={"Ты не обязана всегда быть сильной. Дай себе время.","Можно грустить. Твои чувства имеют значение.","Спасибо, что доверила этому месту часть своей истории.","Не нужно торопиться. Ты заслуживаешь нежности.","Ты сделала достаточно на сегодня. ♡"};return m[new java.util.Random().nextInt(m.length)];}

    private void showCalendar() {
        title("Календарь слёз","Светящиеся точки отмечают дни с эпизодами. Точка — это запись, не оценка дня.");LinearLayout c=card();LinearLayout monthRow=row();TextView prev=label("‹",30,SAGE_DARK,true,Typeface.SERIF);prev.setGravity(Gravity.CENTER);monthRow.addView(prev,new LinearLayout.LayoutParams(dp(42),dp(42)));TextView month=label(monthName(visibleMonth),18,INK,true,Typeface.SERIF);month.setGravity(Gravity.CENTER);monthRow.addView(month,new LinearLayout.LayoutParams(0,-2,1));TextView next=label("›",30,SAGE_DARK,true,Typeface.SERIF);next.setGravity(Gravity.CENTER);monthRow.addView(next,new LinearLayout.LayoutParams(dp(42),dp(42)));c.addView(monthRow);
        String historyFilterLabel=historyCauseFilter.isEmpty()?"Все причины":historyCauseFilter.size()==1?historyCauseFilter.iterator().next():"Выбрано причин: "+historyCauseFilter.size();c.addView(action("Фильтр истории · "+historyFilterLabel,()->chooseHistoryCauses(),false));
        prev.setOnClickListener(v->{feedback(v,false);visibleMonth.add(Calendar.MONTH,-1);selectedDate.setTime(visibleMonth.getTime());showCalendar();});next.setOnClickListener(v->{feedback(v,false);Calendar now=Calendar.getInstance();Calendar target=(Calendar)visibleMonth.clone();target.add(Calendar.MONTH,1);if(target.compareTo(now)<=0){visibleMonth=target;selectedDate.setTime(visibleMonth.getTime());showCalendar();}});
        LinearLayout week=row();String[] days={"Пн","Вт","Ср","Чт","Пт","Сб","Вс"};for(String d:days){TextView t=label(d,11,MUTED,true,Typeface.DEFAULT);t.setGravity(Gravity.CENTER);week.addView(t,new LinearLayout.LayoutParams(0,dp(32),1));}c.addView(week);
        Calendar first=(Calendar)visibleMonth.clone();first.set(Calendar.DAY_OF_MONTH,1);int offset=(first.get(Calendar.DAY_OF_WEEK)+5)%7;int count=first.getActualMaximum(Calendar.DAY_OF_MONTH);int cells=((offset+count+6)/7)*7;
        for(int w=0;w<cells/7;w++){LinearLayout line=row();for(int col=0;col<7;col++){int day=w*7+col-offset+1;FrameLayout cell=new FrameLayout(this);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(47),1);if(day>0&&day<=count){Calendar date=(Calendar)visibleMonth.clone();date.set(Calendar.DAY_OF_MONTH,day);String key=dayKey(date);int amount=recordsFor(key).size();boolean has=amount>0;boolean chosen=dayKey(selectedDate).equals(key);LinearLayout inner=column();inner.setGravity(Gravity.CENTER);inner.setBackground(solid(chosen?SAGE_LIGHT:Color.TRANSPARENT,13,chosen?SAGE:0));TextView n=label(String.valueOf(day),13,has?SAGE_DARK:INK,has,Typeface.DEFAULT);n.setGravity(Gravity.CENTER);inner.addView(n);TextView dot=label(has?"●":" ",9,SAGE,true,Typeface.DEFAULT);dot.setGravity(Gravity.CENTER);if(has)dot.setShadowLayer(dp(7),0,0,SAGE);inner.addView(dot);cell.addView(inner,new FrameLayout.LayoutParams(-1,-1));cell.setOnClickListener(v->{feedback(v,false);selectedDate.setTime(date.getTime());showCalendar();});}line.addView(cell,lp);}c.addView(line);}
        c.addView(label("●  день с отмеченными эпизодами",11,SAGE_DARK,false,Typeface.DEFAULT));
        LinearLayout dayCard=card();String selectedLabel=new SimpleDateFormat("d MMMM yyyy",new Locale("ru")).format(selectedDate.getTime());headingIn(dayCard,selectedLabel,16);ArrayList<CryRecord> records=recordsFor(dayKey(selectedDate));if(records.isEmpty())dayCard.addView(label("В этот день пока нет отметок.",13,MUTED,false,Typeface.DEFAULT));else{dayCard.addView(label("Эпизодов: "+records.size(),12,SAGE_DARK,true,Typeface.DEFAULT));for(CryRecord r:records){LinearLayout item=column();item.setPadding(0,dp(8),0,dp(8));String when=new SimpleDateFormat("HH:mm",new Locale("ru")).format(new Date(r.time));headingIn(item,"Эпизод · "+when,14);item.addView(label("Причины: "+(r.causes.isEmpty()?"не указаны":r.causes),12,INK,false,Typeface.DEFAULT));item.addView(label("Интенсивность: "+(r.intensity>0?r.intensity+" из 5 · "+intensityText(r.intensity):"не указана"),12,MUTED,false,Typeface.DEFAULT));if(!r.note.isEmpty()){TextView note=label(r.note,13,INK,false,Typeface.DEFAULT);note.setPadding(0,dp(4),0,dp(4));item.addView(note);}displayAttachments(item,r);dayCard.addView(item);dayCard.addView(action("Редактировать эпизод",()->editCry(r),false));dayCard.addView(action("＋ Добавить фото к эпизоду",()->pickCryFilesForRecord(true,r),false));dayCard.addView(action("♫ Добавить аудио к эпизоду",()->pickCryFilesForRecord(false,r),false));dayCard.addView(action("● Записать голос к эпизоду",()->startAudioRecording(r),false));dayCard.addView(action("Удалить эпизод",()->confirmDeleteCry(r),false));View div=new View(this);div.setBackgroundColor(LINE);dayCard.addView(div,new LinearLayout.LayoutParams(-1,dp(1)));}}
        LinearLayout actions=card();headingIn(actions,"Добавить отметку",15);actions.addView(action("Я сегодня плакала · +1 эпизод",()->{Calendar chosen=(Calendar)selectedDate.clone();if(dayKey(chosen).equals(dayKey(Calendar.getInstance())))chosen=Calendar.getInstance();else{chosen.set(Calendar.HOUR_OF_DAY,12);chosen.set(Calendar.MINUTE,0);}showCryForm(chosen.getTimeInMillis());},true));
    }
    private void confirmDeleteCry(CryRecord r){new AlertDialog.Builder(this).setTitle("Удалить эпизод?").setMessage("Эту запись и её вложения нельзя будет вернуть.").setNegativeButton("Отмена",null).setPositiveButton("Удалить",(d,w)->{deleteCryAttachments(r);cries.remove(r);saveData();showCalendar();}).show();}
    private void deleteCryAttachments(CryRecord r){if(r.attachments!=null)for(Attachment a:r.attachments){File f=new File(new File(getFilesDir(),"cry_media"),a.fileName);if(f.exists())f.delete();}}
    private void editCry(CryRecord record) {
        LinearLayout box=column();box.setPadding(dp(12),dp(8),dp(12),dp(4));long[] editedTime={record.time};TextView timeLabel=label("Дата и время: "+new SimpleDateFormat("d MMM yyyy · HH:mm",new Locale("ru")).format(new Date(editedTime[0])),12,MUTED,false,Typeface.DEFAULT);box.addView(timeLabel);box.addView(action("Изменить дату и время",()->{Calendar initial=Calendar.getInstance();initial.setTimeInMillis(editedTime[0]);DatePickerDialog dateDialog=new DatePickerDialog(this,(dpicker,y,m,day)->{Calendar picked=Calendar.getInstance();picked.setTimeInMillis(editedTime[0]);picked.set(Calendar.YEAR,y);picked.set(Calendar.MONTH,m);picked.set(Calendar.DAY_OF_MONTH,day);new TimePickerDialog(this,(tpicker,h,minute)->{picked.set(Calendar.HOUR_OF_DAY,h);picked.set(Calendar.MINUTE,minute);picked.set(Calendar.SECOND,0);editedTime[0]=picked.getTimeInMillis();timeLabel.setText("Дата и время: "+new SimpleDateFormat("d MMM yyyy · HH:mm",new Locale("ru")).format(new Date(editedTime[0])));},picked.get(Calendar.HOUR_OF_DAY),picked.get(Calendar.MINUTE),true).show();},initial.get(Calendar.YEAR),initial.get(Calendar.MONTH),initial.get(Calendar.DAY_OF_MONTH));dateDialog.getDatePicker().setMaxDate(System.currentTimeMillis());dateDialog.show();},false));EditText reasons=makeEdit("Причины через запятую",2);reasons.setText(record.causes);box.addView(reasons);EditText note=makeEdit("Подробности",3);note.setText(record.note);box.addView(note);Switch enabled=new Switch(this);enabled.setText("Указать интенсивность");enabled.setTextColor(INK);enabled.setChecked(record.intensity>0);box.addView(enabled);SeekBar bar=new SeekBar(this);bar.setMax(4);bar.setProgress(Math.max(0,record.intensity-1));bar.setEnabled(record.intensity>0);box.addView(bar);enabled.setOnCheckedChangeListener((b,v)->bar.setEnabled(v));
        new AlertDialog.Builder(this).setTitle("Изменить эпизод").setView(box).setNegativeButton("Отмена",null).setNeutralButton("Удалить",(d,w)->confirmDeleteCry(record)).setPositiveButton("Сохранить",(d,w)->{record.time=editedTime[0];selectedDate.setTimeInMillis(record.time);visibleMonth.setTimeInMillis(record.time);visibleMonth.set(Calendar.DAY_OF_MONTH,1);record.causes=reasons.getText().toString().trim();record.note=note.getText().toString().trim();record.intensity=enabled.isChecked()?bar.getProgress()+1:0;saveData();showCalendar();}).show();
    }
    private String monthName(Calendar c){return new SimpleDateFormat("LLLL yyyy",new Locale("ru")).format(c.getTime());}
    private String dayKey(Calendar c){return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(c.getTime());}
    private boolean hasCry(String key){for(CryRecord r:cries)if(r.day().equals(key))return true;return false;}
    private ArrayList<CryRecord> recordsFor(String key){ArrayList<CryRecord> out=new ArrayList<>();for(CryRecord r:cries){if(!r.day().equals(key))continue;if(!historyCauseFilter.isEmpty()){boolean match=false;for(String cause:r.causes.split(","))if(historyCauseFilter.contains(cause.trim())){match=true;break;}if(!match)continue;}out.add(r);}return out;}
    private void chooseHistoryCauses(){ArrayList<String> all=allCauses();String[] labels=all.toArray(new String[0]);boolean[] checked=new boolean[labels.length];for(int i=0;i<labels.length;i++)checked[i]=historyCauseFilter.contains(labels[i]);new AlertDialog.Builder(this).setTitle("Причины в истории").setMultiChoiceItems(labels,checked,(d,w,v)->checked[w]=v).setNeutralButton("Все причины",(d,w)->{historyCauseFilter.clear();showCalendar();}).setNegativeButton("Отмена",null).setPositiveButton("Применить",(d,w)->{historyCauseFilter.clear();for(int i=0;i<labels.length;i++)if(checked[i])historyCauseFilter.add(labels[i]);showCalendar();}).show();}
    private int countAllCryDays(){HashSet<String> days=new HashSet<>();for(CryRecord r:cries)days.add(r.day());return days.size();}
    private int countThisMonth(){Calendar now=Calendar.getInstance();HashSet<String> days=new HashSet<>();for(CryRecord r:cries){Calendar c=Calendar.getInstance();c.setTimeInMillis(r.time);if(c.get(Calendar.YEAR)==now.get(Calendar.YEAR)&&c.get(Calendar.MONTH)==now.get(Calendar.MONTH))days.add(r.day());}return days.size();}

    private void showJournal() {
        title("Дневник","Твои мысли. В твоём темпе. Можно писать совсем немного.");LinearLayout c=card();headingIn(c,"Новая запись",16);EditText titleField=makeEdit("Название (необязательно)",1);c.addView(titleField);addSpace(c,7);EditText body=makeEdit("Что хочется сохранить?",4);c.addView(body);addSpace(c,7);c.addView(action("🎙  Надиктовать текст",()->startVoice(body),false));addSpace(c,8);c.addView(action("Сохранить запись",()->{String s=body.getText().toString().trim();if(s.isEmpty()){Toast.makeText(this,"Напиши хотя бы пару слов",Toast.LENGTH_SHORT).show();return;}journal.add(0,new JournalEntry(System.currentTimeMillis(),titleField.getText().toString().trim(),s));saveData();hideKeyboard(body);navigate("Дневник");Toast.makeText(this,"Запись сохранена",Toast.LENGTH_SHORT).show();},true));
        LinearLayout history=card();headingIn(history,"Твои страницы",16);if(journal.isEmpty())history.addView(label("Здесь появятся твои записи.",13,MUTED,false,Typeface.DEFAULT));else for(int i=0;i<journal.size();i++){JournalEntry e=journal.get(i);LinearLayout entry=column();entry.setPadding(dp(2),dp(8),dp(2),dp(10));String when=new SimpleDateFormat("d MMMM · HH:mm",new Locale("ru")).format(new Date(e.time));entry.addView(label(e.title.isEmpty()?when:e.title,16,INK,true,Typeface.SERIF));if(!e.title.isEmpty())entry.addView(label(when,10,MUTED,false,Typeface.DEFAULT));TextView text=label(e.note,13,INK,false,Typeface.DEFAULT);text.setLineSpacing(dp(3),1f);text.setPadding(0,dp(6),0,0);entry.addView(text);history.addView(entry);if(i<journal.size()-1){View divider=new View(this);divider.setBackgroundColor(LINE);history.addView(divider,new LinearLayout.LayoutParams(-1,dp(1)));}} }

    private void showMemories() {
        title("Мои воспоминания","Сохраняй моменты, к которым захочется вернуться.");LinearLayout c=card();headingIn(c,"Сохранить воспоминание",16);EditText name=makeEdit("Название момента",1);c.addView(name);addSpace(c,7);Spinner type=new Spinner(this);String[] choices=MEMORY_TYPES;type.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,choices));c.addView(type);addSpace(c,7);EditText note=makeEdit("Почему это важно для тебя?",3);c.addView(note);addSpace(c,8);c.addView(action("Сохранить",()->{String n=name.getText().toString().trim();if(n.isEmpty())n="Без названия";memories.add(0,new MemoryEntry(System.currentTimeMillis(),String.valueOf(type.getSelectedItem()),n,note.getText().toString().trim()));saveData();navigate("Воспоминания");},true));
        LinearLayout list=card();headingIn(list,"Коллекция моментов",16);if(memories.isEmpty())list.addView(label("Пока здесь тихо. Можешь сохранить первый момент.",13,MUTED,false,Typeface.DEFAULT));else for(MemoryEntry m:memories){LinearLayout item=column();item.setPadding(0,dp(8),0,dp(10));item.addView(label(m.type+"  ·  "+new SimpleDateFormat("d MMM yyyy",new Locale("ru")).format(new Date(m.time)),10,SAGE_DARK,true,Typeface.DEFAULT));item.addView(label(m.title,17,INK,true,Typeface.SERIF));if(!m.note.isEmpty())item.addView(label(m.note,13,MUTED,false,Typeface.DEFAULT));list.addView(item);list.addView(action("Удалить воспоминание",()->new AlertDialog.Builder(this).setMessage("Удалить этот момент?").setNegativeButton("Отмена",null).setPositiveButton("Удалить",(d,w)->{memories.remove(m);saveData();navigate("Воспоминания");}).show(),false));}
    }

    private void showStats() {
        title("Статистика","Данные показывают только то, что ты отметила в приложении — это не оценка твоего состояния.");
        LinearLayout range=card();headingIn(range,"Период",14);LinearLayout rr=row();for(int d:new int[]{7,30,365}){String text=d==7?"Неделя":d==30?"Месяц":"Год";rr.addView(chip(text,statsDays==d,()->{statsDays=d;showStats();}),new LinearLayout.LayoutParams(0,-2,1));}range.addView(rr);
        LinearLayout filter=card();headingIn(filter,"Фильтр причин",14);String filterLabel=statsCauseFilter.isEmpty()?"Все причины":statsCauseFilter.size()==1?statsCauseFilter.iterator().next():"Выбрано: "+statsCauseFilter.size();filter.addView(action("Выбрать причины · "+filterLabel,()->chooseStatsCauses(),false));
        ArrayList<CryRecord> filtered=filteredRecords();Calendar rangeStart=Calendar.getInstance();rangeStart.set(Calendar.HOUR_OF_DAY,0);rangeStart.set(Calendar.MINUTE,0);rangeStart.set(Calendar.SECOND,0);rangeStart.set(Calendar.MILLISECOND,0);rangeStart.add(Calendar.DAY_OF_YEAR,-(statsDays-1));long rangeStartMillis=rangeStart.getTimeInMillis();ArrayList<CryRecord> inRange=new ArrayList<>();for(CryRecord r:filtered)if(r.time>=rangeStartMillis)inRange.add(r);filtered=inRange;int days=countUniqueDays(filtered);double average=0;int n=0;LinkedHashMap<String,Integer> counts=new LinkedHashMap<>();for(CryRecord r:filtered){if(r.intensity>0){average+=r.intensity;n++;}for(String raw:r.causes.split(",")){String v=raw.trim();if(!v.isEmpty())counts.put(v,counts.containsKey(v)?counts.get(v)+1:1);}}
        LinearLayout metrics=card();headingIn(metrics,"Твоя история",15);metrics.addView(label("Эпизодов: "+filtered.size()+"  ·  Дней с отметками: "+days,14,INK,true,Typeface.DEFAULT));metrics.addView(label("Средняя интенсивность: "+(n==0?"нет данных":String.format(Locale.getDefault(),"%.1f из 5",average/n)),13,MUTED,false,Typeface.DEFAULT));String top="Пока нет выбранных причин";int max=0;for(String k:counts.keySet())if(counts.get(k)>max){max=counts.get(k);top=k;}metrics.addView(label("Чаще всего: "+(max==0?"не указано":top+" · "+max),13,MUTED,false,Typeface.DEFAULT));
        LinearLayout graph=card();headingIn(graph,"Линейный график",15);LinearLayout modes=row();modes.addView(chip("Эпизоды",statsMetric.equals("episodes"),()->{statsMetric="episodes";showStats();}),new LinearLayout.LayoutParams(0,-2,1));modes.addView(chip("Интенсивность",statsMetric.equals("intensity"),()->{statsMetric="intensity";showStats();}),new LinearLayout.LayoutParams(0,-2,1));graph.addView(modes);float[] values=buildGraphValues(filtered,statsDays,statsMetric);CryGraphView view=new CryGraphView(this,values,SAGE,MUTED,LINE);graph.addView(view,new LinearLayout.LayoutParams(-1,dp(190)));graph.addView(label(statsMetric.equals("episodes")?"Число эпизодов за день":"Средняя интенсивность эпизодов за день",11,MUTED,false,Typeface.DEFAULT));
        LinearLayout gaps=card();if(hideGapStats){headingIn(gaps,"Периоды без отметок скрыты",14);gaps.addView(label("Этот раздел можно снова включить в настройках.",12,MUTED,false,Typeface.DEFAULT));}else{headingIn(gaps,"Периоды без отметок",14);String gap=gapSummary();gaps.addView(label(gap,12,MUTED,false,Typeface.DEFAULT));gaps.addView(label("Отсутствие отметок не означает автоматически, что тебе было хорошо или плохо.",11,MUTED,false,Typeface.DEFAULT));}
        LinearLayout total=card();headingIn(total,"Твоё пространство",15);total.addView(label(cries.size()+" эпизодов · "+journal.size()+" записей · "+memories.size()+" воспоминаний · "+goals.size()+" целей",13,MUTED,false,Typeface.DEFAULT));total.addView(action("Открыть календарь",()->navigate("Календарь"),false));
    }
    private ArrayList<CryRecord> filteredRecords(){ArrayList<CryRecord> out=new ArrayList<>();for(CryRecord r:cries){if(statsCauseFilter.isEmpty()){out.add(r);continue;}for(String c:r.causes.split(","))if(statsCauseFilter.contains(c.trim())){out.add(r);break;}}return out;}
    private int countUniqueDays(ArrayList<CryRecord> list){HashSet<String>s=new HashSet<>();for(CryRecord r:list)s.add(r.day());return s.size();}
    private float[] buildGraphValues(ArrayList<CryRecord> list,int count,String metric){float[] values=new float[count];Calendar today=Calendar.getInstance();today.set(Calendar.HOUR_OF_DAY,0);today.set(Calendar.MINUTE,0);today.set(Calendar.SECOND,0);today.set(Calendar.MILLISECOND,0);for(int i=0;i<count;i++){Calendar d=(Calendar)today.clone();d.add(Calendar.DAY_OF_YEAR,-(count-1-i));String key=dayKey(d);int total=0;float sum=0;for(CryRecord r:list)if(r.day().equals(key)){if("episodes".equals(metric))total++;else if(r.intensity>0){sum+=r.intensity;total++;}}values[i]=total==0?("episodes".equals(metric)?0f:Float.NaN):("episodes".equals(metric)?total:sum/total);}return values;}
    private void chooseStatsCauses(){ArrayList<String> all=allCauses();String[] labels=all.toArray(new String[0]);boolean[] checked=new boolean[labels.length];for(int i=0;i<labels.length;i++)checked[i]=statsCauseFilter.contains(labels[i]);new AlertDialog.Builder(this).setTitle("Причины для графика").setMultiChoiceItems(labels,checked,(d,w,v)->checked[w]=v).setNeutralButton("Все",(d,w)->{statsCauseFilter.clear();showStats();}).setNegativeButton("Отмена",null).setPositiveButton("Применить",(d,w)->{statsCauseFilter.clear();for(int i=0;i<labels.length;i++)if(checked[i])statsCauseFilter.add(labels[i]);showStats();}).show();}
    private String gapSummary(){if(cries.isEmpty())return "Пока нет отметок — периоды ещё не рассчитываются.";HashSet<String> days=new HashSet<>();for(CryRecord r:cries)days.add(r.day());ArrayList<String> sorted=new ArrayList<>(days);Collections.sort(sorted);try{java.text.SimpleDateFormat f=new java.text.SimpleDateFormat("yyyy-MM-dd",Locale.US);Calendar first=Calendar.getInstance();first.setTime(f.parse(sorted.get(0)));Calendar lastMarked=Calendar.getInstance();lastMarked.setTime(f.parse(sorted.get(0)));int currentGap=0,longest=0;String longestRange="";for(int i=1;i<sorted.size();i++){Calendar next=Calendar.getInstance();next.setTime(f.parse(sorted.get(i)));int diff=(int)((next.getTimeInMillis()-lastMarked.getTimeInMillis())/86400000L)-1;if(diff>longest){longest=diff;Calendar from=(Calendar)lastMarked.clone();from.add(Calendar.DAY_OF_YEAR,1);Calendar to=(Calendar)next.clone();to.add(Calendar.DAY_OF_YEAR,-1);longestRange=new SimpleDateFormat("d MMM",new Locale("ru")).format(from.getTime())+" — "+new SimpleDateFormat("d MMM",new Locale("ru")).format(to.getTime());}lastMarked=next;}Calendar today=Calendar.getInstance();today.set(Calendar.HOUR_OF_DAY,0);today.set(Calendar.MINUTE,0);today.set(Calendar.SECOND,0);currentGap=Math.max(0,(int)((today.getTimeInMillis()-lastMarked.getTimeInMillis())/86400000L));if(currentGap>longest){longest=currentGap;Calendar from=(Calendar)lastMarked.clone();from.add(Calendar.DAY_OF_YEAR,1);longestRange=new SimpleDateFormat("d MMM",new Locale("ru")).format(from.getTime())+" — сейчас";}return "Самый длинный период без отметок: "+longest+" дн."+(longestRange.isEmpty()?"":" ("+longestRange+")")+". Сейчас без отметок: "+currentGap+" дн.";}catch(Exception e){return "Периоды будут рассчитаны после появления истории.";}}
    private void manageCustomCauses(){content.removeAllViews();title("Мои причины","Создавай собственные теги для личных записей.");LinearLayout c=card();headingIn(c,"Добавить причину",15);EditText add=makeEdit("Название новой причины",1);c.addView(add);c.addView(action("Добавить",()->{String v=add.getText().toString().trim();if(!v.isEmpty()&&!customCauses.contains(v)){customCauses.add(v);saveData();navigate("Профиль");}},true));for(String cause:new ArrayList<>(customCauses)){LinearLayout r=row();r.addView(label(cause,13,INK,false,Typeface.DEFAULT),new LinearLayout.LayoutParams(0,-2,1));r.addView(action("Переименовать",()->renameCause(cause),false));r.addView(action("Удалить",()->new AlertDialog.Builder(this).setMessage("Удалить причину из списка? Ранее сохранённые записи останутся без изменений.").setNegativeButton("Отмена",null).setPositiveButton("Удалить",(d,w)->{customCauses.remove(cause);saveData();navigate("Профиль");}).show(),false));c.addView(r);}if(customCauses.isEmpty())c.addView(label("Собственных тегов пока нет.",12,MUTED,false,Typeface.DEFAULT));c.addView(action("Назад к настройкам",()->navigate("Профиль"),false));}
    private void renameCause(String old){EditText e=makeEdit("Новое название",1);e.setText(old);new AlertDialog.Builder(this).setTitle("Переименовать причину").setView(e).setNegativeButton("Отмена",null).setPositiveButton("Сохранить",(d,w)->{String v=e.getText().toString().trim();if(v.isEmpty()||v.equals(old))return;customCauses.remove(old);customCauses.add(v);for(CryRecord r:cries){ArrayList<String> parts=new ArrayList<>();for(String c:r.causes.split(",")){String t=c.trim();parts.add(t.equals(old)?v:t);}r.causes=android.text.TextUtils.join(", ",parts);}saveData();navigate("Профиль");}).show();}

    private void showSupport() {
        title("Я рядом ♡","Локальный помощник поддержки. Здесь нет подключения к ИИ-сервису.");LinearLayout c=card();TextView welcome=label("Привет. Можешь рассказать, что произошло. Я не буду тебя осуждать и не стану торопить.",14,INK,false,Typeface.DEFAULT);welcome.setPadding(dp(13),dp(13),dp(13),dp(13));welcome.setBackground(solid(MINT,17,LINE));c.addView(welcome);
        String[] prompts={"Мне грустно","Я тревожусь","Я чувствую одиночество","Мне нужно успокоиться","Я не хочу сейчас ничего объяснять"};for(String prompt:prompts){LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=dp(7);c.addView(chip(prompt,false,()->{addChatLine(c,"Ты: "+prompt,false);addChatLine(c,"Рядом: "+reply(prompt),true);}),lp);}
        EditText input=makeEdit("Написать сообщение…",3);LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,-2);ip.topMargin=dp(10);c.addView(input,ip);c.addView(action("🎙  Голосовой ввод",()->startVoice(input),false));addSpace(c,7);c.addView(action("Отправить",()->{String s=input.getText().toString().trim();if(s.isEmpty())return;addChatLine(c,"Ты: "+s,false);addChatLine(c,"Рядом: "+reply(s),true);input.setText("");hideKeyboard(input);},true));
        LinearLayout disclaimer=card();headingIn(disclaimer,"Важно",14);disclaimer.addView(label("Этот локальный помощник использует заранее подготовленные ответы и не заменяет живого человека, психолога или экстренную помощь. Если есть непосредственная опасность, обратись к человеку рядом или в местную экстренную службу.",12,MUTED,false,Typeface.DEFAULT));
    }
    private void addChatLine(LinearLayout c,String s,boolean bot){TextView t=label(s,13,INK,false,Typeface.DEFAULT);t.setPadding(dp(12),dp(10),dp(12),dp(10));t.setLineSpacing(dp(2),1f);t.setBackground(solid(bot?MINT:BG,15,LINE));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(bot?-1:dp(285),-2);p.topMargin=dp(7);if(!bot)p.gravity=Gravity.RIGHT;c.addView(t,p);}
    private String reply(String s){String x=s.toLowerCase(new Locale("ru"));if(x.contains("трев")||x.contains("успоко"))return "Попробуй почувствовать стопы на полу и спокойно выдохнуть. Не нужно делать это идеально. Просто побудь здесь.";if(x.contains("одиноч"))return "Одиночество может быть тяжёлым. Есть ли безопасный человек, которому можно написать: «Мне сейчас нужна компания»?";if(x.contains("груст")||x.contains("плач"))return "Мне жаль, что сейчас больно. Не нужно останавливать слёзы или объяснять их. Может помочь вода, плед или немного тишины.";if(x.contains("не хочу"))return "Хорошо. Не нужно ничего объяснять. Можно просто немного побыть в тишине.";return "Я тебя слышу. Не обязательно сразу искать решение. Хочешь рассказать чуть больше или выбрать один маленький шаг на сейчас?";}

    private void showCare() {
        title("Забота о себе","Не список обязанностей, а идеи, которые можно выбирать.");String[] ideas={"Выпить стакан воды","Открыть окно и подышать","Укутаться в плед","Послушать дождь или лес","Немного потянуться","Отдохнуть от телефона","Написать безопасному человеку"};
        LinearLayout c=card();headingIn(c,"Мягкие идеи",16);c.addView(label("Отмечай только то, что тебе подходит. Ничего не обязательно.",12,MUTED,false,Typeface.DEFAULT));for(String s:ideas){CheckBox cb=new CheckBox(this);cb.setText(s);cb.setTextColor(INK);cb.setButtonTintList(android.content.res.ColorStateList.valueOf(SAGE));cb.setChecked(prefs.getBoolean("care_"+s,false));cb.setOnCheckedChangeListener((b,v)->prefs.edit().putBoolean("care_"+s,v).apply());c.addView(cb);}c.addView(action("Сбросить отметки",()->{for(String s:ideas)prefs.edit().remove("care_"+s).apply();navigate("Забота о себе");},false));
    }

    private void showGoals() {
        title("Цели и мечты","Маленькими шагами или просто мечтать. Без давления.");LinearLayout c=card();headingIn(c,"Добавить желание или цель",16);EditText field=makeEdit("Чего тебе хочется?",2);c.addView(field);addSpace(c,8);c.addView(action("Сохранить",()->{String s=field.getText().toString().trim();if(s.isEmpty())return;goals.add(0,new GoalEntry(System.currentTimeMillis(),s,false));saveData();navigate("Цели и мечты");},true));
        LinearLayout list=card();headingIn(list,"Мои мечты",16);if(goals.isEmpty())list.addView(label("Здесь могут жить большие мечты и совсем маленькие желания.",13,MUTED,false,Typeface.DEFAULT));else for(GoalEntry g:goals){CheckBox cb=new CheckBox(this);cb.setText(g.title);cb.setTextColor(INK);cb.setChecked(g.done);cb.setButtonTintList(android.content.res.ColorStateList.valueOf(SAGE));cb.setOnCheckedChangeListener((b,v)->{g.done=v;saveData();});list.addView(cb);list.addView(action("Удалить",()->new AlertDialog.Builder(this).setMessage("Удалить цель?").setNegativeButton("Отмена",null).setPositiveButton("Удалить",(d,w)->{goals.remove(g);saveData();navigate("Цели и мечты");}).show(),false));}
    }

    private void showLibrary() {
        title("Психологическая библиотека","Небольшие материалы для самопознания. Это образовательные заметки, не диагнозы.");
        addArticle("Эмоциональная усталость","Когда много событий и напряжения накапливаются, отдых может быть важнее попытки заставить себя работать ещё сильнее.");
        addArticle("Личные границы","Границы помогают обозначать, что для тебя приемлемо. Можно начинать с коротких фраз: «Мне нужно подумать» или «Сейчас мне неудобно».");
        addArticle("Заземление","Попробуй заметить пять предметов вокруг, четыре телесных ощущения, три звука, два запаха и один вкус. Если упражнение неприятно, остановись.");
        addArticle("Самосострадание","Попробуй говорить с собой так, как говорила бы с близким человеком, которому сейчас тяжело.");
        addArticle("Когда нужна помощь","Если переживания долго мешают повседневной жизни, можно обратиться к психологу, врачу или другому человеку, которому доверяешь.");
        LinearLayout tests=card();headingIn(tests,"Тесты для самопознания",15);tests.addView(label("В этой сборке не включены клинические тесты. Подбор валидированных опросников, источников и пояснений требует отдельной проверки.",12,MUTED,false,Typeface.DEFAULT));
    }
    private void addArticle(String title,String body){LinearLayout c=card();headingIn(c,title,16);TextView t=label(body,13,INK,false,Typeface.DEFAULT);t.setLineSpacing(dp(3),1f);c.addView(t);}

    private void showProfile() {
        title("Профиль и настройки","Настрой пространство под себя.");LinearLayout p=card();headingIn(p,"Темы оформления",16);String[] themes={"Midnight","Cloudy","Soft Grunge","Dreamcore"};for(String name:themes){p.addView(chip((themeName.equalsIgnoreCase(name)?"✓  ":"")+name,themeName.equalsIgnoreCase(name),()->{themeName=name;prefs.edit().putString("theme",themeName).apply();applyTheme();buildShell();showPage("Профиль");}));LinearLayout.LayoutParams lp=(LinearLayout.LayoutParams)p.getChildAt(p.getChildCount()-1).getLayoutParams();lp.bottomMargin=dp(6);}
        Switch sound=new Switch(this);sound.setText("Звуки интерфейса");sound.setTextColor(INK);sound.setChecked(soundEnabled);p.addView(sound);sound.setOnCheckedChangeListener((b,v)->{soundEnabled=v;prefs.edit().putBoolean("sound",v).apply();if(v)play(sndOpen);});Switch haptics=new Switch(this);haptics.setText("Лёгкая вибрация");haptics.setTextColor(INK);haptics.setChecked(hapticEnabled);p.addView(haptics);haptics.setOnCheckedChangeListener((b,v)->{hapticEnabled=v;prefs.edit().putBoolean("haptics",v).apply();});
        LinearLayout reasons=card();headingIn(reasons,"Собственные причины",15);reasons.addView(label("Добавляй свои теги, переименовывай или удаляй их. Старые записи при удалении тега не стираются.",12,MUTED,false,Typeface.DEFAULT));reasons.addView(action("Управлять моими причинами",()->manageCustomCauses(),false));
        LinearLayout stats=card();headingIn(stats,"Настройки статистики",15);Switch gap=new Switch(this);gap.setText("Скрыть периоды без отметок");gap.setTextColor(INK);gap.setChecked(hideGapStats);gap.setOnCheckedChangeListener((b,v)->{hideGapStats=v;prefs.edit().putBoolean("hide_gap_stats",v).apply();});stats.addView(gap);
        LinearLayout reminder=card();headingIn(reminder,"Напоминания",15);reminder.addView(label("Необязательное спокойное напоминание. Время можно менять или отключить в любой момент.",12,MUTED,false,Typeface.DEFAULT));reminder.addView(action(reminderEnabled&&reminderMinutes>=0?"Изменить время · "+String.format(Locale.getDefault(),"%02d:%02d",reminderMinutes/60,reminderMinutes%60):"Выбрать время",()->chooseReminderTime(),true));addSpace(reminder,6);reminder.addView(action("Отключить напоминания",()->{reminderEnabled=false;prefs.edit().putBoolean("reminder_enabled",false).apply();cancelReminder();navigate("Профиль");},false));
        LinearLayout cloud=card();headingIn(cloud,"Яндекс Диск",15);cloud.addView(label("Зашифрованная переносимая копия с фото и аудио будет загружаться в закрытую папку приложения. Для подключения нужен Client ID OAuth-приложения с правом cloud_api:disk.app_folder.",12,MUTED,false,Typeface.DEFAULT));EditText client=makeEdit("Client ID Яндекс OAuth",1);client.setText(yandexClientId);cloud.addView(client);cloud.addView(action(prefs.getBoolean("yandex_connected",false)?"Подключить другой аккаунт":"Подключить Яндекс Диск",()->{String id=client.getText().toString().trim();if(id.isEmpty()){Toast.makeText(this,"Сначала укажи Client ID из кабинета Яндекс OAuth",Toast.LENGTH_LONG).show();return;}yandexClientId=id;prefs.edit().putString("yandex_client_id",id).apply();startYandexOAuth();},true));cloud.addView(label(prefs.getBoolean("yandex_connected",false)?"Аккаунт подключён · "+(prefs.getBoolean("yandex_sync_pending",false)?"копия ожидает загрузки":"состояние синхронизации сохранено"):"Пока не подключён. Авторизация выполняется на стороне Яндекса.",11,MUTED,false,Typeface.DEFAULT));if(prefs.getBoolean("yandex_connected",false)){long last=prefs.getLong("yandex_last_sync",0L);String syncInfo=last>0?"Последняя копия: "+new SimpleDateFormat("d MMM · HH:mm",new Locale("ru")).format(new Date(last)):"Резервная копия ещё не загружалась";String error=prefs.getString("yandex_sync_error","");cloud.addView(label(syncInfo+(error.isEmpty()?"":"\nПроблема: "+error),11,MUTED,false,Typeface.DEFAULT));}if(prefs.getBoolean("yandex_connected",false)){Switch autoSync=new Switch(this);autoSync.setText("Автоматически после новых записей");autoSync.setTextColor(INK);autoSync.setChecked(prefs.getBoolean("yandex_sync_enabled",false));autoSync.setOnCheckedChangeListener((b,v)->{if(v&&!prefs.getBoolean("backup_key_confirmed",false)){showRecoveryKeyDialog();return;}prefs.edit().putBoolean("yandex_sync_enabled",v).apply();if(v)enqueueYandexBackup(false);});cloud.addView(autoSync);cloud.addView(action("Синхронизировать сейчас",()->enqueueYandexBackup(true),false));cloud.addView(action("Восстановить копию с Яндекс Диска",()->promptCloudRestore(),false));cloud.addView(action("Показать ключ восстановления",()->showRecoveryKeyDialog(),false));cloud.addView(action("Отключить Яндекс Диск",()->{prefs.edit().remove("yandex_access_token").remove("yandex_refresh_token").remove("yandex_sync_enabled").putBoolean("yandex_connected",false).apply();WorkManager.getInstance(this).cancelUniqueWork("mss_yandex_backup");WorkManager.getInstance(this).cancelUniqueWork("mss_yandex_periodic");navigate("Профиль");},false));}else{cloud.addView(action("Открыть регистрацию OAuth-приложения",()->{try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://oauth.yandex.com/client/new")));}catch(Exception ignored){}},false));}
        LinearLayout privacy=card();headingIn(privacy,"Быстрое скрытие",15);privacy.addView(label("Выбери разделы, содержимое которых будет закрываться при обычной навигации. Кнопка ◈ сверху открывает нейтральный экран.",12,MUTED,false,Typeface.DEFAULT));for(String s:HIDE_OPTIONS){CheckBox cb=new CheckBox(this);cb.setText(s);cb.setTextColor(INK);cb.setChecked(hiddenSections.contains(s));cb.setOnCheckedChangeListener((b,v)->{if(v)hiddenSections.add(s);else hiddenSections.remove(s);saveHiddenSections();});privacy.addView(cb);}privacy.addView(action("Проверить быстрое скрытие",()->showQuickHide(),false));
        LinearLayout data=card();headingIn(data,"Резервные копии",15);data.addView(label("Личные заметки хранятся локально в зашифрованном хранилище Android. Ручной экспорт и импорт остаются доступны.",12,MUTED,false,Typeface.DEFAULT));data.addView(action("Экспортировать личные данные",()->{backupMode=0;startExport("MySafeSpace-backup.json",REQ_EXPORT);},true));addSpace(data,7);data.addView(action("Импортировать резервную копию",()->startImport(),false));addSpace(data,7);data.addView(action("Экспортировать настройки оформления",()->{backupMode=1;startExport("MySafeSpace-theme.json",REQ_THEME_EXPORT);},false));
        LinearLayout about=card();headingIn(about,"О приложении",15);about.addView(label("My Safe Space · версия 3.2\nЛокальные записи защищены шифрованием. Синхронизация с Яндекс Диском требует авторизации OAuth.",12,MUTED,false,Typeface.DEFAULT));
    }

    private void chooseReminderTime(){Calendar now=Calendar.getInstance();int h=reminderMinutes>=0?reminderMinutes/60:now.get(Calendar.HOUR_OF_DAY);int m=reminderMinutes>=0?reminderMinutes%60:now.get(Calendar.MINUTE);new TimePickerDialog(this,(v,hour,minute)->{reminderMinutes=hour*60+minute;reminderEnabled=true;prefs.edit().putInt("reminder_minutes",reminderMinutes).putBoolean("reminder_enabled",true).apply();scheduleReminder();navigate("Профиль");},h,m,true).show();}
    private void scheduleReminder(){if(reminderMinutes<0)return;if(android.os.Build.VERSION.SDK_INT>=33&&checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},7702);return;}AlarmManager alarm=(AlarmManager)getSystemService(ALARM_SERVICE);Intent i=new Intent(this,CryReminderReceiver.class);PendingIntent pi=PendingIntent.getBroadcast(this,7701,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);Calendar c=Calendar.getInstance();c.set(Calendar.HOUR_OF_DAY,reminderMinutes/60);c.set(Calendar.MINUTE,reminderMinutes%60);c.set(Calendar.SECOND,0);if(c.getTimeInMillis()<=System.currentTimeMillis())c.add(Calendar.DAY_OF_YEAR,1);alarm.setInexactRepeating(AlarmManager.RTC_WAKEUP,c.getTimeInMillis(),AlarmManager.INTERVAL_DAY,pi);}
    private void cancelReminder(){try{AlarmManager alarm=(AlarmManager)getSystemService(ALARM_SERVICE);PendingIntent pi=PendingIntent.getBroadcast(this,7701,new Intent(this,CryReminderReceiver.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);alarm.cancel(pi);pi.cancel();}catch(Exception ignored){}}
    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){super.onRequestPermissionsResult(requestCode,permissions,grantResults);if(requestCode==7702){if(grantResults.length>0&&grantResults[0]==PackageManager.PERMISSION_GRANTED){scheduleReminder();Toast.makeText(this,"Напоминание включено",Toast.LENGTH_SHORT).show();}else Toast.makeText(this,"Уведомления отключены в разрешениях Android",Toast.LENGTH_LONG).show();}else if(requestCode==7703){boolean granted=grantResults.length>0&&grantResults[0]==PackageManager.PERMISSION_GRANTED;pendingAudioRecordingPermission=false;if(granted)beginAudioRecording();else Toast.makeText(this,"Для голосовой записи нужно разрешить доступ к микрофону",Toast.LENGTH_LONG).show();}}
    private void openYandexSetupWhenReady(){if(isFinishing())return;if(root==null||content==null){new android.os.Handler().postDelayed(()->openYandexSetupWhenReady(),250);return;}navigate("Профиль");showRecoveryKeyDialog();}
    private void startYandexOAuth(){try{String verifier=randomUrlToken(64);String state=randomUrlToken(24);pendingYandexVerifier=verifier;pendingYandexState=state;prefs.edit().putString("yandex_pkce_verifier",verifier).putString("yandex_oauth_state",state).apply();String challenge=Base64.encodeToString(MessageDigest.getInstance("SHA-256").digest(verifier.getBytes(StandardCharsets.US_ASCII)),Base64.URL_SAFE|Base64.NO_PADDING|Base64.NO_WRAP);String redirect="mysafespace://oauth/callback";String url="https://oauth.yandex.com/authorize?response_type=code&client_id="+URLEncoder.encode(yandexClientId,"UTF-8")+"&redirect_uri="+URLEncoder.encode(redirect,"UTF-8")+"&scope="+URLEncoder.encode("cloud_api:disk.app_folder","UTF-8")+"&state="+URLEncoder.encode(state,"UTF-8")+"&code_challenge="+URLEncoder.encode(challenge,"UTF-8")+"&code_challenge_method=S256";startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}catch(Exception e){Toast.makeText(this,"Не удалось открыть авторизацию Яндекса",Toast.LENGTH_LONG).show();}}
    private String randomUrlToken(int bytes){byte[] b=new byte[bytes];new SecureRandom().nextBytes(b);return Base64.encodeToString(b,Base64.URL_SAFE|Base64.NO_PADDING|Base64.NO_WRAP);}
    @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);handleYandexCallback(intent);}
    private void handleYandexCallback(Intent intent){if(intent==null||intent.getData()==null)return;Uri u=intent.getData();if(!"mysafespace".equals(u.getScheme())||!"oauth".equals(u.getHost()))return;String code=u.getQueryParameter("code"),state=u.getQueryParameter("state");String expected=prefs.getString("yandex_oauth_state","");String verifier=prefs.getString("yandex_pkce_verifier","");if(code==null||expected.isEmpty()||!expected.equals(state)||verifier.isEmpty()){Toast.makeText(this,"Авторизация не завершилась. Попробуй подключить Диск снова.",Toast.LENGTH_LONG).show();return;}exchangeYandexCode(code,verifier);}
    private void exchangeYandexCode(String code,String verifier){new Thread(()->{HttpURLConnection con=null;try{URL url=new URL("https://oauth.yandex.com/token");con=(HttpURLConnection)url.openConnection();con.setRequestMethod("POST");con.setDoOutput(true);con.setConnectTimeout(15000);con.setReadTimeout(15000);con.setRequestProperty("Content-Type","application/x-www-form-urlencoded");String body="grant_type=authorization_code&code="+URLEncoder.encode(code,"UTF-8")+"&client_id="+URLEncoder.encode(yandexClientId,"UTF-8")+"&redirect_uri="+URLEncoder.encode("mysafespace://oauth/callback","UTF-8")+"&code_verifier="+URLEncoder.encode(verifier,"UTF-8");try(OutputStream out=con.getOutputStream()){out.write(body.getBytes(StandardCharsets.UTF_8));}InputStream in=con.getResponseCode()<400?con.getInputStream():con.getErrorStream();String response;try(ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] b=new byte[4096];int n;while((n=in.read(b))>0)out.write(b,0,n);response=out.toString("UTF-8");}JSONObject json=new JSONObject(response);String token=json.optString("access_token","");if(token.isEmpty())throw new IOException(json.optString("error_description","Яндекс не выдал токен"));ensureYandexFolder(token);String encrypted=encryptVault(token);String refresh=json.optString("refresh_token","");SharedPreferences.Editor auth=prefs.edit().putString("yandex_access_token",encrypted).putBoolean("yandex_connected",true).putBoolean("yandex_sync_enabled",false).remove("yandex_pkce_verifier").remove("yandex_oauth_state");if(!refresh.isEmpty())auth.putString("yandex_refresh_token",encryptVault(refresh));long expires=json.optLong("expires_in",0);if(expires>0)auth.putLong("yandex_expires_at",System.currentTimeMillis()+expires*1000L);auth.apply();getOrCreateBackupKey();runOnUiThread(()->openYandexSetupWhenReady());}catch(Exception e){String msg=e.getMessage()==null?"Ошибка авторизации":e.getMessage();runOnUiThread(()->Toast.makeText(this,"Не удалось подключить Яндекс Диск: "+msg,Toast.LENGTH_LONG).show());}finally{if(con!=null)con.disconnect();}}).start();}
    private void ensureYandexFolder(String token){try{URL url=new URL("https://cloud-api.yandex.net/v1/disk/resources?path=app:/MySafeSpace");HttpURLConnection c=(HttpURLConnection)url.openConnection();c.setRequestMethod("PUT");c.setRequestProperty("Authorization","OAuth "+token);c.setConnectTimeout(10000);c.setReadTimeout(10000);int code=c.getResponseCode();if(code!=201&&code!=409&&code!=200)throw new IOException("Не удалось создать папку на Диске ("+code+")");c.disconnect();}catch(Exception e){throw new RuntimeException(e);}}
    private void enqueueYandexBackup(boolean tellUser){if(!prefs.getBoolean("yandex_connected",false)){if(tellUser)Toast.makeText(this,"Сначала подключи Яндекс Диск",Toast.LENGTH_SHORT).show();return;}if(!prefs.getBoolean("backup_key_confirmed",false)){showRecoveryKeyDialog();return;}Constraints constraints=new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();OneTimeWorkRequest request=new OneTimeWorkRequest.Builder(YandexBackupWorker.class).setInputData(new androidx.work.Data.Builder().putBoolean("force",tellUser).build()).setConstraints(constraints).setBackoffCriteria(androidx.work.BackoffPolicy.EXPONENTIAL,30,TimeUnit.SECONDS).build();WorkManager.getInstance(this).enqueueUniqueWork("mss_yandex_backup",ExistingWorkPolicy.REPLACE,request);if(tellUser)Toast.makeText(this,"Резервная копия поставлена в очередь. Загрузка начнётся при наличии интернета.",Toast.LENGTH_LONG).show();}
    private byte[] getOrCreateBackupKey()throws Exception{String wrapped=prefs.getString("backup_key_wrapped","");if(!wrapped.isEmpty())return decryptPackedKey(wrapped);byte[] key=new byte[32];new SecureRandom().nextBytes(key);Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.ENCRYPT_MODE,vaultKey());byte[] iv=cipher.getIV(),enc=cipher.doFinal(key),all=new byte[iv.length+enc.length];System.arraycopy(iv,0,all,0,iv.length);System.arraycopy(enc,0,all,iv.length,enc.length);prefs.edit().putString("backup_key_wrapped",Base64.encodeToString(all,Base64.NO_WRAP)).putBoolean("backup_key_confirmed",false).apply();return key;}
    private byte[] decryptPackedKey(String encoded)throws Exception{byte[] all=Base64.decode(encoded,Base64.NO_WRAP);if(all.length<13)throw new IOException("Ключ восстановления повреждён");byte[] iv=new byte[12],body=new byte[all.length-12];System.arraycopy(all,0,iv,0,12);System.arraycopy(all,12,body,0,body.length);Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.DECRYPT_MODE,vaultKey(),new GCMParameterSpec(128,iv));return cipher.doFinal(body);}
    private void showRecoveryKeyDialog(){try{byte[] key=getOrCreateBackupKey();String human=Base64.encodeToString(key,Base64.URL_SAFE|Base64.NO_PADDING|Base64.NO_WRAP);TextView message=label("Это ключ для расшифровки резервной копии на новом телефоне. Сохрани его отдельно от телефона — приложение не сможет восстановить его, если ты потеряешь и телефон, и этот ключ.",13,INK,false,Typeface.DEFAULT);message.setPadding(dp(12),dp(10),dp(12),dp(10));TextView code=label(human,14,SAGE_DARK,true,Typeface.MONOSPACE);code.setPadding(dp(12),dp(12),dp(12),dp(12));code.setBackground(solid(BG,12,LINE));LinearLayout box=column();box.addView(message);box.addView(code);box.addView(action("Копировать ключ",()->{((android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(android.content.ClipData.newPlainText("My Safe Space recovery key",human));Toast.makeText(this,"Ключ скопирован. Сохрани его в безопасном месте.",Toast.LENGTH_LONG).show();},false));new AlertDialog.Builder(this).setTitle("Ключ восстановления").setView(box).setCancelable(false).setNegativeButton("Позже",(d,w)->{}).setPositiveButton(prefs.getBoolean("backup_key_confirmed",false)?"Готово":"Я сохранила ключ",(d,w)->{prefs.edit().putBoolean("backup_key_confirmed",true).putBoolean("yandex_sync_enabled",true).apply();schedulePeriodicYandexBackup();enqueueYandexBackup(true);}).show();}catch(Exception e){Toast.makeText(this,"Не удалось подготовить ключ восстановления",Toast.LENGTH_LONG).show();}}
    private void schedulePeriodicYandexBackup(){Constraints constraints=new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();PeriodicWorkRequest periodic=new PeriodicWorkRequest.Builder(YandexBackupWorker.class,24,TimeUnit.HOURS).setConstraints(constraints).build();WorkManager.getInstance(this).enqueueUniquePeriodicWork("mss_yandex_periodic",ExistingPeriodicWorkPolicy.UPDATE,periodic);}
    private byte[] encryptAttachmentBytes(byte[] plain)throws Exception{Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.ENCRYPT_MODE,vaultKey());byte[] iv=cipher.getIV(),enc=cipher.doFinal(plain),all=new byte[iv.length+enc.length];System.arraycopy(iv,0,all,0,iv.length);System.arraycopy(enc,0,all,iv.length,enc.length);return all;}
    private void promptCloudRestore(){EditText key=makeEdit("Вставь ключ восстановления",2);new AlertDialog.Builder(this).setTitle("Восстановить резервную копию").setMessage("Введи ключ, который приложение показало при подключении Яндекс Диска. Текущие записи на этом телефоне будут заменены содержимым резервной копии.").setView(key).setNegativeButton("Отмена",null).setPositiveButton("Скачать и восстановить",(d,w)->downloadAndRestoreCloud(key.getText().toString().trim())).show();}
    private String freshYandexAccessToken()throws Exception{long expiry=prefs.getLong("yandex_expires_at",0L);if(expiry>0L&&expiry<=System.currentTimeMillis()+5L*60L*1000L)return refreshYandexAccessToken();String token=decryptVault(prefs.getString("yandex_access_token",""));if(token.isEmpty())throw new IOException("Нет авторизации Яндекса");return token;}
    private String refreshYandexAccessToken()throws Exception{String refresh=decryptVault(prefs.getString("yandex_refresh_token",""));if(refresh.isEmpty())throw new IOException("Сеанс Яндекса истёк. Подключи Диск снова.");String body="grant_type=refresh_token&refresh_token="+URLEncoder.encode(refresh,"UTF-8")+"&client_id="+URLEncoder.encode(yandexClientId,"UTF-8");HttpURLConnection c=(HttpURLConnection)new URL("https://oauth.yandex.com/token").openConnection();try{c.setRequestMethod("POST");c.setDoOutput(true);c.setConnectTimeout(20000);c.setReadTimeout(20000);c.setRequestProperty("Content-Type","application/x-www-form-urlencoded; charset=UTF-8");try(OutputStream out=c.getOutputStream()){out.write(body.getBytes(StandardCharsets.UTF_8));}int code=c.getResponseCode();InputStream response=code>=200&&code<300?c.getInputStream():c.getErrorStream();String raw=response==null?"":readStream(response);JSONObject json=new JSONObject(raw);String access=json.optString("access_token","");if(code<200||code>=300||access.isEmpty())throw new IOException(json.optString("error_description","Не удалось обновить доступ Яндекса"));SharedPreferences.Editor edit=prefs.edit().putString("yandex_access_token",encryptVault(access));String newRefresh=json.optString("refresh_token","");if(!newRefresh.isEmpty())edit.putString("yandex_refresh_token",encryptVault(newRefresh));long seconds=json.optLong("expires_in",0L);if(seconds>0)edit.putLong("yandex_expires_at",System.currentTimeMillis()+seconds*1000L);edit.apply();return access;}finally{c.disconnect();}}

    private void downloadAndRestoreCloud(String recoveryCode){new Thread(()->{HttpURLConnection c=null;try{byte[] key=Base64.decode(recoveryCode,Base64.URL_SAFE|Base64.NO_PADDING|Base64.NO_WRAP);if(key.length!=32)throw new IOException("Проверь ключ восстановления");Cipher wrap=Cipher.getInstance("AES/GCM/NoPadding");wrap.init(Cipher.ENCRYPT_MODE,vaultKey());byte[] wrapIv=wrap.getIV(),wrapBody=wrap.doFinal(key),wrapped=new byte[wrapIv.length+wrapBody.length];System.arraycopy(wrapIv,0,wrapped,0,wrapIv.length);System.arraycopy(wrapBody,0,wrapped,wrapIv.length,wrapBody.length);String token=freshYandexAccessToken();URL url=new URL("https://cloud-api.yandex.net/v1/disk/resources/download?path=app:/MySafeSpace/secure-backup.mss");c=(HttpURLConnection)url.openConnection();c.setRequestProperty("Authorization","OAuth "+token);int responseCode=c.getResponseCode();if(responseCode==401){c.disconnect();c=null;token=refreshYandexAccessToken();c=(HttpURLConnection)url.openConnection();c.setRequestProperty("Authorization","OAuth "+token);responseCode=c.getResponseCode();}if(responseCode!=200)throw new IOException("Не удалось найти резервную копию на Диске ("+responseCode+")");String href=new JSONObject(readStream(c.getInputStream())).getString("href");c.disconnect();c=(HttpURLConnection)new URL(href).openConnection();byte[] encrypted;try(InputStream in=c.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] b=new byte[8192];int n;while((n=in.read(b))>0)out.write(b,0,n);encrypted=out.toByteArray();}byte[] zip=decryptPortableBackup(encrypted,key);String json=restorePortableZip(zip);new JSONObject(json);runOnUiThread(()->{try{restoreData(new JSONObject(json));prefs.edit().putString("backup_key_wrapped",Base64.encodeToString(wrapped,Base64.NO_WRAP)).putBoolean("backup_key_confirmed",true).putBoolean("yandex_sync_enabled",true).apply();vaultProblem=false;saveData();schedulePeriodicYandexBackup();applyTheme();buildShell();showPage("Главная");Toast.makeText(this,"Резервная копия восстановлена",Toast.LENGTH_LONG).show();}catch(Exception e){Toast.makeText(this,"Не удалось применить резервную копию: "+e.getMessage(),Toast.LENGTH_LONG).show();}});}catch(Exception e){String msg=e.getMessage()==null?"Ошибка восстановления":e.getMessage();runOnUiThread(()->Toast.makeText(this,msg,Toast.LENGTH_LONG).show());}finally{if(c!=null)c.disconnect();}}).start();}
    private byte[] decryptPortableBackup(byte[] encrypted,byte[] key)throws Exception{if(encrypted.length<13)throw new IOException("Копия повреждена");byte[] iv=new byte[12],body=new byte[encrypted.length-12];System.arraycopy(encrypted,0,iv,0,12);System.arraycopy(encrypted,12,body,0,body.length);Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.DECRYPT_MODE,new SecretKeySpec(key,"AES"),new GCMParameterSpec(128,iv));return cipher.doFinal(body);}
    private String restorePortableZip(byte[] zipBytes)throws Exception{String json=null;try(ZipInputStream zip=new ZipInputStream(new java.io.ByteArrayInputStream(zipBytes))){ZipEntry entry;while((entry=zip.getNextEntry())!=null){ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[8192];int n;while((n=zip.read(b))>0)out.write(b,0,n);if("data.json".equals(entry.getName()))json=out.toString("UTF-8");else if(entry.getName().startsWith("media/")){String fileName=entry.getName().substring("media/".length());if(!fileName.matches("[A-Za-z0-9_-]+\\.mss"))throw new IOException("Недопустимое имя вложения в резервной копии");File dir=new File(getFilesDir(),"cry_media");if(!dir.exists())dir.mkdirs();byte[] encrypted=encryptAttachmentBytes(out.toByteArray());try(FileOutputStream f=new FileOutputStream(new File(dir,fileName))){f.write(encrypted);}}zip.closeEntry();}}if(json==null)throw new IOException("В резервной копии нет данных");return json;}

    private String readStream(InputStream in)throws Exception{try(ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] b=new byte[4096];int n;while((n=in.read(b))>0)out.write(b,0,n);return out.toString("UTF-8");}}

    private void saveHiddenSections(){StringBuilder b=new StringBuilder();for(String s:hiddenSections){if(b.length()>0)b.append('|');b.append(s);}prefs.edit().putString("hide_sections",b.toString()).apply();}
    private void showQuickHide(){
        stopNature();LinearLayout cover=column();cover.setGravity(Gravity.CENTER);cover.setPadding(dp(30),dp(30),dp(30),dp(30));cover.setBackgroundColor(BG);TextView icon=label("☁",52,MUTED,false,Typeface.SERIF);icon.setGravity(Gravity.CENTER);cover.addView(icon);TextView title=label("Тихая пауза",24,INK,false,Typeface.SERIF);title.setGravity(Gravity.CENTER);title.setPadding(0,dp(8),0,dp(8));cover.addView(title);TextView sub=label("Экран личного пространства временно скрыт.",13,MUTED,false,Typeface.DEFAULT);sub.setGravity(Gravity.CENTER);cover.addView(sub);addStandaloneSpace(cover,20);TextView back=action("Вернуться в My Safe Space",()->{buildShell();showPage("Главная");},true);cover.addView(back,new LinearLayout.LayoutParams(-1,-2));setContentView(cover);
    }
    private void addStandaloneSpace(LinearLayout into,int h){into.addView(new View(this),new LinearLayout.LayoutParams(1,dp(h)));}

    private EditText makeEdit(String hint,int lines){EditText e=new EditText(this);e.setTextSize(14);e.setTextColor(INK);e.setHintTextColor(MUTED);e.setHint(hint);e.setMinLines(lines);e.setGravity(Gravity.TOP|Gravity.START);e.setPadding(dp(12),dp(11),dp(12),dp(11));e.setBackground(solid(BG,15,LINE));return e;}
    private void startVoice(EditText target){voiceTarget=target;try{Intent i=new Intent("android.speech.action.RECOGNIZE_SPEECH");i.putExtra("android.speech.extra.LANGUAGE_MODEL","free_form");i.putExtra("android.speech.extra.LANGUAGE",Locale.getDefault().toLanguageTag());i.putExtra("android.speech.extra.PROMPT","Говори, я записываю");startActivityForResult(i,REQ_VOICE);}catch(Exception e){Toast.makeText(this,"Голосовой ввод недоступен на этом устройстве",Toast.LENGTH_SHORT).show();}}

    private void startExport(String name,int requestCode){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");i.putExtra(Intent.EXTRA_TITLE,name);try{startActivityForResult(i,requestCode);}catch(Exception e){Toast.makeText(this,"Не удалось открыть сохранение файла",Toast.LENGTH_SHORT).show();}}
    private void startImport(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");try{startActivityForResult(i,REQ_IMPORT);}catch(Exception e){Toast.makeText(this,"Не удалось открыть выбор файла",Toast.LENGTH_SHORT).show();}}
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(resultCode!=RESULT_OK||data==null)return;
        if(requestCode==REQ_CRY_IMAGES||requestCode==REQ_CRY_AUDIO){ArrayList<Uri> chosen=new ArrayList<>();if(data.getClipData()!=null){for(int i=0;i<data.getClipData().getItemCount();i++)chosen.add(data.getClipData().getItemAt(i).getUri());}else if(data.getData()!=null)chosen.add(data.getData());for(Uri u:chosen){try{Attachment a=saveEncryptedAttachment(u);if(attachmentTarget!=null){attachmentTarget.attachments.add(a);saveData();}else draftAttachments.add(a);}catch(Exception e){Toast.makeText(this,"Не удалось добавить файл: "+e.getMessage(),Toast.LENGTH_LONG).show();}}if(attachmentTarget!=null){attachmentTarget=null;showCalendar();}else updateAttachmentCount();return;}
        if(data.getData()==null)return;Uri uri=data.getData();try{
        if(requestCode==REQ_VOICE){ArrayList<String> result=data.getStringArrayListExtra("android.speech.extra.RESULTS");if(voiceTarget!=null&&result!=null&&!result.isEmpty()){String old=voiceTarget.getText().toString();voiceTarget.setText(old.isEmpty()?result.get(0):old+" "+result.get(0));}return;}
        if(requestCode==REQ_EXPORT||requestCode==REQ_THEME_EXPORT){String payload=backupMode==1?buildThemeBackup():buildDataBackup();try(OutputStream out=getContentResolver().openOutputStream(uri)){out.write(payload.getBytes(StandardCharsets.UTF_8));out.flush();}Toast.makeText(this,"Файл сохранён",Toast.LENGTH_SHORT).show();return;}
        if(requestCode==REQ_IMPORT){String raw=readUri(uri);new AlertDialog.Builder(this).setTitle("Восстановить данные?").setMessage("Импортированные данные заменят текущие записи, воспоминания и цели. Перед продолжением сделай резервную копию текущих данных.").setNegativeButton("Отмена",null).setPositiveButton("Восстановить",(d,w)->{try{restoreData(new JSONObject(raw));vaultProblem=false;saveData();applyTheme();buildShell();showPage("Главная");Toast.makeText(this,"Резервная копия восстановлена",Toast.LENGTH_LONG).show();}catch(Exception ex){Toast.makeText(this,"Не удалось прочитать эту копию",Toast.LENGTH_LONG).show();}}).show();}
    }catch(Exception e){Toast.makeText(this,"Операция не выполнена: "+e.getMessage(),Toast.LENGTH_LONG).show();}}
    private String readUri(Uri uri)throws Exception{try(InputStream in=getContentResolver().openInputStream(uri);ByteArrayOutputStream b=new ByteArrayOutputStream()){byte[] buf=new byte[8192];int n;while((n=in.read(buf))>0)b.write(buf,0,n);return b.toString("UTF-8");}}
    private String buildThemeBackup()throws Exception{JSONObject o=new JSONObject();o.put("type","mss-theme");o.put("version",3);o.put("theme",themeName);o.put("sound",soundEnabled);o.put("haptics",hapticEnabled);o.put("hideSections",new JSONArray(hiddenSections));return o.toString(2);}
    private String buildDataBackup()throws Exception{JSONObject o=toDataJson();o.put("type","mss-backup");o.put("version",3);return o.toString(2);}
    private void restoreData(JSONObject o)throws Exception{
        if("mss-theme".equals(o.optString("type"))){themeName=o.optString("theme","Midnight");soundEnabled=o.optBoolean("sound",true);hapticEnabled=o.optBoolean("haptics",true);hiddenSections.clear();JSONArray h=o.optJSONArray("hideSections");if(h!=null)for(int i=0;i<h.length();i++)hiddenSections.add(h.optString(i));prefs.edit().putString("theme",themeName).putBoolean("sound",soundEnabled).putBoolean("haptics",hapticEnabled).apply();saveHiddenSections();return;}
        cries.clear();journal.clear();memories.clear();goals.clear();customCauses.clear();JSONArray custom=o.optJSONArray("customCauses");if(custom!=null)for(int i=0;i<custom.length();i++)customCauses.add(custom.optString(i));JSONArray a=o.optJSONArray("cries");if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.getJSONObject(i);CryRecord r=new CryRecord(x.optLong("time"),x.optString("causes"),x.optString("note"));r.intensity=x.optInt("intensity",0);JSONArray at=x.optJSONArray("attachments");if(at!=null)for(int j=0;j<at.length();j++){JSONObject f=at.getJSONObject(j);r.attachments.add(new Attachment(f.optString("fileName"),f.optString("displayName","Вложение"),f.optString("mime","application/octet-stream")));}cries.add(r);}
        a=o.optJSONArray("journal");if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.getJSONObject(i);journal.add(new JournalEntry(x.optLong("time"),x.optString("title"),x.optString("note")));}
        a=o.optJSONArray("memories");if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.getJSONObject(i);memories.add(new MemoryEntry(x.optLong("time"),x.optString("type"),x.optString("title"),x.optString("note")));}
        a=o.optJSONArray("goals");if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.getJSONObject(i);goals.add(new GoalEntry(x.optLong("time"),x.optString("title"),x.optBoolean("done")));}
    }

    private void hideKeyboard(View v){try{((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(v.getWindowToken(),0);}catch(Exception ignored){}}

    // AES-256 where supported, with a per-install key protected by Android Keystore.
    private SecretKey vaultKey() throws Exception {
        KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);if(ks.containsAlias(VAULT_ALIAS))return (SecretKey)ks.getKey(VAULT_ALIAS,null);
        KeyGenerator kg=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");KeyGenParameterSpec spec=new KeyGenParameterSpec.Builder(VAULT_ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setRandomizedEncryptionRequired(true).build();kg.init(spec);return kg.generateKey();
    }
    private String encryptVault(String plain)throws Exception{Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.ENCRYPT_MODE,vaultKey());byte[] iv=cipher.getIV();byte[] encrypted=cipher.doFinal(plain.getBytes(StandardCharsets.UTF_8));byte[] all=new byte[iv.length+encrypted.length];System.arraycopy(iv,0,all,0,iv.length);System.arraycopy(encrypted,0,all,iv.length,encrypted.length);return Base64.encodeToString(all,Base64.NO_WRAP);}
    private String decryptVault(String encoded)throws Exception{byte[] all=Base64.decode(encoded,Base64.NO_WRAP);if(all.length<13)throw new IllegalArgumentException("Invalid vault");byte[] iv=new byte[12];byte[] encrypted=new byte[all.length-12];System.arraycopy(all,0,iv,0,12);System.arraycopy(all,12,encrypted,0,encrypted.length);Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.DECRYPT_MODE,vaultKey(),new GCMParameterSpec(128,iv));return new String(cipher.doFinal(encrypted),StandardCharsets.UTF_8);}
    private void loadData(){
        String vault=prefs.getString("vault","");if(!vault.isEmpty()){try{restoreData(new JSONObject(decryptVault(vault)));return;}catch(Exception e){vaultProblem=true;}}
        if(vaultProblem)return;
        try{JSONArray a=new JSONArray(prefs.getString("cries","[]"));for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);CryRecord r=new CryRecord(o.optLong("time"),o.optString("causes"),o.optString("note"));r.intensity=o.optInt("intensity",0);cries.add(r);}}catch(Exception ignored){}
        try{JSONArray a=new JSONArray(prefs.getString("journal","[]"));for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);journal.add(new JournalEntry(o.optLong("time"),o.optString("title"),o.optString("note")));}}catch(Exception ignored){}
        if(journal.isEmpty()){String legacy=prefs.getString("entries","");if(!legacy.isEmpty())for(String line:legacy.split("\\n")){if(line.trim().isEmpty())continue;String[] parts=line.split(" · ",3);long time=System.currentTimeMillis();String note=line;if(parts.length>=2){try{time=new SimpleDateFormat("dd.MM.yyyy HH:mm",Locale.getDefault()).parse(parts[0]).getTime();}catch(Exception ignored){}note=parts.length==3?parts[2]:parts[parts.length-1];}journal.add(new JournalEntry(time,"",note));}}
        try{JSONArray a=new JSONArray(prefs.getString("memories","[]"));for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);memories.add(new MemoryEntry(o.optLong("time"),o.optString("type"),o.optString("title"),o.optString("note")));}}catch(Exception ignored){}
        try{JSONArray a=new JSONArray(prefs.getString("goals","[]"));for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);goals.add(new GoalEntry(o.optLong("time"),o.optString("title"),o.optBoolean("done")));}}catch(Exception ignored){}
        if(!cries.isEmpty()||!journal.isEmpty()||!memories.isEmpty()||!goals.isEmpty())saveData();
    }
    private JSONObject toDataJson()throws Exception{
        JSONObject all=new JSONObject();all.put("customCauses",new JSONArray(customCauses));JSONArray a=new JSONArray();for(CryRecord r:cries){JSONObject x=new JSONObject();x.put("time",r.time);x.put("causes",r.causes);x.put("note",r.note);x.put("intensity",r.intensity);JSONArray at=new JSONArray();if(r.attachments!=null)for(Attachment f:r.attachments){JSONObject z=new JSONObject();z.put("fileName",f.fileName);z.put("displayName",f.displayName);z.put("mime",f.mime);at.put(z);}x.put("attachments",at);a.put(x);}all.put("cries",a);
        a=new JSONArray();for(JournalEntry e:journal){JSONObject x=new JSONObject();x.put("time",e.time);x.put("title",e.title);x.put("note",e.note);a.put(x);}all.put("journal",a);
        a=new JSONArray();for(MemoryEntry e:memories){JSONObject x=new JSONObject();x.put("time",e.time);x.put("type",e.type);x.put("title",e.title);x.put("note",e.note);a.put(x);}all.put("memories",a);
        a=new JSONArray();for(GoalEntry g:goals){JSONObject x=new JSONObject();x.put("time",g.time);x.put("title",g.title);x.put("done",g.done);a.put(x);}all.put("goals",a);return all;
    }
    private void saveData(){if(vaultProblem){Toast.makeText(this,"Хранилище заблокировано: сначала восстанови данные из резервной копии",Toast.LENGTH_LONG).show();return;}try{String encrypted=encryptVault(toDataJson().toString());prefs.edit().putString("vault",encrypted).remove("cries").remove("journal").remove("memories").remove("goals").remove("entries").apply();if(prefs.getBoolean("yandex_sync_enabled",false))enqueueYandexBackup(false);}catch(Exception e){Toast.makeText(this,"Не удалось сохранить защищённые данные",Toast.LENGTH_LONG).show();}}

    @Override protected void onDestroy(){if(activeRecorder!=null)cleanupRecorder();super.onDestroy();stopNature();if(soundPool!=null){soundPool.release();soundPool=null;}}
    @Override public void onBackPressed(){if(!current.equals("Главная")){navigate("Главная");}else super.onBackPressed();}
}
