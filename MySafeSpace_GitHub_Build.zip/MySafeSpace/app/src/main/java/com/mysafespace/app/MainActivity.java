package com.mysafespace.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.SoundPool;
import android.media.MediaPlayer;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.HapticFeedbackConstants;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.view.animation.DecelerateInterpolator;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    // Warm ivory + botanical sage palette.
    private static final int BG=Color.rgb(246,245,237), PAPER=Color.rgb(255,254,249), SAGE=Color.rgb(111,132,105),
            SAGE_DARK=Color.rgb(62,83,66), SAGE_LIGHT=Color.rgb(225,233,218), MINT=Color.rgb(235,241,229),
            INK=Color.rgb(43,57,46), MUTED=Color.rgb(119,129,116), LINE=Color.rgb(222,226,215), WHITE=Color.WHITE;
    private LinearLayout root, content, nav, header;
    private String current="Главная";
    private SharedPreferences prefs;
    private SoundPool soundPool;
    private MediaPlayer ambience;
    private int ambienceId=0;
    private int sndTap, sndSave, sndOpen;
    private boolean soundEnabled=true, hapticEnabled=true;
    private final ArrayList<CryRecord> cries=new ArrayList<>();
    private final ArrayList<JournalEntry> journal=new ArrayList<>();
    private Calendar visibleMonth=Calendar.getInstance();
    private Calendar selectedDate=Calendar.getInstance();
    private long pendingCryTime=-1L;
    private final LinkedHashSet<String> selectedCauses=new LinkedHashSet<>();
    private static final String[] CAUSES={"Стресс","Тревога","Грусть","Одиночество","Разочарование","Усталость","Конфликт","Боль","Радость","Другое"};

    private static class CryRecord {
        long time; String causes, note;
        CryRecord(long t,String c,String n){time=t;causes=c;note=n;}
        String day(){return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date(time));}
    }
    private static class JournalEntry {
        long time; String note;
        JournalEntry(long t,String n){time=t;note=n;}
    }

    @Override public void onCreate(Bundle state){super.onCreate(state);
        prefs=getSharedPreferences("safe_space",MODE_PRIVATE);
        soundEnabled=prefs.getBoolean("sound",true); hapticEnabled=prefs.getBoolean("haptics",true);
        getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        loadData(); initSounds(); showSplash();
    }

    private void initSounds(){
        try{soundPool=new SoundPool.Builder().setMaxStreams(3).build();sndTap=soundPool.load(this,R.raw.tap,1);sndSave=soundPool.load(this,R.raw.save,1);sndOpen=soundPool.load(this,R.raw.open,1);}catch(Exception ignored){}
    }
    private void play(int id){if(soundEnabled&&soundPool!=null&&id!=0)try{soundPool.play(id,0.38f,0.38f,1,0,1f);}catch(Exception ignored){}}
    private void playNature(int which){
        if(ambience!=null && ambienceId==which && ambience.isPlaying()){stopNature();return;}
        stopNature();
        try{ambience=MediaPlayer.create(this,which==1?R.raw.ambience_rain:R.raw.ambience_forest);if(ambience!=null){ambience.setLooping(true);ambience.setVolume(.42f,.42f);ambience.start();ambienceId=which;Toast.makeText(this,which==1?"Звучит мягкий дождь":"Звучит спокойный лес",Toast.LENGTH_SHORT).show();}}
        catch(Exception e){stopNature();Toast.makeText(this,"Не удалось включить звук",Toast.LENGTH_SHORT).show();}
    }
    private void stopNature(){if(ambience!=null){try{if(ambience.isPlaying())ambience.stop();}catch(Exception ignored){}try{ambience.release();}catch(Exception ignored){}ambience=null;}ambienceId=0;}
    private void feedback(View v,boolean save){if(hapticEnabled)v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);play(save?sndSave:sndTap);}

    private void showSplash(){
        LinearLayout splash=new LinearLayout(this);splash.setOrientation(LinearLayout.VERTICAL);splash.setGravity(Gravity.CENTER);splash.setBackground(gradient(BG,Color.rgb(229,237,223),GradientDrawable.Orientation.TL_BR));setContentView(splash);
        TextView leaf=label("❧",64,SAGE,true,Typeface.SERIF);splash.addView(leaf);
        TextView brand=label("My Safe Space",32,INK,false,Typeface.SERIF);brand.setGravity(Gravity.CENTER);brand.setAlpha(0f);brand.setTranslationY(18);splash.addView(brand);
        TextView sub=label("твоё тихое место",13,MUTED,false,Typeface.DEFAULT);sub.setGravity(Gravity.CENTER);sub.setAlpha(0f);splash.addView(sub);
        ObjectAnimator rotate=ObjectAnimator.ofFloat(leaf,"rotation",-12f,8f,0f);rotate.setDuration(1050);
        ObjectAnimator fade=ObjectAnimator.ofFloat(leaf,"alpha",0f,1f);fade.setDuration(750);
        ObjectAnimator rise=ObjectAnimator.ofFloat(brand,"translationY",18f,0f);rise.setDuration(800);
        ObjectAnimator brandFade=ObjectAnimator.ofFloat(brand,"alpha",0f,1f);brandFade.setDuration(800);
        ObjectAnimator subFade=ObjectAnimator.ofFloat(sub,"alpha",0f,1f);subFade.setDuration(650);subFade.setStartDelay(300);
        AnimatorSet intro=new AnimatorSet();intro.playTogether(rotate,fade,rise,brandFade,subFade);intro.setInterpolator(new DecelerateInterpolator());intro.start();
        new android.os.Handler().postDelayed(()->{if(isFinishing())return;play(sndOpen);buildShell();showPage("Главная");},1550);
    }

    private GradientDrawable gradient(int a,int b,GradientDrawable.Orientation o){GradientDrawable d=new GradientDrawable(o,new int[]{a,b});d.setCornerRadius(dp(24));return d;}
    private GradientDrawable solid(int c,int radius,int stroke){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(dp(radius));if(stroke!=0)d.setStroke(dp(1),stroke);return d;}
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+0.5f);}
    private TextView label(String s,int size,int color,boolean bold,Typeface face){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.CENTER_VERTICAL);if(face!=null)t.setTypeface(face,bold?Typeface.BOLD:Typeface.NORMAL);else if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private void margins(View v,int bottom){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(bottom);content.addView(v,p);}
    private void addSpace(LinearLayout into,int h){View v=new View(this);into.addView(v,new LinearLayout.LayoutParams(1,dp(h)));}

    private void buildShell(){
        root=column();root.setBackgroundColor(BG);setContentView(root);
        header=column();header.setPadding(dp(22),dp(12),dp(22),dp(10));
        LinearLayout brandRow=row();TextView sprig=label("❧",25,SAGE,true,Typeface.SERIF);brandRow.addView(sprig,new LinearLayout.LayoutParams(dp(34),dp(36)));
        TextView brand=label("MY SAFE SPACE",12,SAGE_DARK,true,Typeface.DEFAULT);brand.setLetterSpacing(.14f);brandRow.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
        TextView sound=label(soundEnabled?"♫":"♪",21,SAGE_DARK,true,Typeface.DEFAULT);sound.setGravity(Gravity.CENTER);sound.setBackground(solid(MINT,18,LINE));brandRow.addView(sound,new LinearLayout.LayoutParams(dp(40),dp(38)));sound.setOnClickListener(v->{feedback(v,false);soundEnabled=!soundEnabled;prefs.edit().putBoolean("sound",soundEnabled).apply();sound.setText(soundEnabled?"♫":"♪");Toast.makeText(this,soundEnabled?"Звук включён":"Звук выключен",Toast.LENGTH_SHORT).show();});
        header.addView(brandRow);root.addView(header);
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(false);scroll.setClipToPadding(false);content=column();content.setPadding(dp(18),dp(5),dp(18),dp(24));scroll.addView(content);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        nav=row();nav.setPadding(dp(7),dp(7),dp(7),dp(7));nav.setBackgroundColor(PAPER);nav.setElevation(dp(8));String[] tabs={"Главная","Дневник","Календарь","Поддержка","Профиль"};String[] icons={"⌂","▤","▦","♡","◯"};
        for(int i=0;i<tabs.length;i++){final String tab=tabs[i];LinearLayout item=column();item.setGravity(Gravity.CENTER);item.setPadding(0,dp(4),0,dp(4));TextView ic=label(icons[i],21,SAGE,true,Typeface.DEFAULT);ic.setGravity(Gravity.CENTER);TextView tx=label(tabs[i],9,MUTED,false,Typeface.DEFAULT);tx.setGravity(Gravity.CENTER);item.addView(ic);item.addView(tx);item.setOnClickListener(v->{feedback(v,false);navigate(tab);});nav.addView(item,new LinearLayout.LayoutParams(0,-2,1));}
        root.addView(nav);
    }

    private void navigate(String tab){current=tab;showPage(tab);}
    private void showPage(String tab){current=tab;content.removeAllViews();switch(tab){case "Главная":showHome();break;case "Дневник":showJournal();break;case "Календарь":showCalendar();break;case "Поддержка":showSupport();break;case "Профиль":showProfile();break;case "Статистика":showStats();break;}
        content.setAlpha(0f);content.setTranslationY(dp(8));content.animate().alpha(1f).translationY(0).setDuration(260).setInterpolator(new DecelerateInterpolator()).start();
    }
    private void title(String s,String sub){TextView h=label(s,29,INK,false,Typeface.SERIF);h.setPadding(0,dp(4),0,dp(3));margins(h,3);if(sub!=null&&!sub.isEmpty()){TextView p=label(sub,13,MUTED,false,Typeface.DEFAULT);p.setLineSpacing(dp(2),1f);margins(p,16);}}
    private LinearLayout card(){LinearLayout c=column();c.setPadding(dp(17),dp(16),dp(17),dp(16));c.setBackground(solid(PAPER,24,LINE));c.setElevation(dp(2));margins(c,13);return c;}
    private TextView action(String s,Runnable run,boolean primary){TextView b=label(s,14,primary?WHITE:INK,true,Typeface.DEFAULT);b.setGravity(Gravity.CENTER);b.setPadding(dp(15),dp(14),dp(15),dp(14));b.setBackground(primary?gradient(SAGE,Color.rgb(141,163,132),GradientDrawable.Orientation.LEFT_RIGHT):solid(MINT,18,LINE));b.setOnClickListener(v->{feedback(v,primary);v.animate().scaleX(.98f).scaleY(.98f).setDuration(75).withEndAction(()->v.animate().scaleX(1f).scaleY(1f).setDuration(100).start()).start();run.run();});return b;}
    private TextView chip(String s,boolean active,Runnable run){TextView t=label(s,12,active?WHITE:INK,false,Typeface.DEFAULT);t.setGravity(Gravity.CENTER);t.setPadding(dp(13),dp(10),dp(13),dp(10));t.setBackground(active?solid(SAGE,18,0):solid(MINT,18,LINE));t.setOnClickListener(v->{feedback(v,false);run.run();});return t;}
    private void headingIn(LinearLayout c,String s,int size){TextView t=label(s,size,INK,true,Typeface.DEFAULT);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(8);c.addView(t,p);}

    private void showHome(){
        title("Твоё тихое место","Здесь можно выдохнуть. Тебе не нужно быть сильной каждую минуту.");
        LinearLayout hero=card();hero.setBackground(gradient(Color.rgb(231,238,224),Color.rgb(247,246,238),GradientDrawable.Orientation.TL_BR));
        TextView little=label("ДОБРО ПОЖАЛОВАТЬ ДОМОЙ",10,SAGE_DARK,true,Typeface.DEFAULT);little.setLetterSpacing(.12f);hero.addView(little);
        TextView h=label("Можно просто быть собой. ♡",24,INK,false,Typeface.SERIF);h.setPadding(0,dp(10),0,dp(7));hero.addView(h);
        TextView body=label("Даже если сегодня было непросто — ты заслуживаешь нежности и заботы.",14,MUTED,false,Typeface.DEFAULT);body.setLineSpacing(dp(3),1f);hero.addView(body);
        addSpace(hero,13);hero.addView(action("Я плакала сегодня  ·  ＋",()->showCryForm(),true));
        LinearLayout quick=card();headingIn(quick,"Твои маленькие шаги",16);
        TextView q1=label("♡  Записать мысли",14,INK,true,Typeface.DEFAULT);quick.addView(q1);TextView q2=label("Слова могут остаться только здесь.",12,MUTED,false,Typeface.DEFAULT);quick.addView(q2);addSpace(quick,10);quick.addView(action("Открыть дневник",()->navigate("Дневник"),false));
        LinearLayout summary=card();headingIn(summary,"Твои отметки",16);TextView num=label(countThisMonth()+" дней",27,SAGE_DARK,false,Typeface.SERIF);summary.addView(num);summary.addView(label("ты отмечала, что плакала в этом месяце",12,MUTED,false,Typeface.DEFAULT));addSpace(summary,8);summary.addView(action("Посмотреть календарь",()->navigate("Календарь"),false));
        LinearLayout sounds=card();headingIn(sounds,"Звуки природы",16);sounds.addView(label("Можно включить тихий фон, пока отдыхаешь или пишешь.",12,MUTED,false,Typeface.DEFAULT));addSpace(sounds,10);LinearLayout soundRow=row();TextView rain=action("☂  Дождь",()->playNature(1),false);TextView forest=action("♧  Лес",()->playNature(2),false);soundRow.addView(rain,new LinearLayout.LayoutParams(0,-2,1));View gap=new View(this);soundRow.addView(gap,new LinearLayout.LayoutParams(dp(8),1));soundRow.addView(forest,new LinearLayout.LayoutParams(0,-2,1));sounds.addView(soundRow);addSpace(sounds,8);sounds.addView(action("Остановить звук",()->stopNature(),false));
        TextView note=label("«Ты не обязана справляться со всем сразу».",15,SAGE_DARK,false,Typeface.SERIF);note.setGravity(Gravity.CENTER);note.setPadding(dp(15),dp(15),dp(15),dp(20));margins(note,4);
    }

    private void showCryForm(){showCryForm(System.currentTimeMillis());}
    private void showCryForm(long timestamp){pendingCryTime=timestamp;selectedCauses.clear();content.removeAllViews();title("Ты плакала ♡","Спасибо, что отмечаешь это. Здесь нет осуждения.");
        LinearLayout c=card();headingIn(c,"Из-за чего?",16);TextView hint=label("Можно выбрать несколько причин.",12,MUTED,false,Typeface.DEFAULT);c.addView(hint);addSpace(c,10);
        LinearLayout[] wraps={row(),row(),row(),row(),row()};for(int i=0;i<CAUSES.length;i++){final String cause=CAUSES[i];final TextView[] ref=new TextView[1];TextView t=chip(cause,false,()->{if(selectedCauses.contains(cause))selectedCauses.remove(cause);else selectedCauses.add(cause);ref[0].setBackground(selectedCauses.contains(cause)?solid(SAGE,18,0):solid(MINT,18,LINE));ref[0].setTextColor(selectedCauses.contains(cause)?WHITE:INK);});ref[0]=t;wraps[i/2].addView(t,new LinearLayout.LayoutParams(0,-2,1));if(i%2==0){View spacer=new View(this);wraps[i/2].addView(spacer,new LinearLayout.LayoutParams(dp(7),1));}}
        for(LinearLayout r:wraps){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(7);c.addView(r,p);}
        headingIn(c,"Хочешь добавить пару слов?",15);EditText details=new EditText(this);details.setTextSize(14);details.setTextColor(INK);details.setHintTextColor(MUTED);details.setHint("Что случилось или что ты чувствовала…");details.setMinLines(3);details.setGravity(Gravity.TOP|Gravity.START);details.setPadding(dp(12),dp(12),dp(12),dp(12));details.setBackground(solid(BG,16,LINE));c.addView(details);
        addSpace(c,14);c.addView(action("Сохранить отметку",()->{if(selectedCauses.isEmpty()){Toast.makeText(this,"Выбери хотя бы одну причину",Toast.LENGTH_SHORT).show();return;}StringBuilder causesText=new StringBuilder();for(String s:selectedCauses){if(causesText.length()>0)causesText.append(", ");causesText.append(s);}long when=pendingCryTime>0?pendingCryTime:System.currentTimeMillis();cries.add(0,new CryRecord(when,causesText.toString(),details.getText().toString().trim()));pendingCryTime=-1L;saveData();showSuccess();},true));
        TextView cancel=action("Назад",()->navigate("Главная"),false);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.topMargin=dp(8);c.addView(cancel,cp);
    }
    private void showSuccess(){content.removeAllViews();LinearLayout c=card();c.setGravity(Gravity.CENTER);TextView icon=label("❧",55,SAGE,true,Typeface.SERIF);icon.setGravity(Gravity.CENTER);c.addView(icon);TextView t=label("Спасибо, что поделилась",24,INK,false,Typeface.SERIF);t.setGravity(Gravity.CENTER);t.setPadding(0,dp(12),0,dp(8));c.addView(t);TextView p=label("Твоя отметка сохранена.\nТы справляешься так, как можешь — и этого достаточно.",14,MUTED,false,Typeface.DEFAULT);p.setGravity(Gravity.CENTER);c.addView(p);addSpace(c,20);c.addView(action("Посмотреть календарь",()->navigate("Календарь"),true));addSpace(c,7);c.addView(action("На главную",()->navigate("Главная"),false));c.setScaleX(.96f);c.setScaleY(.96f);c.animate().scaleX(1f).scaleY(1f).setDuration(260).start();}

    private void showCalendar(){
        title("Календарь","Здесь отмечены дни, когда ты плакала. Только факты — без оценок.");
        LinearLayout c=card();LinearLayout monthRow=row();TextView prev=label("‹",30,SAGE_DARK,true,Typeface.SERIF);prev.setGravity(Gravity.CENTER);monthRow.addView(prev,new LinearLayout.LayoutParams(dp(42),dp(42)));
        TextView month=label(monthName(visibleMonth),18,INK,true,Typeface.SERIF);month.setGravity(Gravity.CENTER);monthRow.addView(month,new LinearLayout.LayoutParams(0,-2,1));TextView next=label("›",30,SAGE_DARK,true,Typeface.SERIF);next.setGravity(Gravity.CENTER);monthRow.addView(next,new LinearLayout.LayoutParams(dp(42),dp(42)));c.addView(monthRow);
        prev.setOnClickListener(v->{feedback(v,false);visibleMonth.add(Calendar.MONTH,-1);selectedDate.setTime(visibleMonth.getTime());selectedDate.set(Calendar.DAY_OF_MONTH,1);showCalendar();});next.setOnClickListener(v->{feedback(v,false);Calendar now=Calendar.getInstance();Calendar target=(Calendar)visibleMonth.clone();target.add(Calendar.MONTH,1);if(target.compareTo(now)<=0){visibleMonth=target;selectedDate.setTime(visibleMonth.getTime());selectedDate.set(Calendar.DAY_OF_MONTH,1);showCalendar();}});
        LinearLayout week=row();String[] days={"Пн","Вт","Ср","Чт","Пт","Сб","Вс"};for(String d:days){TextView t=label(d,11,MUTED,true,Typeface.DEFAULT);t.setGravity(Gravity.CENTER);week.addView(t,new LinearLayout.LayoutParams(0,dp(34),1));}c.addView(week);
        Calendar first=(Calendar)visibleMonth.clone();first.set(Calendar.DAY_OF_MONTH,1);int offset=(first.get(Calendar.DAY_OF_WEEK)+5)%7;int count=first.getActualMaximum(Calendar.DAY_OF_MONTH);int cells=((offset+count+6)/7)*7;
        for(int w=0;w<cells/7;w++){LinearLayout line=row();for(int col=0;col<7;col++){int day=w*7+col-offset+1;FrameLayout cell=new FrameLayout(this);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(46),1);if(day>0&&day<=count){Calendar date=(Calendar)visibleMonth.clone();date.set(Calendar.DAY_OF_MONTH,day);String key=dayKey(date);boolean has=hasCry(key);boolean chosen=dayKey(selectedDate).equals(key);LinearLayout inner=column();inner.setGravity(Gravity.CENTER);inner.setBackground(solid(chosen?SAGE_LIGHT:Color.TRANSPARENT,14,chosen?SAGE:0));TextView n=label(String.valueOf(day),13,has?SAGE_DARK:INK,has,Typeface.DEFAULT);n.setGravity(Gravity.CENTER);inner.addView(n);TextView dot=label(has?"•":" ",13,SAGE,true,Typeface.DEFAULT);dot.setGravity(Gravity.CENTER);inner.addView(dot);cell.addView(inner,new FrameLayout.LayoutParams(-1,-1));cell.setOnClickListener(v->{feedback(v,false);selectedDate.setTime(date.getTime());showCalendar();});}
                line.addView(cell,lp);}c.addView(line);}
        TextView legend=label("●  день с отметкой о слезах",11,SAGE_DARK,false,Typeface.DEFAULT);legend.setPadding(0,dp(9),0,0);c.addView(legend);
        LinearLayout dayCard=card();String selectedLabel=new SimpleDateFormat("d MMMM yyyy",new Locale("ru")).format(selectedDate.getTime());headingIn(dayCard,selectedLabel,16);ArrayList<CryRecord> records=recordsFor(dayKey(selectedDate));if(records.isEmpty()){dayCard.addView(label("В этот день отметок нет. И это тоже нормально ♡",13,MUTED,false,Typeface.DEFAULT));}else{for(CryRecord r:records){TextView item=label("Я плакала · "+new SimpleDateFormat("HH:mm",Locale.getDefault()).format(new Date(r.time))+"\nПричина: "+r.causes+(r.note.isEmpty()?"":"\n"+r.note),13,INK,false,Typeface.DEFAULT);item.setLineSpacing(dp(3),1f);item.setPadding(0,dp(8),0,dp(8));dayCard.addView(item);}}
        LinearLayout actions=card();headingIn(actions,"Быстрая отметка",15);actions.addView(action("Я плакала в этот день",()->{Calendar chosen=(Calendar)selectedDate.clone();if(!dayKey(chosen).equals(dayKey(Calendar.getInstance()))){chosen.set(Calendar.HOUR_OF_DAY,12);chosen.set(Calendar.MINUTE,0);chosen.set(Calendar.SECOND,0);chosen.set(Calendar.MILLISECOND,0);}showCryForm(chosen.getTimeInMillis());},true));
    }
    private String monthName(Calendar c){return new SimpleDateFormat("LLLL yyyy",new Locale("ru")).format(c.getTime());}
    private String dayKey(Calendar c){return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(c.getTime());}
    private boolean hasCry(String key){for(CryRecord r:cries)if(r.day().equals(key))return true;return false;}
    private ArrayList<CryRecord> recordsFor(String key){ArrayList<CryRecord> out=new ArrayList<>();for(CryRecord r:cries)if(r.day().equals(key))out.add(r);return out;}

    private void showJournal(){title("Дневник","Можно записать мысли, даже если они пока не складываются в слова.");LinearLayout c=card();headingIn(c,"Новая запись",16);EditText field=new EditText(this);field.setTextColor(INK);field.setHintTextColor(MUTED);field.setTextSize(14);field.setGravity(Gravity.TOP|Gravity.START);field.setMinLines(4);field.setPadding(dp(13),dp(13),dp(13),dp(13));field.setHint("Что хочется выпустить из головы?");field.setBackground(solid(BG,16,LINE));c.addView(field);addSpace(c,10);c.addView(action("Сохранить запись",()->{String s=field.getText().toString().trim();if(s.isEmpty()){Toast.makeText(this,"Добавь хотя бы пару слов",Toast.LENGTH_SHORT).show();return;}journal.add(0,new JournalEntry(System.currentTimeMillis(),s));saveData();field.setText("");hideKeyboard(field);Toast.makeText(this,"Запись сохранена",Toast.LENGTH_SHORT).show();showJournal();},true));
        LinearLayout history=card();headingIn(history,"Твои записи",16);if(journal.isEmpty())history.addView(label("Здесь появятся твои записи. Не торопись.",13,MUTED,false,Typeface.DEFAULT));else for(int i=0;i<journal.size();i++){JournalEntry e=journal.get(i);TextView entry=label(new SimpleDateFormat("d MMMM · HH:mm",new Locale("ru")).format(new Date(e.time))+"\n"+e.note,14,INK,false,Typeface.DEFAULT);entry.setLineSpacing(dp(3),1f);entry.setPadding(0,dp(10),0,dp(10));history.addView(entry);if(i<journal.size()-1){View line=new View(this);line.setBackgroundColor(LINE);history.addView(line,new LinearLayout.LayoutParams(-1,dp(1)));}}}

    private void showStats(){title("Статистика","Не чтобы сравнивать себя с кем-то, а чтобы замечать закономерности.");LinearLayout c=card();headingIn(c,"Отметки за этот месяц",15);TextView n=label(String.valueOf(countThisMonth()),42,SAGE_DARK,false,Typeface.SERIF);c.addView(n);c.addView(label("дней с отметкой о слезах",12,MUTED,false,Typeface.DEFAULT));
        LinearLayout causes=card();headingIn(causes,"Причины, которые ты отмечала",15);LinkedHashMap<String,Integer> counts=new LinkedHashMap<>();for(CryRecord r:cries){for(String raw:r.causes.split(",")){String s=raw.trim();counts.put(s,counts.containsKey(s)?counts.get(s)+1:1);}}if(counts.isEmpty())causes.addView(label("Пока нет данных. Когда появятся отметки, здесь будет обзор.",13,MUTED,false,Typeface.DEFAULT));else{int max=1;for(Integer v:counts.values())max=Math.max(max,v);for(String k:counts.keySet()){LinearLayout line=row();TextView name=label(k,12,INK,false,Typeface.DEFAULT);line.addView(name,new LinearLayout.LayoutParams(dp(105),-2));ProgressBar bar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);bar.setMax(max);bar.setProgress(counts.get(k));if(android.os.Build.VERSION.SDK_INT>=21)bar.setProgressTintList(android.content.res.ColorStateList.valueOf(SAGE));line.addView(bar,new LinearLayout.LayoutParams(0,dp(7),1));TextView count=label("  "+counts.get(k),11,MUTED,false,Typeface.DEFAULT);line.addView(count);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(28));causes.addView(line,p);}}addSpace(causes,4);causes.addView(action("Открыть календарь",()->navigate("Календарь"),false));
        LinearLayout total=card();headingIn(total,"Всего",15);total.addView(label(cries.size()+" отметок о слезах  ·  "+journal.size()+" записей в дневнике",13,MUTED,false,Typeface.DEFAULT));}
    private int countThisMonth(){Calendar now=Calendar.getInstance();HashSet<String> days=new HashSet<>();for(CryRecord r:cries){Calendar c=Calendar.getInstance();c.setTimeInMillis(r.time);if(c.get(Calendar.YEAR)==now.get(Calendar.YEAR)&&c.get(Calendar.MONTH)==now.get(Calendar.MONTH))days.add(r.day());}return days.size();}

    private void showSupport(){title("Я рядом ♡","Это небольшой локальный помощник. Твои сообщения не отправляются в интернет.");LinearLayout c=card();TextView welcome=label("Привет. Можешь рассказать, как ты себя чувствуешь. Я не буду тебя осуждать.",14,INK,false,Typeface.DEFAULT);welcome.setPadding(dp(13),dp(13),dp(13),dp(13));welcome.setBackground(solid(MINT,17,LINE));c.addView(welcome);String[] prompts={"Мне грустно","Я тревожусь","Я чувствую одиночество","Мне нужно успокоиться"};for(String p:prompts){LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=dp(8);TextView b=chip(p,false,()->{addChatLine(c,"Ты: "+p,false);addChatLine(c,"Рядом: "+reply(p),true);});c.addView(b,lp);}EditText input=new EditText(this);input.setTextColor(INK);input.setHintTextColor(MUTED);input.setHint("Написать сообщение…");input.setBackground(solid(BG,17,LINE));input.setPadding(dp(12),dp(12),dp(12),dp(12));LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,-2);ip.topMargin=dp(13);c.addView(input,ip);c.addView(action("Отправить",()->{String s=input.getText().toString().trim();if(s.isEmpty())return;addChatLine(c,"Ты: "+s,false);addChatLine(c,"Рядом: "+reply(s),true);input.setText("");hideKeyboard(input);},true));
        LinearLayout disclaimer=card();headingIn(disclaimer,"Важно",14);disclaimer.addView(label("Это не психолог и не экстренная служба. Если есть непосредственная опасность, обратись к человеку рядом или в местную экстренную службу.",12,MUTED,false,Typeface.DEFAULT));}
    private void addChatLine(LinearLayout c,String s,boolean bot){TextView t=label(s,13,INK,false,Typeface.DEFAULT);t.setPadding(dp(12),dp(11),dp(12),dp(11));t.setLineSpacing(dp(2),1f);t.setBackground(solid(bot?MINT:Color.rgb(245,245,237),15,LINE));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(bot? -1:dp(285),-2);p.topMargin=dp(8);if(!bot)p.gravity=Gravity.RIGHT;c.addView(t,p);}
    private String reply(String s){String x=s.toLowerCase(new Locale("ru"));if(x.contains("трев")||x.contains("успоко"))return "Попробуй почувствовать стопы на полу и мягко выдохнуть чуть дольше, чем вдыхаешь. Не нужно делать это идеально. Просто побудь здесь.";if(x.contains("одиноч"))return "Одиночество может быть очень тяжёлым. Есть ли кто-то безопасный, кому можно написать: «Мне сейчас нужна компания»?";if(x.contains("груст")||x.contains("плач"))return "Мне жаль, что сейчас больно. Не нужно останавливать слёзы или объяснять их. Может помочь вода, плед или немного тишины.";return "Я тебя слышу. Не обязательно сразу искать решение. Хочешь рассказать чуть больше или выберем один маленький шаг на сейчас?";}

    private void showProfile(){title("Твоё пространство","Небольшие настройки и забота о приватности.");LinearLayout p=card();headingIn(p,"Внешний вид",15);p.addView(label("Мягкие природные оттенки · кремовый фон · шалфейный зелёный",13,MUTED,false,Typeface.DEFAULT));addSpace(p,12);headingIn(p,"Звук и ощущения",15);Switch sound=new Switch(this);sound.setText("Звуковые эффекты");sound.setTextColor(INK);sound.setChecked(soundEnabled);p.addView(sound);sound.setOnCheckedChangeListener((b,v)->{soundEnabled=v;prefs.edit().putBoolean("sound",v).apply();if(v)play(sndOpen);});Switch haptics=new Switch(this);haptics.setText("Лёгкая вибрация при нажатии");haptics.setTextColor(INK);haptics.setChecked(hapticEnabled);p.addView(haptics);haptics.setOnCheckedChangeListener((b,v)->{hapticEnabled=v;prefs.edit().putBoolean("haptics",v).apply();});
        LinearLayout privacy=card();headingIn(privacy,"Твои данные",15);privacy.addView(label("Отметки о слезах и дневник хранятся только на этом устройстве. В этой версии они не синхронизируются с облаком.",13,MUTED,false,Typeface.DEFAULT));privacy.addView(action("Посмотреть статистику",()->navigate("Статистика"),false));
        LinearLayout about=card();headingIn(about,"My Safe Space",15);about.addView(label("Версия 2.0 · приложение для бережного отношения к себе.",12,MUTED,false,Typeface.DEFAULT));about.addView(action("Удалить все данные",()->new android.app.AlertDialog.Builder(this).setTitle("Удалить все записи?").setMessage("Отметки о слезах и дневник будут удалены без возможности восстановления.").setNegativeButton("Отмена",null).setPositiveButton("Удалить",(d,w)->{cries.clear();journal.clear();saveData();navigate("Главная");}).show(),false));}

    private void hideKeyboard(View v){try{((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(v.getWindowToken(),0);}catch(Exception ignored){}}
    private void loadData(){
        try{JSONArray a=new JSONArray(prefs.getString("cries","[]"));for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);cries.add(new CryRecord(o.optLong("time"),o.optString("causes"),o.optString("note")));}}catch(Exception ignored){}
        try{JSONArray a=new JSONArray(prefs.getString("journal","[]"));for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);journal.add(new JournalEntry(o.optLong("time"),o.optString("note")));}}catch(Exception ignored){}
        // Preserve diary entries from the previous installed version.
        if(journal.isEmpty()){
            String legacy=prefs.getString("entries","");
            if(!legacy.isEmpty()){
                for(String line:legacy.split("\\n")){
                    if(line.trim().isEmpty())continue;
                    String[] parts=line.split(" · ",3);long time=System.currentTimeMillis();String note=line;
                    if(parts.length>=2){try{time=new SimpleDateFormat("dd.MM.yyyy HH:mm",Locale.getDefault()).parse(parts[0]).getTime();}catch(Exception ignored){}note=parts.length==3?parts[2]:parts[parts.length-1];}
                    journal.add(new JournalEntry(time,note));
                }
                saveData();
            }
        }
    }
    private void saveData(){try{JSONArray a=new JSONArray();for(CryRecord r:cries){JSONObject o=new JSONObject();o.put("time",r.time);o.put("causes",r.causes);o.put("note",r.note);a.put(o);}JSONArray j=new JSONArray();for(JournalEntry e:journal){JSONObject o=new JSONObject();o.put("time",e.time);o.put("note",e.note);j.put(o);}prefs.edit().putString("cries",a.toString()).putString("journal",j.toString()).apply();}catch(Exception ignored){}}
    @Override protected void onDestroy(){super.onDestroy();stopNature();if(soundPool!=null){soundPool.release();soundPool=null;}}
    @Override public void onBackPressed(){if(!current.equals("Главная")){navigate("Главная");}else super.onBackPressed();}
}
