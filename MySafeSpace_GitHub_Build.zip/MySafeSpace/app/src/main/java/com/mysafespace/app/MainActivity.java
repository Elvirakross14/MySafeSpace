package com.mysafespace.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    final int BG=Color.rgb(23,19,29), PANEL=Color.rgb(36,30,44), PANEL2=Color.rgb(48,40,58);
    final int WHITE=Color.rgb(245,239,247), MUTED=Color.rgb(185,173,191), PINK=Color.rgb(233,169,199), LAV=Color.rgb(185,168,237);
    LinearLayout base, content, nav; String current="Главная"; int intensity=0; String mood="";
    SharedPreferences prefs; ArrayList<String> entries=new ArrayList<>();
    public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        prefs=getSharedPreferences("safe_space",MODE_PRIVATE); load(); buildShell(); showHome();}
    GradientDrawable shape(int color,int radius,int stroke){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(radius);if(stroke!=0)d.setStroke(1,stroke);return d;}
    TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);t.setGravity(Gravity.CENTER_VERTICAL);return t;}
    LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
    LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    void pad(View v,int n){v.setPadding(n,n,n,n);}
    TextView button(String s,Runnable r,boolean primary){TextView t=text(s,14,primary?BG:WHITE,true);t.setGravity(Gravity.CENTER);t.setPadding(14,13,14,13);t.setBackground(shape(primary?PINK:PANEL2,24,primary?0:PANEL2));t.setOnClickListener(v->r.run());return t;}
    void buildShell(){base=column();base.setBackgroundColor(BG);setContentView(base);
        LinearLayout header=column();pad(header,20);TextView brand=text("☾  MY SAFE SPACE",12,PINK,true);header.addView(brand);TextView title=text("Твоё тихое место",25,WHITE,true);header.addView(title);base.addView(header);
        ScrollView sc=new ScrollView(this);content=column();content.setPadding(17,4,17,18);sc.addView(content);base.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        nav=row();nav.setBackgroundColor(PANEL);String[] tabs={"Главная","Календарь","Дневник","Поддержка","Профиль"};String[] icons={"⌂","▦","♡","☁","⚙"};
        for(int i=0;i<tabs.length;i++){final String tab=tabs[i];LinearLayout item=column();item.setGravity(Gravity.CENTER);TextView ic=text(icons[i],20,PINK,true);ic.setGravity(Gravity.CENTER);TextView tx=text(tabs[i],10,MUTED,false);tx.setGravity(Gravity.CENTER);item.addView(ic);item.addView(tx);item.setPadding(2,9,2,9);item.setOnClickListener(v->navigate(tab));nav.addView(item,new LinearLayout.LayoutParams(0,-2,1));}
        base.addView(nav);
    }
    void navigate(String tab){current=tab;content.removeAllViews();switch(tab){case "Главная":showHome();break;case "Календарь":showCalendar();break;case "Дневник":showJournal();break;case "Поддержка":showChat();break;default:showProfile();}}
    void heading(String s,String sub){TextView h=text(s,21,WHITE,true);content.addView(h);if(sub!=null){TextView p=text(sub,13,MUTED,false);p.setPadding(0,5,0,12);content.addView(p);}}
    LinearLayout card(){LinearLayout c=column();c.setPadding(16,15,16,15);c.setBackground(shape(PANEL,22,PANEL2));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=12;content.addView(c,lp);return c;}
    void showHome(){heading("Привет, ты дома ☾","Здесь можно выдохнуть. Не нужно притворяться, что всё хорошо.");
        LinearLayout c=card();c.addView(text("Как ты себя чувствуешь?",17,WHITE,true));c.addView(text("Отметь состояние — без правильных и неправильных ответов.",12,MUTED,false));
        String[] moods={"🥲 Немного грустно","🌧 Тяжёлый день","🫧 Тревожно","🕊 Спокойнее"};for(String m:moods)c.addView(button(m,()->{mood=m;Toast.makeText(this,"Чувство отмечено: "+m,Toast.LENGTH_SHORT).show();},false));
        LinearLayout d=card();d.addView(text("Маленькое напоминание",17,PINK,true));d.addView(text("Тебе не нужно заслуживать отдых. Можно остановиться, попить воды и дать себе время.",14,WHITE,false));
        LinearLayout quick=card();quick.addView(text("Быстрый доступ",17,WHITE,true));quick.addView(button("＋ Записать эмоции",()->navigate("Дневник"),true));quick.addView(button("♡ Поговорить с помощником",()->navigate("Поддержка"),false));
        LinearLayout stats=card();stats.addView(text("Твои записи",17,WHITE,true));stats.addView(text(entries.size()+" записей сохранено на этом устройстве",13,MUTED,false));}
    void showJournal(){heading("Дневник эмоций","Записывай только то, чем хочется поделиться с собой.");
        LinearLayout c=card();c.addView(text("Насколько сильные эмоции?",16,WHITE,true));LinearLayout scales=row();for(int i=1;i<=5;i++){final int n=i;TextView b=button(""+i,()->{intensity=n;Toast.makeText(this,"Выбрано: "+n+"/5",Toast.LENGTH_SHORT).show();},false);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1);lp.setMargins(2,8,2,8);scales.addView(b,lp);}c.addView(scales);
        EditText note=new EditText(this);note.setHint("Что произошло? Что хочется сказать себе?");note.setTextColor(WHITE);note.setHintTextColor(MUTED);note.setMinLines(3);note.setGravity(Gravity.TOP);note.setBackground(shape(BG,14,PANEL2));c.addView(note);
        c.addView(button("Сохранить запись",()->{if(intensity==0){Toast.makeText(this,"Сначала выбери силу эмоций от 1 до 5",Toast.LENGTH_SHORT).show();return;}String s=new SimpleDateFormat("dd.MM.yyyy HH:mm",Locale.getDefault()).format(new Date())+" · "+intensity+"/5 · "+note.getText().toString();entries.add(0,s);save();intensity=0;note.setText("");Toast.makeText(this,"Запись сохранена 🤍",Toast.LENGTH_SHORT).show();navigate("Дневник");},true));
        LinearLayout history=card();history.addView(text("История",17,WHITE,true));if(entries.isEmpty())history.addView(text("Пока нет записей. Можно начать в любой момент.",13,MUTED,false));else for(String e:entries)history.addView(text("• "+e,13,WHITE,false));}
    void showCalendar(){heading("Календарь","Твои отметки — не оценка, а способ замечать себя.");LinearLayout c=card();Calendar cal=Calendar.getInstance();c.addView(text(new SimpleDateFormat("LLLL yyyy",new Locale("ru")).format(cal.getTime()),18,PINK,true));c.addView(text("В этой первой сборке календарь показывает количество сохранённых записей. Полная сетка календаря появится в следующем обновлении.",13,MUTED,false));c.addView(text("Всего записей: "+entries.size(),16,WHITE,true));}
    void showChat(){heading("Рядом ☁","Бесплатный локальный помощник. Ответы подготовлены заранее и не отправляются в интернет.");
        LinearLayout c=card();TextView welcome=text("Привет. Я рядом и могу тебя выслушать. Что сейчас больше всего хочется сказать?",14,WHITE,false);welcome.setPadding(12,12,12,12);welcome.setBackground(shape(PANEL2,16,0));c.addView(welcome);
        String[] prompts={"Мне грустно","У меня тревога","Я чувствую одиночество","Мне нужно успокоиться","Я не знаю, что чувствую"};
        for(String p:prompts)c.addView(button(p,()->addBotReply(c,p),false));
        EditText input=new EditText(this);input.setHint("Напиши, что у тебя на душе…");input.setTextColor(WHITE);input.setHintTextColor(MUTED);input.setBackground(shape(BG,14,PANEL2));c.addView(input);
        c.addView(button("Отправить",()->{String s=input.getText().toString().trim();if(s.isEmpty())return;TextView u=text("Ты: "+s,14,PINK,true);u.setPadding(8,12,8,8);c.addView(u);addBotReply(c,s);input.setText("");((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(input.getWindowToken(),0);},true));
        LinearLayout disclaimer=card();disclaimer.addView(text("Важно",14,PINK,true));disclaimer.addView(text("Я не психолог и не экстренная служба. Если ты можешь причинить вред себе или кому-то ещё, обратись к человеку рядом и в местную экстренную службу. В Германии — 112 при непосредственной опасности.",12,MUTED,false));}
    void addBotReply(LinearLayout c,String s){TextView r=text("Помощник: "+reply(s),14,WHITE,false);r.setPadding(12,12,12,12);r.setBackground(shape(PANEL2,16,0));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=8;c.addView(r,lp);}
    String reply(String s){String x=s.toLowerCase(new Locale("ru"));if(x.contains("трев")||x.contains("успоко"))return "Давай попробуем очень маленький шаг. Почувствуй стопы на полу. Медленно вдохни на 4 счёта и выдохни на 6. Повтори несколько раз, только если тебе комфортно. Ты сейчас в настоящем моменте.";if(x.contains("одиноч"))return "Одиночество может ощущаться очень тяжело. Спасибо, что сказала об этом. Есть ли кто-то безопасный, кому можно отправить простое «мне сейчас нужна компания»?";if(x.contains("груст")||x.contains("плач"))return "Мне жаль, что сейчас больно. Тебе не нужно останавливать слёзы или объяснять их. Может быть, сейчас поможет вода, плед или немного тишины?";if(x.contains("не знаю"))return "Это нормально — не сразу понимать свои чувства. Можно начать с тела: ты чувствуешь напряжение, усталость, тяжесть или что-то другое?";return "Я тебя слышу. Не обязательно сразу искать решение. Хочешь рассказать, что произошло, или лучше вместе найти один маленький шаг, который облегчит ближайшие минуты?";}
    void showProfile(){heading("Настройки","Приватность и информация о приложении.");LinearLayout c=card();c.addView(text("My Safe Space · версия 1.0.0",16,WHITE,true));c.addView(text("Все записи хранятся локально на устройстве. Интернет и аккаунт для дневника не требуются.",13,MUTED,false));c.addView(button("Удалить все записи",()->new android.app.AlertDialog.Builder(this).setTitle("Удалить историю?").setMessage("Это действие нельзя отменить.").setNegativeButton("Отмена",null).setPositiveButton("Удалить",(d,w)->{entries.clear();save();navigate("Профиль");}).show(),false));}
    void load(){String raw=prefs.getString("entries","");if(!raw.isEmpty())entries.addAll(Arrays.asList(raw.split("\\n",-1)));}
    void save(){StringBuilder b=new StringBuilder();for(String e:entries){if(b.length()>0)b.append("\n");b.append(e.replace("\n"," "));}prefs.edit().putString("entries",b.toString()).apply();}
}
