package com.mysafespace.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.net.Uri;
import android.os.Bundle;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Locale;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/**
 * My Safe Space 3.0 foundation.
 * Personal entries are stored as one AES/GCM encrypted JSON vault using Android Keystore.
 * The app intentionally works offline; online services are not silently simulated.
 */
public class MainActivity extends Activity {
    private static final String VAULT_ALIAS = "MySafeSpaceVaultKey";
    private static final int REQ_EXPORT = 4101, REQ_IMPORT = 4102, REQ_VOICE = 4103, REQ_THEME_EXPORT = 4104;

    private static int BG, PAPER, SAGE, SAGE_DARK, SAGE_LIGHT, MINT, INK, MUTED, LINE, WHITE;
    private LinearLayout root, content, nav, header;
    private String current = "Главная";
    private SharedPreferences prefs;
    private SoundPool soundPool;
    private MediaPlayer ambience;
    private int ambienceId = 0;
    private int sndTap, sndSave, sndOpen;
    private boolean soundEnabled = true, hapticEnabled = true;
    private boolean vaultProblem = false;
    private String themeName = "Sage nature";
    private EditText voiceTarget;
    private int backupMode = 0;

    private final ArrayList<CryRecord> cries = new ArrayList<>();
    private final ArrayList<JournalEntry> journal = new ArrayList<>();
    private final ArrayList<MemoryEntry> memories = new ArrayList<>();
    private final ArrayList<GoalEntry> goals = new ArrayList<>();
    private final LinkedHashSet<String> hiddenSections = new LinkedHashSet<>();
    private final LinkedHashSet<String> selectedCauses = new LinkedHashSet<>();
    private Calendar visibleMonth = Calendar.getInstance();
    private Calendar selectedDate = Calendar.getInstance();
    private long pendingCryTime = -1L;

    private static final String[] CAUSES = {"Отношения", "Семья", "Одиночество", "Тревога", "Усталость", "Обида", "Разочарование", "Конфликт", "Боль", "Радость", "Другое"};
    private static final String[] MEMORY_TYPES = {"Важный момент", "Фотография", "Заметка", "Цитата", "Голосовая запись", "Памятная дата", "Письмо себе"};
    private static final String[] HIDE_OPTIONS = {"Дневник", "Воспоминания", "Календарь", "Поддержка"};

    private static class CryRecord {
        long time; String causes, note;
        CryRecord(long t, String c, String n) { time=t; causes=c; note=n; }
        String day() { return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date(time)); }
    }
    private static class JournalEntry {
        long time; String title, note;
        JournalEntry(long t, String h, String n) { time=t; title=h; note=n; }
    }
    private static class MemoryEntry {
        long time; String type, title, note;
        MemoryEntry(long t, String y, String h, String n) { time=t; type=y; title=h; note=n; }
    }
    private static class GoalEntry {
        long time; String title; boolean done;
        GoalEntry(long t, String h, boolean d) { time=t; title=h; done=d; }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("safe_space", MODE_PRIVATE);
        soundEnabled = prefs.getBoolean("sound", true);
        hapticEnabled = prefs.getBoolean("haptics", true);
        themeName = prefs.getString("theme", "Sage nature");
        for (String s : prefs.getString("hide_sections", "").split("\\|")) if (!s.trim().isEmpty()) hiddenSections.add(s);
        applyTheme();
        loadData();
        initSounds();
        showSplash();
    }

    private void applyTheme() {
        if ("Soft grunge".equals(themeName)) {
            BG=Color.rgb(241,233,236); PAPER=Color.rgb(252,247,249); SAGE=Color.rgb(158,119,137); SAGE_DARK=Color.rgb(101,67,84);
            SAGE_LIGHT=Color.rgb(235,218,226); MINT=Color.rgb(245,233,238); INK=Color.rgb(65,49,58); MUTED=Color.rgb(139,119,128); LINE=Color.rgb(224,207,216);
        } else if ("Lavender".equals(themeName)) {
            BG=Color.rgb(243,240,249); PAPER=Color.rgb(254,252,255); SAGE=Color.rgb(143,126,174); SAGE_DARK=Color.rgb(91,75,121);
            SAGE_LIGHT=Color.rgb(231,223,245); MINT=Color.rgb(241,236,249); INK=Color.rgb(55,48,68); MUTED=Color.rgb(127,117,146); LINE=Color.rgb(222,214,237);
        } else if ("Dark academia".equals(themeName)) {
            BG=Color.rgb(39,35,33); PAPER=Color.rgb(54,47,43); SAGE=Color.rgb(170,137,99); SAGE_DARK=Color.rgb(221,190,151);
            SAGE_LIGHT=Color.rgb(77,64,54); MINT=Color.rgb(66,56,49); INK=Color.rgb(242,230,213); MUTED=Color.rgb(190,176,157); LINE=Color.rgb(91,78,67);
        } else {
            BG=Color.rgb(246,245,237); PAPER=Color.rgb(255,254,249); SAGE=Color.rgb(111,132,105); SAGE_DARK=Color.rgb(62,83,66);
            SAGE_LIGHT=Color.rgb(225,233,218); MINT=Color.rgb(235,241,229); INK=Color.rgb(43,57,46); MUTED=Color.rgb(119,129,116); LINE=Color.rgb(222,226,215);
        }
        WHITE=Color.WHITE;
        if (getWindow()!=null) {
            getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG);
            getWindow().getDecorView().setSystemUiVisibility("Dark academia".equals(themeName) ? 0 : View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        }
    }

    private void initSounds() {
        try { soundPool = new SoundPool.Builder().setMaxStreams(3).build(); sndTap=soundPool.load(this,R.raw.tap,1); sndSave=soundPool.load(this,R.raw.save,1); sndOpen=soundPool.load(this,R.raw.open,1); }
        catch (Exception ignored) { }
    }
    private void play(int id) { if(soundEnabled && soundPool!=null && id!=0) try { soundPool.play(id,.38f,.38f,1,0,1f); } catch(Exception ignored) { } }
    private void playNature(int which) {
        if(ambience!=null && ambienceId==which && ambience.isPlaying()) { stopNature(); return; }
        stopNature();
        try { ambience=MediaPlayer.create(this,which==1?R.raw.ambience_rain:R.raw.ambience_forest); if(ambience!=null){ambience.setLooping(true);ambience.setVolume(.42f,.42f);ambience.start();ambienceId=which;} }
        catch(Exception e) { stopNature(); Toast.makeText(this,"Не удалось включить звук",Toast.LENGTH_SHORT).show(); }
    }
    private void stopNature() { if(ambience!=null){try{if(ambience.isPlaying())ambience.stop();}catch(Exception ignored){}try{ambience.release();}catch(Exception ignored){}ambience=null;}ambienceId=0; }
    private void feedback(View v,boolean save) { if(hapticEnabled)v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP); play(save?sndSave:sndTap); }

    private void showSplash() {
        LinearLayout splash=column(); splash.setGravity(Gravity.CENTER); splash.setBackground(gradient(BG,SAGE_LIGHT,GradientDrawable.Orientation.TL_BR)); setContentView(splash);
        TextView sprig=label("❧",64,SAGE,true,Typeface.SERIF); sprig.setGravity(Gravity.CENTER); splash.addView(sprig);
        TextView brand=label("My Safe Space",32,INK,false,Typeface.SERIF); brand.setGravity(Gravity.CENTER); brand.setPadding(0,dp(8),0,dp(5)); splash.addView(brand);
        TextView sub=label("твоё личное пространство",13,MUTED,false,Typeface.DEFAULT); sub.setGravity(Gravity.CENTER); splash.addView(sub);
        sprig.setAlpha(0f);sprig.setScaleX(.8f);sprig.setScaleY(.8f);sprig.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(700).start();
        new android.os.Handler().postDelayed(()->{if(!isFinishing()){play(sndOpen);buildShell();showPage("Главная");}},650);
    }

    private GradientDrawable gradient(int a,int b,GradientDrawable.Orientation o) { GradientDrawable d=new GradientDrawable(o,new int[]{a,b}); d.setCornerRadius(dp(24)); return d; }
    private GradientDrawable solid(int c,int radius,int stroke) { GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(dp(radius));if(stroke!=0)d.setStroke(dp(1),stroke);return d; }
    private int dp(float n) { return (int)(n*getResources().getDisplayMetrics().density+0.5f); }
    private TextView label(String s,int size,int color,boolean bold,Typeface face) { TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.CENTER_VERTICAL);if(face!=null)t.setTypeface(face,bold?Typeface.BOLD:Typeface.NORMAL);else if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t; }
    private LinearLayout column() { LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l; }
    private LinearLayout row() { LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l; }
    private void margins(View v,int bottom) { LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(bottom);content.addView(v,p); }
    private void addSpace(LinearLayout into,int h) { into.addView(new View(this),new LinearLayout.LayoutParams(1,dp(h))); }

    private void buildShell() {
        root=column();root.setBackgroundColor(BG);setContentView(root);
        header=column();header.setPadding(dp(18),dp(9),dp(18),dp(8));
        LinearLayout brandRow=row();TextView sprig=label("❧",24,SAGE,true,Typeface.SERIF);brandRow.addView(sprig,new LinearLayout.LayoutParams(dp(32),dp(36)));
        TextView brand=label("MY SAFE SPACE",12,SAGE_DARK,true,Typeface.DEFAULT);brand.setLetterSpacing(.13f);brandRow.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
        TextView shield=label("◈",22,SAGE_DARK,true,Typeface.DEFAULT);shield.setGravity(Gravity.CENTER);shield.setBackground(solid(MINT,18,LINE));brandRow.addView(shield,new LinearLayout.LayoutParams(dp(40),dp(38)));shield.setOnClickListener(v->{feedback(v,false);showQuickHide();});
        header.addView(brandRow);root.addView(header);
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(false);scroll.setClipToPadding(false);content=column();content.setPadding(dp(17),dp(4),dp(17),dp(22));scroll.addView(content);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        nav=row();nav.setPadding(dp(4),dp(6),dp(4),dp(6));nav.setBackgroundColor(PAPER);nav.setElevation(dp(7));
        String[] tabs={"Главная","Профиль","Воспоминания","Статистика","Календарь","Дневник"};String[] icons={"⌂","◯","♡","▥","▦","▤"};
        for(int i=0;i<tabs.length;i++){final String tab=tabs[i];LinearLayout item=column();item.setGravity(Gravity.CENTER);item.setPadding(0,dp(4),0,dp(4));TextView ic=label(icons[i],19,SAGE,true,Typeface.DEFAULT);ic.setGravity(Gravity.CENTER);TextView tx=label(tabs[i],8,MUTED,false,Typeface.DEFAULT);tx.setGravity(Gravity.CENTER);item.addView(ic);item.addView(tx);item.setOnClickListener(v->{feedback(v,false);navigate(tab);});nav.addView(item,new LinearLayout.LayoutParams(0,-2,1));}
        root.addView(nav);
    }

    private void navigate(String tab) { current=tab;showPage(tab); }
    private void showPage(String tab) {
        current=tab;content.removeAllViews();
        if(hiddenSections.contains(tab) && !"Главная".equals(tab) && !"Профиль".equals(tab) && !"Статистика".equals(tab)) { title("Раздел скрыт","Этот раздел выбран для быстрого скрытия.");margins(label("Его содержимое временно не показывается в обычной навигации.",13,MUTED,false,Typeface.DEFAULT),14);margins(action("Настройки приватности",()->navigate("Профиль"),true),0);return; }
        switch(tab){
            case "Главная":showHome();break;case "Дневник":showJournal();break;case "Календарь":showCalendar();break;case "Поддержка":showSupport();break;
            case "Профиль":showProfile();break;case "Статистика":showStats();break;case "Воспоминания":showMemories();break;case "Забота о себе":showCare();break;case "Цели и мечты":showGoals();break;case "Библиотека":showLibrary();break;
            default:showHome();
        }
        content.setAlpha(0f);content.setTranslationY(dp(7));content.animate().alpha(1f).translationY(0).setDuration(220).start();
    }
    private void title(String s,String sub) { TextView h=label(s,28,INK,false,Typeface.SERIF);h.setPadding(0,dp(4),0,dp(3));margins(h,2);if(sub!=null&&!sub.isEmpty()){TextView p=label(sub,13,MUTED,false,Typeface.DEFAULT);p.setLineSpacing(dp(2),1f);margins(p,13);} }
    private LinearLayout card() { LinearLayout c=column();c.setPadding(dp(16),dp(15),dp(16),dp(15));c.setBackground(solid(PAPER,23,LINE));c.setElevation(dp(1));margins(c,12);return c; }
    private TextView action(String s,Runnable run,boolean primary) { TextView b=label(s,14,primary?WHITE:INK,true,Typeface.DEFAULT);b.setGravity(Gravity.CENTER);b.setPadding(dp(14),dp(13),dp(14),dp(13));b.setBackground(primary?gradient(SAGE,Color.rgb(Math.min(255,Color.red(SAGE)+25),Math.min(255,Color.green(SAGE)+23),Math.min(255,Color.blue(SAGE)+24)),GradientDrawable.Orientation.LEFT_RIGHT):solid(MINT,17,LINE));b.setOnClickListener(v->{feedback(v,primary);v.animate().scaleX(.985f).scaleY(.985f).setDuration(65).withEndAction(()->v.animate().scaleX(1f).scaleY(1f).setDuration(90).start()).start();run.run();});return b; }
    private TextView chip(String s,boolean active,Runnable run) { TextView t=label(s,12,active?WHITE:INK,false,Typeface.DEFAULT);t.setGravity(Gravity.CENTER);t.setPadding(dp(12),dp(9),dp(12),dp(9));t.setBackground(active?solid(SAGE,18,0):solid(MINT,18,LINE));t.setOnClickListener(v->{feedback(v,false);run.run();});return t; }
    private void headingIn(LinearLayout c,String s,int size) { TextView t=label(s,size,INK,true,Typeface.DEFAULT);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(8);c.addView(t,p); }

    private void showHome() {
        title("Твоё тихое место","Не нужно быть идеальной. Здесь всё можно делать в своём темпе.");
        if(vaultProblem){LinearLayout warning=card();headingIn(warning,"Локальное хранилище недоступно",15);warning.addView(label("Не удалось расшифровать прежние данные. Я не буду перезаписывать их автоматически. Открой профиль и попробуй восстановить резервную копию.",12,MUTED,false,Typeface.DEFAULT));warning.addView(action("Открыть восстановление",()->navigate("Профиль"),true));}
        LinearLayout hero=card();hero.setBackground(gradient(SAGE_LIGHT,BG,GradientDrawable.Orientation.TL_BR));hero.addView(label("ДОБРО ПОЖАЛОВАТЬ ДОМОЙ",10,SAGE_DARK,true,Typeface.DEFAULT));TextView h=label("Можно просто быть собой. ♡",24,INK,false,Typeface.SERIF);h.setPadding(0,dp(8),0,dp(6));hero.addView(h);hero.addView(label(new SimpleDateFormat("EEEE, d MMMM",new Locale("ru")).format(new Date()),13,MUTED,false,Typeface.DEFAULT));addSpace(hero,12);hero.addView(action("Я плакала сегодня  ·  ＋",()->showCryForm(),true));
        LinearLayout stat=card();headingIn(stat,"Твои отмеченные дни",16);TextView number=label(String.valueOf(countAllCryDays()),38,SAGE_DARK,false,Typeface.SERIF);stat.addView(number);stat.addView(label("дней с отметкой о слезах · без оценок и сравнений",12,MUTED,false,Typeface.DEFAULT));addSpace(stat,8);stat.addView(action("Открыть календарь",()->navigate("Календарь"),false));
        LinearLayout quick=card();headingIn(quick,"Твоё пространство",16);quick.addView(action("✎  Записать мысли",()->navigate("Дневник"),false));addSpace(quick,7);quick.addView(action("♡  Сохранить воспоминание",()->navigate("Воспоминания"),false));addSpace(quick,7);quick.addView(action("☁  Мне нужна поддержка",()->navigate("Поддержка"),false));addSpace(quick,7);quick.addView(action("❀  Забота о себе",()->navigate("Забота о себе"),false));addSpace(quick,7);quick.addView(action("✧  Мои цели и мечты",()->navigate("Цели и мечты"),false));addSpace(quick,7);quick.addView(action("⌕  Психологическая библиотека",()->navigate("Библиотека"),false));
        LinearLayout sounds=card();headingIn(sounds,"Звуки природы",16);sounds.addView(label("Небольшой фоновый звук для спокойного момента.",12,MUTED,false,Typeface.DEFAULT));addSpace(sounds,8);LinearLayout soundRow=row();soundRow.addView(action("☂  Дождь",()->playNature(1),false),new LinearLayout.LayoutParams(0,-2,1));View gap=new View(this);soundRow.addView(gap,new LinearLayout.LayoutParams(dp(7),1));soundRow.addView(action("♧  Лес",()->playNature(2),false),new LinearLayout.LayoutParams(0,-2,1));sounds.addView(soundRow);addSpace(sounds,7);sounds.addView(action("Остановить звук",()->stopNature(),false));
        TextView quote=label("«Ты не обязана справляться со всем сразу». ",15,SAGE_DARK,false,Typeface.SERIF);quote.setGravity(Gravity.CENTER);quote.setPadding(dp(14),dp(8),dp(14),dp(18));margins(quote,0);
    }

    private void showCryForm() { showCryForm(System.currentTimeMillis()); }
    private void showCryForm(long timestamp) {
        pendingCryTime=timestamp;selectedCauses.clear();content.removeAllViews();title("Я плакала ♡","Можно отметить день и написать причину. Объяснять всё необязательно.");
        LinearLayout c=card();headingIn(c,"Что могло стать причиной?",16);c.addView(label("Можно выбрать несколько вариантов или написать своё.",12,MUTED,false,Typeface.DEFAULT));addSpace(c,9);
        LinearLayout[] wraps={row(),row(),row(),row(),row(),row()};for(int i=0;i<CAUSES.length;i++){final String cause=CAUSES[i];final TextView[] ref=new TextView[1];TextView t=chip(cause,false,()->{if(selectedCauses.contains(cause))selectedCauses.remove(cause);else selectedCauses.add(cause);ref[0].setBackground(selectedCauses.contains(cause)?solid(SAGE,18,0):solid(MINT,18,LINE));ref[0].setTextColor(selectedCauses.contains(cause)?WHITE:INK);});ref[0]=t;LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,-2,1);wraps[i/2].addView(t,cp);if(i%2==0){View space=new View(this);wraps[i/2].addView(space,new LinearLayout.LayoutParams(dp(6),1));}}
        for(LinearLayout r:wraps){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(6);c.addView(r,p);}
        headingIn(c,"Хочешь рассказать подробнее?",15);EditText details=new EditText(this);details.setTextSize(14);details.setTextColor(INK);details.setHintTextColor(MUTED);details.setHint("Что произошло? Что тебя задело? Можно оставить пустым.");details.setMinLines(3);details.setGravity(Gravity.TOP|Gravity.START);details.setPadding(dp(12),dp(12),dp(12),dp(12));details.setBackground(solid(BG,15,LINE));c.addView(details);
        addSpace(c,12);c.addView(action("Сохранить день",()->{StringBuilder b=new StringBuilder();for(String s:selectedCauses){if(b.length()>0)b.append(", ");b.append(s);}long when=pendingCryTime>0?pendingCryTime:System.currentTimeMillis();cries.add(0,new CryRecord(when,b.toString(),details.getText().toString().trim()));pendingCryTime=-1L;saveData();showSuccess();},true));addSpace(c,7);c.addView(action("Отмена",()->navigate("Календарь"),false));
    }
    private void showSuccess() { content.removeAllViews();LinearLayout c=card();c.setGravity(Gravity.CENTER);TextView icon=label("♡",54,SAGE,true,Typeface.SERIF);icon.setGravity(Gravity.CENTER);c.addView(icon);TextView t=label("Твоя отметка сохранена",23,INK,false,Typeface.SERIF);t.setGravity(Gravity.CENTER);t.setPadding(0,dp(11),0,dp(7));c.addView(t);TextView p=label("Спасибо, что доверила этому месту часть своей истории.",14,MUTED,false,Typeface.DEFAULT);p.setGravity(Gravity.CENTER);c.addView(p);addSpace(c,18);c.addView(action("Посмотреть календарь",()->navigate("Календарь"),true));addSpace(c,7);c.addView(action("На главную",()->navigate("Главная"),false)); }

    private void showCalendar() {
        title("Календарь слёз","Отмечай только те дни, которыми хочешь поделиться с собой.");LinearLayout c=card();LinearLayout monthRow=row();TextView prev=label("‹",30,SAGE_DARK,true,Typeface.SERIF);prev.setGravity(Gravity.CENTER);monthRow.addView(prev,new LinearLayout.LayoutParams(dp(42),dp(42)));TextView month=label(monthName(visibleMonth),18,INK,true,Typeface.SERIF);month.setGravity(Gravity.CENTER);monthRow.addView(month,new LinearLayout.LayoutParams(0,-2,1));TextView next=label("›",30,SAGE_DARK,true,Typeface.SERIF);next.setGravity(Gravity.CENTER);monthRow.addView(next,new LinearLayout.LayoutParams(dp(42),dp(42)));c.addView(monthRow);
        prev.setOnClickListener(v->{feedback(v,false);visibleMonth.add(Calendar.MONTH,-1);selectedDate.setTime(visibleMonth.getTime());showCalendar();});next.setOnClickListener(v->{feedback(v,false);Calendar now=Calendar.getInstance();Calendar target=(Calendar)visibleMonth.clone();target.add(Calendar.MONTH,1);if(target.compareTo(now)<=0){visibleMonth=target;selectedDate.setTime(visibleMonth.getTime());showCalendar();}});
        LinearLayout week=row();String[] days={"Пн","Вт","Ср","Чт","Пт","Сб","Вс"};for(String d:days){TextView t=label(d,11,MUTED,true,Typeface.DEFAULT);t.setGravity(Gravity.CENTER);week.addView(t,new LinearLayout.LayoutParams(0,dp(32),1));}c.addView(week);
        Calendar first=(Calendar)visibleMonth.clone();first.set(Calendar.DAY_OF_MONTH,1);int offset=(first.get(Calendar.DAY_OF_WEEK)+5)%7;int count=first.getActualMaximum(Calendar.DAY_OF_MONTH);int cells=((offset+count+6)/7)*7;
        for(int w=0;w<cells/7;w++){LinearLayout line=row();for(int col=0;col<7;col++){int day=w*7+col-offset+1;FrameLayout cell=new FrameLayout(this);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(45),1);if(day>0&&day<=count){Calendar date=(Calendar)visibleMonth.clone();date.set(Calendar.DAY_OF_MONTH,day);String key=dayKey(date);boolean has=hasCry(key);boolean chosen=dayKey(selectedDate).equals(key);LinearLayout inner=column();inner.setGravity(Gravity.CENTER);inner.setBackground(solid(chosen?SAGE_LIGHT:Color.TRANSPARENT,13,chosen?SAGE:0));TextView n=label(String.valueOf(day),13,has?SAGE_DARK:INK,has,Typeface.DEFAULT);n.setGravity(Gravity.CENTER);inner.addView(n);TextView dot=label(has?"♥":" ",10,SAGE,true,Typeface.DEFAULT);dot.setGravity(Gravity.CENTER);inner.addView(dot);cell.addView(inner,new FrameLayout.LayoutParams(-1,-1));cell.setOnClickListener(v->{feedback(v,false);selectedDate.setTime(date.getTime());showCalendar();});}line.addView(cell,lp);}c.addView(line);}
        c.addView(label("♥  день, когда ты отметила слёзы",11,SAGE_DARK,false,Typeface.DEFAULT));
        LinearLayout dayCard=card();String selectedLabel=new SimpleDateFormat("d MMMM yyyy",new Locale("ru")).format(selectedDate.getTime());headingIn(dayCard,selectedLabel,16);ArrayList<CryRecord> records=recordsFor(dayKey(selectedDate));if(records.isEmpty())dayCard.addView(label("В этот день пока нет отметок.",13,MUTED,false,Typeface.DEFAULT));else for(CryRecord r:records){TextView item=label("Причина: "+(r.causes.isEmpty()?"не указана":r.causes)+(r.note.isEmpty()?"":"\n\n"+r.note),13,INK,false,Typeface.DEFAULT);item.setLineSpacing(dp(3),1f);item.setPadding(0,dp(7),0,dp(7));dayCard.addView(item);dayCard.addView(action("Редактировать или удалить",()->editCry(r),false));}
        LinearLayout actions=card();headingIn(actions,"Добавить отметку",15);actions.addView(action("Я плакала в этот день",()->{Calendar chosen=(Calendar)selectedDate.clone();chosen.set(Calendar.HOUR_OF_DAY,12);chosen.set(Calendar.MINUTE,0);chosen.set(Calendar.SECOND,0);showCryForm(chosen.getTimeInMillis());},true));
    }
    private void editCry(CryRecord record) {
        LinearLayout box=column();box.setPadding(dp(12),dp(8),dp(12),dp(4));EditText reasons=new EditText(this);reasons.setText(record.causes);reasons.setHint("Причины");box.addView(reasons);EditText note=new EditText(this);note.setText(record.note);note.setHint("Подробности");note.setMinLines(3);box.addView(note);
        new AlertDialog.Builder(this).setTitle("Изменить отметку").setView(box).setNegativeButton("Отмена",null).setNeutralButton("Удалить",(d,w)->{new AlertDialog.Builder(this).setMessage("Удалить эту отметку?").setNegativeButton("Отмена",null).setPositiveButton("Удалить",(dd,ww)->{cries.remove(record);saveData();showCalendar();}).show();}).setPositiveButton("Сохранить",(d,w)->{record.causes=reasons.getText().toString().trim();record.note=note.getText().toString().trim();saveData();showCalendar();}).show();
    }
    private String monthName(Calendar c){return new SimpleDateFormat("LLLL yyyy",new Locale("ru")).format(c.getTime());}
    private String dayKey(Calendar c){return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(c.getTime());}
    private boolean hasCry(String key){for(CryRecord r:cries)if(r.day().equals(key))return true;return false;}
    private ArrayList<CryRecord> recordsFor(String key){ArrayList<CryRecord> out=new ArrayList<>();for(CryRecord r:cries)if(r.day().equals(key))out.add(r);return out;}
    private int countAllCryDays(){HashSet<String> days=new HashSet<>();for(CryRecord r:cries)days.add(r.day());return days.size();}
    private int countThisMonth(){Calendar now=Calendar.getInstance();HashSet<String> days=new HashSet<>();for(CryRecord r:cries){Calendar c=Calendar.getInstance();c.setTimeInMillis(r.time);if(c.get(Calendar.YEAR)==now.get(Calendar.YEAR)&&c.get(Calendar.MONTH)==now.get(Calendar.MONTH))days.add(r.day());}return days.size();}

    private void showJournal() {
        title("Дневник","Твои мысли. В твоём темпе. Можно писать совсем немного.");LinearLayout c=card();headingIn(c,"Новая запись",16);EditText titleField=makeEdit("Название (необязательно)",1);c.addView(titleField);addSpace(c,7);EditText body=makeEdit("Что хочется сохранить?",4);c.addView(body);addSpace(c,7);c.addView(action("🎙  Надиктовать текст",()->startVoice(body),false));addSpace(c,8);c.addView(action("Сохранить запись",()->{String s=body.getText().toString().trim();if(s.isEmpty()){Toast.makeText(this,"Напиши хотя бы пару слов",Toast.LENGTH_SHORT).show();return;}journal.add(0,new JournalEntry(System.currentTimeMillis(),titleField.getText().toString().trim(),s));saveData();hideKeyboard(body);navigate("Дневник");Toast.makeText(this,"Запись сохранена",Toast.LENGTH_SHORT).show();},true));
        LinearLayout history=card();headingIn(history,"Твои страницы",16);if(journal.isEmpty())history.addView(label("Здесь появятся твои записи.",13,MUTED,false,Typeface.DEFAULT));else for(int i=0;i<journal.size();i++){JournalEntry e=journal.get(i);LinearLayout entry=column();entry.setPadding(dp(2),dp(8),dp(2),dp(10));String when=new SimpleDateFormat("d MMMM · HH:mm",new Locale("ru")).format(new Date(e.time));entry.addView(label(e.title.isEmpty()?when:e.title,16,INK,true,Typeface.SERIF));if(!e.title.isEmpty())entry.addView(label(when,10,MUTED,false,Typeface.DEFAULT));TextView text=label(e.note,13,INK,false,Typeface.DEFAULT);text.setLineSpacing(dp(3),1f);text.setPadding(0,dp(6),0,0);entry.addView(text);history.addView(entry);if(i<journal.size()-1){View divider=new View(this);divider.setBackgroundColor(LINE);history.addView(divider,new LinearLayout.LayoutParams(-1,dp(1)));}} }

    private void showMemories() {
        title("Мои воспоминания","Сохраняй моменты, к которым захочется вернуться.");LinearLayout c=card();headingIn(c,"Сохранить воспоминание",16);EditText name=makeEdit("Название момента",1);c.addView(name);addSpace(c,7);Spinner type=new Spinner(this);String[] choices=MEMORY_TYPES;type.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,choices));c.addView(type);addSpace(c,7);EditText note=makeEdit("Почему это важно для тебя?",3);c.addView(note);addSpace(c,8);c.addView(action("Сохранить",()->{String n=name.getText().toString().trim();if(n.isEmpty())n="Без названия";memories.add(0,new MemoryEntry(System.currentTimeMillis(),String.valueOf(type.getSelectedItem()),n,note.getText().toString().trim()));saveData();navigate("Воспоминания");},true));
        LinearLayout list=card();headingIn(list,"Коллекция моментов",16);if(memories.isEmpty())list.addView(label("Пока здесь тихо. Можешь сохранить первый момент.",13,MUTED,false,Typeface.DEFAULT));else for(MemoryEntry m:memories){LinearLayout item=column();item.setPadding(0,dp(8),0,dp(10));item.addView(label(m.type+"  ·  "+new SimpleDateFormat("d MMM yyyy",new Locale("ru")).format(new Date(m.time)),10,SAGE_DARK,true,Typeface.DEFAULT));item.addView(label(m.title,17,INK,true,Typeface.SERIF));if(!m.note.isEmpty())item.addView(label(m.note,13,MUTED,false,Typeface.DEFAULT));list.addView(item);list.addView(action("Удалить воспоминание",()->new AlertDialog.Builder(this).setMessage("Удалить этот момент?").setNegativeButton("Отмена",null).setPositiveButton("Удалить",(d,w)->{memories.remove(m);saveData();navigate("Воспоминания");}).show(),false));}
    }

    private void showStats() {
        title("Статистика","Это обзор истории, а не оценка тебя.");LinearLayout c=card();headingIn(c,"Отмеченные дни",15);c.addView(label(String.valueOf(countAllCryDays()),42,SAGE_DARK,false,Typeface.SERIF));c.addView(label("дней, когда ты отметила, что плакала",12,MUTED,false,Typeface.DEFAULT));addSpace(c,8);c.addView(label("В этом месяце: "+countThisMonth(),13,INK,false,Typeface.DEFAULT));
        LinearLayout causes=card();headingIn(causes,"Причины, которые ты указывала",15);LinkedHashMap<String,Integer> counts=new LinkedHashMap<>();for(CryRecord r:cries){for(String raw:r.causes.split(",")){String s=raw.trim();if(!s.isEmpty())counts.put(s,counts.containsKey(s)?counts.get(s)+1:1);}}if(counts.isEmpty())causes.addView(label("Когда появятся записи с причинами, здесь будет обзор.",13,MUTED,false,Typeface.DEFAULT));else{int max=1;for(Integer v:counts.values())max=Math.max(max,v);for(String k:counts.keySet()){LinearLayout line=row();TextView name=label(k,12,INK,false,Typeface.DEFAULT);line.addView(name,new LinearLayout.LayoutParams(dp(110),-2));ProgressBar bar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);bar.setMax(max);bar.setProgress(counts.get(k));if(android.os.Build.VERSION.SDK_INT>=21)bar.setProgressTintList(android.content.res.ColorStateList.valueOf(SAGE));line.addView(bar,new LinearLayout.LayoutParams(0,dp(7),1));line.addView(label("  "+counts.get(k),11,MUTED,false,Typeface.DEFAULT));causes.addView(line,new LinearLayout.LayoutParams(-1,dp(30)));}}
        LinearLayout total=card();headingIn(total,"Твоё пространство",15);total.addView(label(cries.size()+" отметок · "+journal.size()+" записей · "+memories.size()+" воспоминаний · "+goals.size()+" целей",13,MUTED,false,Typeface.DEFAULT));total.addView(action("Открыть календарь",()->navigate("Календарь"),false));
    }

    private void showSupport() {
        title("Я рядом ♡","Локальный помощник поддержки. Здесь нет подключения к ИИ-сервису.");LinearLayout c=card();TextView welcome=label("Привет. Можешь рассказать, что произошло. Я не буду тебя осуждать и не стану торопить.",14,INK,false,Typeface.DEFAULT);welcome.setPadding(dp(13),dp(13),dp(13),dp(13));welcome.setBackground(solid(MINT,17,LINE));c.addView(welcome);
        String[] prompts={"Мне грустно","Я тревожусь","Я чувствую одиночество","Мне нужно успокоиться","Я не хочу сейчас ничего объяснять"};for(String prompt:prompts){LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=dp(7);c.addView(chip(prompt,false,()->{addChatLine(c,"Ты: "+prompt,false);addChatLine(c,"Рядом: "+reply(prompt),true);}),lp);}
        EditText input=makeEdit("Написать сообщение…",3);LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,-2);ip.topMargin=dp(10);c.addView(input,ip);c.addView(action("🎙  Голосовой ввод",()->startVoice(input),false));addSpace(c,7);c.addView(action("Отправить",()->{String s=input.getText().toString().trim();if(s.isEmpty())return;addChatLine(c,"Ты: "+s,false);addChatLine(c,"Рядом: "+reply(s),true);input.setText("");hideKeyboard(input);},true));
        LinearLayout disclaimer=card();headingIn(disclaimer,"Важно",14);disclaimer.addView(label("Этот локальный помощник использует заранее подготовленные ответы и не заменяет живого человека, психолога или экстренную помощь. Если есть непосредственная опасность, обратись к человеку рядом или в местную экстренную службу.",12,MUTED,false,Typeface.DEFAULT));
    }
    private void addChatLine(LinearLayout c,String s,boolean bot){TextView t=label(s,13,INK,false,Typeface.DEFAULT);t.setPadding(dp(12),dp(10),dp(12),dp(10));t.setLineSpacing(dp(2),1f);t.setBackground(solid(bot?MINT:BG,15,LINE));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(bot?-1:dp(285),-2);p.topMargin=dp(7);if(!bot)p.gravity=Gravity.RIGHT;c.addView(t,p);}
    private String reply(String s){String x=s.toLowerCase(new Locale("ru"));if(x.contains("трев")||x.contains("успоко"))return "Попробуй почувствовать стопы на полу и спокойно выдохнуть. Не нужно делать это идеально. Просто побудь здесь.";if(x.contains("одиноч"))return "Одиночество может быть тяжёлым. Есть ли безопасный человек, которому можно написать: «Мне сейчас нужна компания»?";if(x.contains("груст")||x.contains("плач"))return "Мне жаль, что сейчас больно. Не нужно останавливать слёзы или объяснять их. Может помочь вода, плед или немного тишины.";if(x.contains("не хочу"))return "Хорошо. Не нужно ничего объяснять. Можно просто немного побыть в тишине.";return "Я тебя слышу. Не обязательно сразу искать решение. Хочешь рассказать чуть больше или выбрать один маленький шаг на сейчас?";}

    private void showCare() {
        title("Забота о себе","Не список обязанностей, а идеи, которые можно выбирать.");String[] ideas={"Выпить стакан воды","Открыть окно и подышать","Укутаться в плед","Послушать дождь или лес","Немного потянуться","Отдохнуть от телефона","Написать безопасному человеку"};
        LinearLayout c=card();headingIn(c,"Мягкие идеи",16);c.addView(label("Отмечай только то, что тебе подходит. Ничего не обязательно.",12,MUTED,false,Typeface.DEFAULT));for(String s:ideas){CheckBox cb=new CheckBox(this);cb.setText(s);cb.setTextColor(INK);cb.setButtonTintList(android.content.res.ColorStateList.valueOf(SAGE));cb.setChecked(prefs.getBoolean("care_"+s,false));cb.setOnCheckedChangeListener((b,v)->prefs.edit().putBoolean("care_"+s,v).apply());c.addView(cb);}c.addView(action("Сбросить отметки",()->{for(String s:ideas)prefs.edit().remove("care_"+s).apply();navigate("Забота о себе");},false));
    }

    private void showGoals() {
        title("Цели и мечты","Маленькими шагами или просто мечтать. Без давления.");LinearLayout c=card();headingIn(c,"Добавить желание или цель",16);EditText field=makeEdit("Чего тебе хочется?",2);c.addView(field);addSpace(c,8);c.addView(action("Сохранить",()->{String s=field.getText().toString().trim();if(s.isEmpty())return;goals.add(0,new GoalEntry(System.currentTimeMillis(),s,false));saveData();navigate("Цели и мечты");},true));
        LinearLayout list=card();headingIn(list,"Мои мечты",16);if(goals.isEmpty())list.addView(label("Здесь могут жить большие мечты и совсем маленькие желания.",13,MUTED,false,Typeface.DEFAULT));else for(GoalEntry g:goals){CheckBox cb=new CheckBox(this);cb.setText(g.title);cb.setTextColor(INK);cb.setChecked(g.done);cb.setButtonTintList(android.content.res.ColorStateList.valueOf(SAGE));cb.setOnCheckedChangeListener((b,v)->{g.done=v;saveData();});list.addView(cb);list.addView(action("Удалить",()->new AlertDialog.Builder(this).setMessage("Удалить цель?").setNegativeButton("Отмена",null).setPositiveButton("Удалить",(d,w)->{goals.remove(g);saveData();navigate("Цели и мечты");}).show(),false));}
    }

    private void showLibrary() {
        title("Психологическая библиотека","Небольшие материалы для самопознания. Это образовательные заметки, не диагнозы.");
        addArticle("Эмоциональная усталость","Когда много событий и напряжения накапливаются, отдых может быть важнее попытки заставить себя работать ещё сильнее.");
        addArticle("Личные границы","Границы помогают обозначать, что для тебя приемлемо. Можно начинать с коротких фраз: «Мне нужно подумать» или «Сейчас мне неудобно».");
        addArticle("Заземление","Попробуй заметить пять предметов вокруг, четыре телесных ощущения, три звука, два запаха и один вкус. Если упражнение неприятно, остановись.");
        addArticle("Самосострадание","Попробуй говорить с собой так, как говорила бы с близким человеком, которому сейчас тяжело.");
        addArticle("Когда нужна помощь","Если переживания долго мешают повседневной жизни, можно обратиться к психологу, врачу или другому человеку, которому доверяешь.");
        LinearLayout tests=card();headingIn(tests,"Тесты для самопознания",15);tests.addView(label("В этой сборке не включены клинические тесты. Подбор валидированных опросников, источников и пояснений требует отдельной проверки.",12,MUTED,false,Typeface.DEFAULT));
    }
    private void addArticle(String title,String body){LinearLayout c=card();headingIn(c,title,16);TextView t=label(body,13,INK,false,Typeface.DEFAULT);t.setLineSpacing(dp(3),1f);c.addView(t);}

    private void showProfile() {
        title("Профиль и настройки","Настрой пространство под себя.");LinearLayout p=card();headingIn(p,"Темы оформления",16);String[] themes={"Soft grunge","Sage nature","Lavender","Dark academia"};for(String name:themes){p.addView(chip((themeName.equals(name)?"✓  ":"")+name,themeName.equals(name),()->{themeName=name;prefs.edit().putString("theme",themeName).apply();applyTheme();buildShell();showPage("Профиль");}));LinearLayout.LayoutParams lp=(LinearLayout.LayoutParams)p.getChildAt(p.getChildCount()-1).getLayoutParams();lp.bottomMargin=dp(6);}
        Switch sound=new Switch(this);sound.setText("Звуки интерфейса");sound.setTextColor(INK);sound.setChecked(soundEnabled);p.addView(sound);sound.setOnCheckedChangeListener((b,v)->{soundEnabled=v;prefs.edit().putBoolean("sound",v).apply();if(v)play(sndOpen);});Switch haptics=new Switch(this);haptics.setText("Лёгкая вибрация");haptics.setTextColor(INK);haptics.setChecked(hapticEnabled);p.addView(haptics);haptics.setOnCheckedChangeListener((b,v)->{hapticEnabled=v;prefs.edit().putBoolean("haptics",v).apply();});
        LinearLayout privacy=card();headingIn(privacy,"Быстрое скрытие",15);privacy.addView(label("Выбери разделы, содержимое которых будет закрываться при обычной навигации. Кнопка ◈ сверху открывает нейтральный экран.",12,MUTED,false,Typeface.DEFAULT));for(String s:HIDE_OPTIONS){CheckBox cb=new CheckBox(this);cb.setText(s);cb.setTextColor(INK);cb.setChecked(hiddenSections.contains(s));cb.setOnCheckedChangeListener((b,v)->{if(v)hiddenSections.add(s);else hiddenSections.remove(s);saveHiddenSections();});privacy.addView(cb);}privacy.addView(action("Проверить быстрое скрытие",()->showQuickHide(),false));
        LinearLayout data=card();headingIn(data,"Резервные копии",15);data.addView(label("Личные записи хранятся локально в зашифрованном хранилище Android. Экспорт выполняется только после твоего действия.",12,MUTED,false,Typeface.DEFAULT));data.addView(action("Экспортировать личные данные",()->{backupMode=0;startExport("MySafeSpace-backup.json",REQ_EXPORT);},true));addSpace(data,7);data.addView(action("Импортировать резервную копию",()->startImport(),false));addSpace(data,7);data.addView(action("Экспортировать настройки оформления",()->{backupMode=1;startExport("MySafeSpace-theme.json",REQ_THEME_EXPORT);},false));
        LinearLayout about=card();headingIn(about,"О приложении",15);about.addView(label("My Safe Space · версия 3.0\nОфлайн-основа приложения. Некоторые расширенные функции ещё не реализованы.",12,MUTED,false,Typeface.DEFAULT));about.addView(action("Что входит в эту сборку",()->new AlertDialog.Builder(this).setTitle("My Safe Space 3.0").setMessage("Работают: календарь дней со слезами и причины, дневник, воспоминания, цели, базовая библиотека, локальная поддержка, темы, экспорт/импорт, шифрование локального хранилища.\n\nПока отсутствуют: полноценная ИИ-подруга, социальная сеть, облачная синхронизация, визуальный редактор коллажей, PDF-книги и фотоальбом.").setPositiveButton("Понятно",null).show(),false));
    }

    private void saveHiddenSections(){StringBuilder b=new StringBuilder();for(String s:hiddenSections){if(b.length()>0)b.append('|');b.append(s);}prefs.edit().putString("hide_sections",b.toString()).apply();}
    private void showQuickHide(){
        stopNature();LinearLayout cover=column();cover.setGravity(Gravity.CENTER);cover.setPadding(dp(30),dp(30),dp(30),dp(30));cover.setBackgroundColor(BG);TextView icon=label("☁",52,MUTED,false,Typeface.SERIF);icon.setGravity(Gravity.CENTER);cover.addView(icon);TextView title=label("Тихая пауза",24,INK,false,Typeface.SERIF);title.setGravity(Gravity.CENTER);title.setPadding(0,dp(8),0,dp(8));cover.addView(title);TextView sub=label("Экран личного пространства временно скрыт.",13,MUTED,false,Typeface.DEFAULT);sub.setGravity(Gravity.CENTER);cover.addView(sub);addStandaloneSpace(cover,20);TextView back=action("Вернуться в My Safe Space",()->{buildShell();showPage("Главная");},true);cover.addView(back,new LinearLayout.LayoutParams(-1,-2));setContentView(cover);
    }
    private void addStandaloneSpace(LinearLayout into,int h){into.addView(new View(this),new LinearLayout.LayoutParams(1,dp(h)));}

    private EditText makeEdit(String hint,int lines){EditText e=new EditText(this);e.setTextSize(14);e.setTextColor(INK);e.setHintTextColor(MUTED);e.setHint(hint);e.setMinLines(lines);e.setGravity(Gravity.TOP|Gravity.START);e.setPadding(dp(12),dp(11),dp(12),dp(11));e.setBackground(solid(BG,15,LINE));return e;}
    private void startVoice(EditText target){voiceTarget=target;try{Intent i=new Intent("android.speech.action.RECOGNIZE_SPEECH");i.putExtra("android.speech.extra.LANGUAGE_MODEL","free_form");i.putExtra("android.speech.extra.LANGUAGE",Locale.getDefault().toLanguageTag());i.putExtra("android.speech.extra.PROMPT","Говори, я записываю");startActivityForResult(i,REQ_VOICE);}catch(Exception e){Toast.makeText(this,"Голосовой ввод недоступен на этом устройстве",Toast.LENGTH_SHORT).show();}}

    private void startExport(String name,int requestCode){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");i.putExtra(Intent.EXTRA_TITLE,name);try{startActivityForResult(i,requestCode);}catch(Exception e){Toast.makeText(this,"Не удалось открыть сохранение файла",Toast.LENGTH_SHORT).show();}}
    private void startImport(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");try{startActivityForResult(i,REQ_IMPORT);}catch(Exception e){Toast.makeText(this,"Не удалось открыть выбор файла",Toast.LENGTH_SHORT).show();}}
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(resultCode!=RESULT_OK||data==null||data.getData()==null)return;Uri uri=data.getData();try{
        if(requestCode==REQ_VOICE){ArrayList<String> result=data.getStringArrayListExtra("android.speech.extra.RESULTS");if(voiceTarget!=null&&result!=null&&!result.isEmpty()){String old=voiceTarget.getText().toString();voiceTarget.setText(old.isEmpty()?result.get(0):old+" "+result.get(0));}return;}
        if(requestCode==REQ_EXPORT||requestCode==REQ_THEME_EXPORT){String payload=backupMode==1?buildThemeBackup():buildDataBackup();try(OutputStream out=getContentResolver().openOutputStream(uri)){out.write(payload.getBytes(StandardCharsets.UTF_8));out.flush();}Toast.makeText(this,"Файл сохранён",Toast.LENGTH_SHORT).show();return;}
        if(requestCode==REQ_IMPORT){String raw=readUri(uri);new AlertDialog.Builder(this).setTitle("Восстановить данные?").setMessage("Импортированные данные заменят текущие записи, воспоминания и цели. Перед продолжением сделай резервную копию текущих данных.").setNegativeButton("Отмена",null).setPositiveButton("Восстановить",(d,w)->{try{restoreData(new JSONObject(raw));vaultProblem=false;saveData();applyTheme();buildShell();showPage("Главная");Toast.makeText(this,"Резервная копия восстановлена",Toast.LENGTH_LONG).show();}catch(Exception ex){Toast.makeText(this,"Не удалось прочитать эту копию",Toast.LENGTH_LONG).show();}}).show();}
    }catch(Exception e){Toast.makeText(this,"Операция не выполнена: "+e.getMessage(),Toast.LENGTH_LONG).show();}}
    private String readUri(Uri uri)throws Exception{try(InputStream in=getContentResolver().openInputStream(uri);ByteArrayOutputStream b=new ByteArrayOutputStream()){byte[] buf=new byte[8192];int n;while((n=in.read(buf))>0)b.write(buf,0,n);return b.toString("UTF-8");}}
    private String buildThemeBackup()throws Exception{JSONObject o=new JSONObject();o.put("type","mss-theme");o.put("version",3);o.put("theme",themeName);o.put("sound",soundEnabled);o.put("haptics",hapticEnabled);o.put("hideSections",new JSONArray(hiddenSections));return o.toString(2);}
    private String buildDataBackup()throws Exception{JSONObject o=toDataJson();o.put("type","mss-backup");o.put("version",3);return o.toString(2);}
    private void restoreData(JSONObject o)throws Exception{
        if("mss-theme".equals(o.optString("type"))){themeName=o.optString("theme","Sage nature");soundEnabled=o.optBoolean("sound",true);hapticEnabled=o.optBoolean("haptics",true);hiddenSections.clear();JSONArray h=o.optJSONArray("hideSections");if(h!=null)for(int i=0;i<h.length();i++)hiddenSections.add(h.optString(i));prefs.edit().putString("theme",themeName).putBoolean("sound",soundEnabled).putBoolean("haptics",hapticEnabled).apply();saveHiddenSections();return;}
        cries.clear();journal.clear();memories.clear();goals.clear();JSONArray a=o.optJSONArray("cries");if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.getJSONObject(i);cries.add(new CryRecord(x.optLong("time"),x.optString("causes"),x.optString("note")));}
        a=o.optJSONArray("journal");if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.getJSONObject(i);journal.add(new JournalEntry(x.optLong("time"),x.optString("title"),x.optString("note")));}
        a=o.optJSONArray("memories");if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.getJSONObject(i);memories.add(new MemoryEntry(x.optLong("time"),x.optString("type"),x.optString("title"),x.optString("note")));}
        a=o.optJSONArray("goals");if(a!=null)for(int i=0;i<a.length();i++){JSONObject x=a.getJSONObject(i);goals.add(new GoalEntry(x.optLong("time"),x.optString("title"),x.optBoolean("done")));}
    }

    private void hideKeyboard(View v){try{((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(v.getWindowToken(),0);}catch(Exception ignored){}}

    // AES-256 where supported, with a per-install key protected by Android Keystore.
    private SecretKey vaultKey() throws Exception {
        KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);if(ks.containsAlias(VAULT_ALIAS))return (SecretKey)ks.getKey(VAULT_ALIAS,null);
        KeyGenerator kg=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");KeyGenParameterSpec spec=new KeyGenParameterSpec.Builder(VAULT_ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setRandomizedEncryptionRequired(true).build();kg.init(spec);return kg.generateKey();
    }
    private String encryptVault(String plain)throws Exception{Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.ENCRYPT_MODE,vaultKey());byte[] iv=cipher.getIV();byte[] encrypted=cipher.doFinal(plain.getBytes(StandardCharsets.UTF_8));byte[] all=new byte[iv.length+encrypted.length];System.arraycopy(iv,0,all,0,iv.length);System.arraycopy(encrypted,0,all,iv.length,encrypted.length);return Base64.encodeToString(all,Base64.NO_WRAP);}
    private String decryptVault(String encoded)throws Exception{byte[] all=Base64.decode(encoded,Base64.NO_WRAP);if(all.length<13)throw new IllegalArgumentException("Invalid vault");byte[] iv=new byte[12];byte[] encrypted=new byte[all.length-12];System.arraycopy(all,0,iv,0,12);System.arraycopy(all,12,encrypted,0,encrypted.length);Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.DECRYPT_MODE,vaultKey(),new GCMParameterSpec(128,iv));return new String(cipher.doFinal(encrypted),StandardCharsets.UTF_8);}
    private void loadData(){
        String vault=prefs.getString("vault","");if(!vault.isEmpty()){try{restoreData(new JSONObject(decryptVault(vault)));return;}catch(Exception e){vaultProblem=true;}}
        if(vaultProblem)return;
        try{JSONArray a=new JSONArray(prefs.getString("cries","[]"));for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);cries.add(new CryRecord(o.optLong("time"),o.optString("causes"),o.optString("note")));}}catch(Exception ignored){}
        try{JSONArray a=new JSONArray(prefs.getString("journal","[]"));for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);journal.add(new JournalEntry(o.optLong("time"),o.optString("title"),o.optString("note")));}}catch(Exception ignored){}
        if(journal.isEmpty()){String legacy=prefs.getString("entries","");if(!legacy.isEmpty())for(String line:legacy.split("\\n")){if(line.trim().isEmpty())continue;String[] parts=line.split(" · ",3);long time=System.currentTimeMillis();String note=line;if(parts.length>=2){try{time=new SimpleDateFormat("dd.MM.yyyy HH:mm",Locale.getDefault()).parse(parts[0]).getTime();}catch(Exception ignored){}note=parts.length==3?parts[2]:parts[parts.length-1];}journal.add(new JournalEntry(time,"",note));}}
        try{JSONArray a=new JSONArray(prefs.getString("memories","[]"));for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);memories.add(new MemoryEntry(o.optLong("time"),o.optString("type"),o.optString("title"),o.optString("note")));}}catch(Exception ignored){}
        try{JSONArray a=new JSONArray(prefs.getString("goals","[]"));for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);goals.add(new GoalEntry(o.optLong("time"),o.optString("title"),o.optBoolean("done")));}}catch(Exception ignored){}
        if(!cries.isEmpty()||!journal.isEmpty()||!memories.isEmpty()||!goals.isEmpty())saveData();
    }
    private JSONObject toDataJson()throws Exception{
        JSONObject all=new JSONObject();JSONArray a=new JSONArray();for(CryRecord r:cries){JSONObject x=new JSONObject();x.put("time",r.time);x.put("causes",r.causes);x.put("note",r.note);a.put(x);}all.put("cries",a);
        a=new JSONArray();for(JournalEntry e:journal){JSONObject x=new JSONObject();x.put("time",e.time);x.put("title",e.title);x.put("note",e.note);a.put(x);}all.put("journal",a);
        a=new JSONArray();for(MemoryEntry e:memories){JSONObject x=new JSONObject();x.put("time",e.time);x.put("type",e.type);x.put("title",e.title);x.put("note",e.note);a.put(x);}all.put("memories",a);
        a=new JSONArray();for(GoalEntry g:goals){JSONObject x=new JSONObject();x.put("time",g.time);x.put("title",g.title);x.put("done",g.done);a.put(x);}all.put("goals",a);return all;
    }
    private void saveData(){if(vaultProblem){Toast.makeText(this,"Хранилище заблокировано: сначала восстанови данные из резервной копии",Toast.LENGTH_LONG).show();return;}try{String encrypted=encryptVault(toDataJson().toString());prefs.edit().putString("vault",encrypted).remove("cries").remove("journal").remove("memories").remove("goals").remove("entries").apply();}catch(Exception e){Toast.makeText(this,"Не удалось сохранить защищённые данные",Toast.LENGTH_LONG).show();}}

    @Override protected void onDestroy(){super.onDestroy();stopNature();if(soundPool!=null){soundPool.release();soundPool=null;}}
    @Override public void onBackPressed(){if(!current.equals("Главная")){navigate("Главная");}else super.onBackPressed();}
}
