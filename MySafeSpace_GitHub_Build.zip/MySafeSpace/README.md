# My Safe Space 3.0 — Android foundation

A native Android personal-space app written in Java. This release expands the earlier cry-day tracker into a first functional foundation for the requested product.

## Implemented in this source build

- Six-section bottom navigation: Home, Profile, Memories, Statistics, Cry Calendar, Diary.
- Cry-day calendar: add a dated crying entry, select multiple optional cause tags, add free text, leave reasons blank, inspect a date, edit or delete an entry.
- Statistics focused on days marked as crying and the reasons the user chose to record. There is no daily mood score or emotional intensity scale.
- Diary with titled and untitled text entries and speech-to-text input through the Android speech recognizer when available.
- Memories with selectable item types, title, notes, date, list view and delete confirmation.
- Goals and dreams with optional completion tracking.
- Basic self-care checklist; all checkboxes are optional and locally stored.
- Starter educational library with non-diagnostic wellbeing material.
- Local support screen with predefined responses. It is not a live AI companion or a substitute for a person, clinician or emergency service.
- Four selectable themes: Soft grunge, Sage nature, Lavender and Dark academia.
- Optional interface sounds and haptic feedback.
- Quick privacy cover screen and user-selectable sections hidden from normal navigation. This is a quick screen cover, not an app disguise or a guaranteed security boundary.
- Manual JSON export/import using Android's Storage Access Framework; import requires explicit confirmation.
- Separate theme/settings export.
- Local personal data vault encrypted using AES/GCM with a key held by Android Keystore (Android API 23+). Legacy plaintext preferences are migrated to the encrypted vault on the next save.
- Existing Gradle build logic still generates the offline rain and forest loops at build time.

## Not implemented yet

The following parts of the full product specification are future work and are not represented as finished features in this build:

- A real AI companion, remote AI API, controllable conversational memory, voice conversation and natural voice output.
- Biometric/PIN protection for selected sections and a fully configurable emergency-hide disguise.
- Full photo/video attachment management, original-quality media storage, advanced search, trash/recovery and unlimited draft history.
- Full collage editor, sticker library, custom widget system, advanced home-screen layout editor, custom launcher icon selection and animated theme editor.
- PDF books and styled PDF export.
- Validated psychological test catalog and larger source-reviewed psychology library.
- Cloud backup, opt-in multi-device sync and conflict resolution.
- Friends, profiles, direct messages, blocking/reporting and social privacy controls.
- World map/timeline of life events, anniversaries and scheduled letters to the future.
- Full Android home-screen widgets, notification scheduling, and automated app update delivery.

## Data and privacy notes

Personal app records are encrypted at rest in the app's private preferences using Android Keystore-backed AES/GCM. Android auto-backup is disabled in the manifest so encrypted local data is not silently copied without its key. User-initiated JSON exports are readable JSON files; save them somewhere private. Import replaces the current records only after confirmation. The encryption key is device-local, so the JSON export is the portable restore format.

The quick-hide screen is a visual cover, not a substitute for Android device security. The local support helper uses prepared responses; no network permission or external AI connection is included.

## Build

Requires JDK 17, Gradle 8.9, Android SDK Platform 35 and Build Tools 35.0.0. From this directory run:

```bash
gradle --no-daemon assembleDebug
```

The APK is generated at `app/build/outputs/apk/debug/app-debug.apk`.
