# My Safe Space 2.0 — Android

A calm, private journaling app with a cream-and-sage botanical design. Built in Java with native Android views; no analytics, account, ads, or network permission.

## Included in version 2.0

- Light ivory background, sage-green gradients, refined serif headings, rounded cards, and botanical accents.
- Animated launch screen and gentle page/button transitions.
- Optional sound effects for taps, saving, and opening; haptic feedback can be disabled.
- Two offline ambient sound loops generated during the build: gentle rain and a quiet woodland bed. They can be started/stopped on the home screen.
- A dedicated “I cried” flow with multi-select reasons and an optional note.
- A month calendar that marks only days with crying entries. Tapping a date shows the saved time, reason(s), and note.
- Diary entries, a basic statistics screen, a local supportive prompt chat, and privacy/settings controls.
- Local-only storage. Entries are not uploaded or synchronized.
- Migration of previous version's diary entries from the old `safe_space` preferences key.

## Build

Requires JDK 17, Gradle 8.9, Android SDK Platform 35 and Build Tools 35.0.0. Run `gradle assembleDebug` from this folder. The debug APK is generated at `app/build/outputs/apk/debug/app-debug.apk`.

## Privacy and limitations

The helper chat uses prepared local replies; it is not a live AI or a crisis service. Do not treat it as therapy or emergency support. The app has no internet permission and keeps diary content on the device. Uninstalling the app or clearing its storage deletes the local records.

The two ambient audio loops are generated at build time and kept uncompressed in the APK. This keeps the source ZIP small for mobile upload while producing an APK above 40 MB with functional offline relaxation audio rather than dummy padding.
