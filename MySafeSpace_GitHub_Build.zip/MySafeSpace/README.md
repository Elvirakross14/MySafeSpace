# My Safe Space 3.3

A native Android personal-space app written in Java. It includes a rearrangeable two-column home screen, four adaptive themes, interactive watercolor cat companions, a unified memory timeline, and a local-first encrypted data vault.

## Included in this source build

- Home screen action **“Я сегодня плакала”**: one tap creates one distinct episode; multiple episodes on the same date are counted separately.
- Optional multi-select causes, user-created/renamed/deleted cause tags, optional free-text notes, and optional intensity from 1–5.
- Optional multiple photo and audio-file attachments per episode, plus in-app microphone recording. Attachments are encrypted individually at rest.
- A supportive, non-judgmental message after saving an episode. No separate support mode is added by this feature.
- Calendar with adaptive glowing dots on dates with entries, per-day episode count, detailed episode view, and edit/delete actions. Date and time can be edited.
- Linear daily chart with weekly, monthly, and yearly ranges; switch between episode count and average recorded intensity; filter by one or multiple causes.
- Statistics for the selected period and an optional “periods without entries” summary that can be hidden. Missing entries are explicitly not treated as evidence of wellbeing.
- Four selectable, adaptive themes: Midnight, Cloudy, Cherry Noir, and Sage Garden. Older Soft Grunge and Dreamcore selections migrate to the two new themes. The chart and accents follow the active theme. Motion can be disabled or set to gentle or more noticeable.
- Optional daily reminder at a user-selected time, with the alarm restored after device restart.
- Yandex Disk app-folder backup flow: OAuth authorization with PKCE, a user-held recovery key, AES-GCM encrypted portable backup containing records and media, automatic WorkManager upload after record changes when enabled, retry when network returns, daily verification backup, manual sync, and restore. Access/refresh tokens are encrypted using Android Keystore.
- Diary notes, saved moments, and crying-calendar entries appear together in one chronological Memories timeline, with edit and delete actions for the different entry types.
- The home screen can be rearranged and its blocks shown or hidden; these preferences persist.
- Nine original watercolor-style cat stickers form an interactive collection. A tap triggers expressive reactions, a double tap gives an affectionate response, a short swipe pets the cat, and a long press lets it be dragged. Cat positions, names, and home-screen visibility are saved locally. Gentle idle motion follows the animation preference.
- Existing goals, self-care, local support prompts, interface sound/haptics, quick-hide screen, and local encrypted vault are retained.
- Manual JSON export/import remains available. The cloud backup includes attachment bytes; the legacy JSON export includes record metadata only.

## Yandex Disk setup

1. Register an OAuth application in the Yandex OAuth console.
2. Configure the redirect URI exactly as `mysafespace://oauth/callback` and grant `cloud_api:disk.app_folder`.
3. Copy the OAuth **Client ID** into Profile → Yandex Disk in the app, then authorize through Yandex. The app does not ask for the Yandex password.
4. Save the recovery key somewhere separate from the phone. Automatic sync is not enabled until the key is confirmed.
5. Enable automatic sync. New saves are queued for upload when a network is available; WorkManager retries failed uploads.

The cloud file is encrypted on the device before upload. Losing both the phone and the recovery key means the cloud copy cannot be decrypted. Yandex OAuth registration and live upload/restore have not been exercised in this build environment and require the user's own Client ID and consent.

## Data and privacy

- Private records are stored in app-private storage, encrypted with AES/GCM using an Android Keystore key.
- Photo/audio attachments are encrypted with the same device-protected key at rest.
- Cloud backups are separately encrypted with the recovery key before they leave the phone.
- The diary has no additional PIN or biometric gate, as requested. Normal Android device security still applies.
- Android auto-backup remains disabled. Keep the Yandex recovery key separately; it is required to restore a cloud backup on a new phone.

## Build

Requires JDK 17, Gradle 8.9, Android SDK Platform 35, and Build Tools 35.0.0. From this directory:

```bash
gradle --no-daemon assembleDebug
```

The APK is generated at `app/build/outputs/apk/debug/app-debug.apk`. The existing repository-level GitHub Actions workflow is responsible for signing with the persistent keystore configured in repository secrets. Do not change the application ID (`com.mysafespace.app`) or signing secrets.

## Verification status

Manifest/resource XML has been parsed and the source has been reviewed for Java syntax delimiters. This container does not have Android SDK/Gradle installed, so this source archive has **not** been compiled or run on a device. The repository's GitHub Actions build must complete successfully before installing. Do not uninstall the existing app; preserve its local encrypted data.
